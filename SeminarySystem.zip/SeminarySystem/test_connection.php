<?php

require_once __DIR__ . '/config/database.php';

try {
    $stmt = $pdo->query('SELECT DATABASE() AS database_name');

    $result = $stmt->fetch();

    echo '<h1>Database Connection Successful!</h1>';

    echo '<p>Connected database: ' .
        htmlspecialchars($result['database_name'], ENT_QUOTES, 'UTF-8') .
        '</p>';

} catch (PDOException $e) {
    error_log('Database test failed: ' . $e->getMessage());

    http_response_code(500);

    echo 'The database test failed. Check the server logs.';
}