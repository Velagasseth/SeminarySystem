<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Require login.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Check department access.
if (($_SESSION['role'] ?? '') !== 'super_admin') {

    $stmt = $pdo->prepare(
        "SELECT 1
         FROM user_departments ud
         INNER JOIN departments d
            ON d.id = ud.department_id
         WHERE ud.user_id = ?
           AND d.department_code = 'manual-work'
           AND d.status = 'active'
         LIMIT 1"
    );

    $stmt->execute([(int) $_SESSION['user_id']]);

    if (!$stmt->fetch()) {
        http_response_code(403);
        exit('Access denied. You are not assigned to the Manual Work Department.');
    }
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$fullName = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manual Work Dashboard | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            margin: 0;
            font-size: 22px;
        }

        header p {
            margin: 7px 0 0;
            font-size: 13px;
            color: #d1fae5;
        }

        .logout {
            background: #dc2626;
            color: white;
            padding: 10px 14px;
            border-radius: 6px;
            text-decoration: none;
        }

        main {
            max-width: 1100px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h2 {
            color: #123b2a;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .card h3 {
            margin-top: 0;
            color: #14532d;
        }

        .card p {
            color: #64748b;
            line-height: 1.5;
        }

        .card a {
            display: inline-block;
            margin-top: 8px;
            color: #166534;
            font-weight: bold;
            text-decoration: none;
        }

        .notice {
            margin-top: 25px;
            padding: 16px;
            background: #dcfce7;
            border-left: 4px solid #166534;
            border-radius: 5px;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>🧹 Manual Work Department</h1>
        <p>Seminary Management System</p>
    </div>

    <a class="logout" href="../admin/logout.php">Log Out</a>
</header>

<main>

    <section class="welcome">
        <h2>Welcome, <?= e($fullName) ?>!</h2>

        <p>
            Role: <?= e(ucwords(str_replace('_', ' ', $role))) ?>
        </p>

        <p>
            Organize community work, allocate responsibilities,
            and maintain the seminary environment.
        </p>
    </section>

    <section class="cards">

        <article class="card">
            <h3>🧹 Cleaning Duties</h3>
            <p>Organize bathroom, toilet, classroom, and corridor cleaning.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🌱 Gardening</h3>
            <p>Coordinate watering, planting, pruning, and garden maintenance.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🏡 Compound Maintenance</h3>
            <p>Plan compound cleaning, grass cutting, and general maintenance.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🐔 Poultry Management</h3>
            <p>Organize feeding, cleaning, egg collection, and poultry care.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🐇 Animal Care</h3>
            <p>Coordinate the care and feeding of rabbits and dogs.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>⛪ Chapel and Library</h3>
            <p>Schedule cleaning and maintenance of shared community spaces.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🍽️ Refectory Duties</h3>
            <p>Organize dining hall cleaning and related responsibilities.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>👥 Work Assignments</h3>
            <p>Assign seminarians or groups to duties and monitor completion.</p>
            <a href="#">Coming soon</a>
        </article>

    </section>

    <div class="notice">
        <strong>Development notice:</strong>
        This dashboard currently provides the interface.
        We will connect the work assignments and schedules to the database
        in later development stages.
    </div>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
