<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['finance_csrf'])) {
    $_SESSION['finance_csrf'] = bin2hex(random_bytes(32));
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['finance_csrf'], $token)
    ) {
        $error = 'Invalid request. Please refresh the page.';
    } else {

        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === '' || $password === '') {
            $error = 'Enter your username and password.';
        } else {

            $stmt = $pdo->prepare(
                'SELECT id, full_name, username, password_hash, role, status
                 FROM users
                 WHERE username = ?
                 LIMIT 1'
            );

            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if (
                $user &&
                password_verify($password, $user['password_hash']) &&
                $user['status'] === 'active'
            ) {

                $hasAccess = ($user['role'] === 'super_admin');

                if (!$hasAccess) {

                    $access = $pdo->prepare(
                        "SELECT 1
                         FROM user_departments ud
                         INNER JOIN departments d
                            ON d.id = ud.department_id
                         WHERE ud.user_id = ?
                           AND d.department_code = 'finance'
                           AND d.status = 'active'
                         LIMIT 1"
                    );

                    $access->execute([(int) $user['id']]);
                    $hasAccess = (bool) $access->fetchColumn();
                }

                if ($hasAccess) {

                    session_regenerate_id(true);

                    $_SESSION['user_id'] = (int) $user['id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['department_code'] = 'finance';

                    header('Location: dashboard.php');
                    exit;

                } else {
                    $error = 'You are not authorized to access the Finance Department.';
                }

            } else {
                $error = 'Invalid username or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Finance Login | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: #f1f5f9;
            font-family: Arial, sans-serif;
        }

        .login-box {
            width: 100%;
            max-width: 410px;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }

        .icon {
            text-align: center;
            font-size: 45px;
        }

        h1 {
            text-align: center;
            color: #123b2a;
            font-size: 25px;
            margin-bottom: 8px;
        }

        .subtitle {
            text-align: center;
            color: #64748b;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 16px;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 16px;
        }

        button {
            width: 100%;
            margin-top: 22px;
            padding: 13px;
            border: none;
            border-radius: 6px;
            background: #14532d;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #166534;
        }

        .error {
            padding: 12px;
            background: #fee2e2;
            color: #991b1b;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .back {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #166534;
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="login-box">

    <div class="icon">💰</div>

    <h1>Finance Department</h1>

    <p class="subtitle">Seminary Management System</p>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars(
                $_SESSION['finance_csrf'],
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >

        <label for="username">Username</label>

        <input
            type="text"
            id="username"
            name="username"
            autocomplete="username"
            required
        >

        <label for="password">Password</label>

        <input
            type="password"
            id="password"
            name="password"
            autocomplete="current-password"
            required
        >

        <button type="submit">Log In</button>

    </form>

    <a class="back" href="../index.php">← Back to Main Website</a>

</div>

</body>
</html>
