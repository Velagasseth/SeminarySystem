<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Require login.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Verify Sports Department access.
if (($_SESSION['role'] ?? '') !== 'super_admin') {

    $stmt = $pdo->prepare(
        "SELECT 1
         FROM user_departments ud
         INNER JOIN departments d
            ON d.id = ud.department_id
         WHERE ud.user_id = ?
           AND d.department_code = 'sports'
           AND d.status = 'active'
         LIMIT 1"
    );

    $stmt->execute([(int) $_SESSION['user_id']]);

    if (!$stmt->fetch()) {
        http_response_code(403);
        exit('Access denied. You are not assigned to the Sports Department.');
    }
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$fullName = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sports Dashboard | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            margin: 0;
            font-size: 22px;
        }

        header p {
            margin: 7px 0 0;
            font-size: 13px;
            color: #d1fae5;
        }

        .logout {
            background: #dc2626;
            color: white;
            padding: 10px 14px;
            border-radius: 6px;
            text-decoration: none;
        }

        main {
            max-width: 1100px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h2 {
            color: #123b2a;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .card h3 {
            color: #14532d;
            margin-top: 0;
        }

        .card p {
            color: #64748b;
            line-height: 1.5;
        }

        .card a {
            display: inline-block;
            margin-top: 8px;
            color: #166534;
            font-weight: bold;
            text-decoration: none;
        }

        .notice {
            margin-top: 25px;
            padding: 16px;
            background: #dcfce7;
            border-left: 4px solid #166534;
            border-radius: 5px;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>⚽ Sports Department</h1>
        <p>Seminary Management System</p>
    </div>

    <a class="logout" href="../admin/logout.php">Log Out</a>
</header>

<main>

    <section class="welcome">
        <h2>Welcome, <?= e($fullName) ?>!</h2>

        <p>
            Role: <?= e(ucwords(str_replace('_', ' ', $role))) ?>
        </p>

        <p>
            Promote teamwork, healthy competition, discipline,
            and physical fitness within the seminary.
        </p>
    </section>

    <section class="cards">

        <article class="card">
            <h3>🏃 Sports and Games</h3>
            <p>Organize football, volleyball, basketball, athletics, and other games.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>👥 Teams and Classes</h3>
            <p>Organize teams and register participants for competitions.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📅 Fixtures</h3>
            <p>Publish match dates, times, venues, and participating teams.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🏆 Competitions</h3>
            <p>Coordinate inter-class tournaments and sports events.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📊 Results and Standings</h3>
            <p>Record scores, wins, draws, losses, and league standings.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📰 Sports News</h3>
            <p>Publish announcements, match reports, and competition updates.</p>
            <a href="#">Coming soon</a>
        </article>

    </section>

    <div class="notice">
        <strong>Development notice:</strong>
        The Sports Dashboard is ready as an interface.
        We will connect fixtures, results, teams, and announcements to the
        database in later steps.
    </div>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>