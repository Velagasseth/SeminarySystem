<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Protect the dashboard.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'super_admin') {
    http_response_code(403);
    exit('Access denied.');
}

// Get the total number of registered users.
$stmt = $pdo->query('SELECT COUNT(*) FROM users');
$totalUsers = (int) $stmt->fetchColumn();

// Get the total number of departments.
$stmt = $pdo->query('SELECT COUNT(*) FROM departments');
$totalDepartments = (int) $stmt->fetchColumn();

// Get the number of active users.
$stmt = $pdo->query(
    "SELECT COUNT(*) FROM users WHERE status = 'active'"
);
$activeUsers = (int) $stmt->fetchColumn();

// Retrieve departments for the dashboard.
$stmt = $pdo->query(
    'SELECT department_name, department_code, status
     FROM departments
     ORDER BY department_name'
);
$departments = $stmt->fetchAll();

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Administrator Dashboard</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 18px 22px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 {
            margin: 0;
            font-size: 21px;
        }

        header p {
            margin: 6px 0 0;
            color: #d1fae5;
            font-size: 13px;
        }

        .logout {
            padding: 10px 15px;
            border-radius: 6px;
            background: #dc2626;
            color: white;
            text-decoration: none;
        }

        main {
            max-width: 1150px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h2 {
            margin-bottom: 8px;
            color: #123b2a;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .stat-card {
            padding: 22px;
            background: white;
            border-radius: 10px;
            border-left: 5px solid #166534;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .stat-card h3 {
            margin: 0 0 12px;
            font-size: 14px;
            color: #64748b;
        }

        .stat-card strong {
            font-size: 30px;
            color: #123b2a;
        }

        .section-title {
            margin-bottom: 15px;
            color: #123b2a;
        }

        .departments {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 15px;
        }

        .department-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        .department-card h3 {
            margin-top: 0;
            margin-bottom: 10px;
        }

        .department-card p {
            color: #64748b;
            font-size: 13px;
        }

        .status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            background: #dcfce7;
            color: #166534;
            font-size: 12px;
        }

        .department-code {
            font-size: 12px;
            color: #64748b;
        }

        footer {
            padding: 25px;
            text-align: center;
            color: #64748b;
            font-size: 13px;
        }
        
        .header-links {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.manage-users {
    padding: 10px 15px;
    border-radius: 6px;
    background: #ffffff;
    color: #123b2a;
    text-decoration: none;
}
    </style>
</head>

<body>

<header>
    <div>
        <h1>Seminary Management System</h1>
        <p>Administrator Control Panel</p>
    </div>

    <div class="header-links">
    <a class="manage-users" href="users.php">Manage Users</a>
    <a class="logout" href="logout.php">Log Out</a>
</div>
</header>

<main>

    <section class="welcome">
        <h2>
            Welcome, <?= e($_SESSION['full_name'] ?? 'Administrator') ?>!
        </h2>

        <p>
            Manage seminary departments, users, and daily activities
            from one central dashboard.
        </p>
    </section>

    <section class="stats">

        <div class="stat-card">
            <h3>Total Users</h3>
            <strong><?= $totalUsers ?></strong>
        </div>

        <div class="stat-card">
            <h3>Active Users</h3>
            <strong><?= $activeUsers ?></strong>
        </div>

        <div class="stat-card">
            <h3>Departments</h3>
            <strong><?= $totalDepartments ?></strong>
        </div>

    </section>

    <h2 class="section-title">Seminary Departments</h2>

    <section class="departments">

        <?php foreach ($departments as $department): ?>

            <article class="department-card">

                <h3><?= e($department['department_name']) ?></h3>

                <p class="department-code">
                    Department code:
                    <?= e($department['department_code']) ?>
                </p>

                <span class="status">
                    <?= e(ucfirst($department['status'])) ?>
                </span>

            </article>

        <?php endforeach; ?>

    </section>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
