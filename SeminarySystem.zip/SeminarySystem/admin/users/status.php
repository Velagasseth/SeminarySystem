<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$adminRole = $_SESSION['role'] ?? '';

if (!in_array($adminRole, ['super_admin', 'rector', 'administrator'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$action = $_POST['action'] ?? '';

if (!$id || $id === (int)$_SESSION['user_id']) {
    exit('Invalid user or you cannot change your own status.');
}

if (!in_array($action, ['activate', 'deactivate'], true)) {
    exit('Invalid action.');
}

$stmt = $pdo->prepare("SELECT id, role, status FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    exit('User not found.');
}

if ($user['role'] === 'super_admin' && $adminRole !== 'super_admin') {
    http_response_code(403);
    exit('Only a super administrator can manage this account.');
}

$newStatus = $action === 'activate' ? 'active' : 'inactive';

if ($user['role'] === 'super_admin' && $newStatus === 'inactive') {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM users
        WHERE role = 'super_admin' AND status = 'active'
    ");
    $stmt->execute();

    if ((int)$stmt->fetchColumn() <= 1) {
        exit('Cannot deactivate the last active super administrator.');
    }
}

$stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
$stmt->execute([$newStatus, $id]);

header('Location: index.php?status_updated=1');
exit;
