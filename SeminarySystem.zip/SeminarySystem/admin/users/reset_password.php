<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$adminRole = $_SESSION['role'] ?? '';

if (!in_array($adminRole, ['super_admin', 'rector', 'administrator'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id === (int)$_SESSION['user_id']) {
    exit('Invalid user ID. Use your existing account recovery process for your own account.');
}

$stmt = $pdo->prepare("SELECT id, full_name, username, role FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    exit('User not found.');
}

if ($user['role'] === 'super_admin' && $adminRole !== 'super_admin') {
    http_response_code(403);
    exit('Only a super administrator can reset this account.');
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (strlen($password) < 10) {
        $message = 'Password must contain at least 10 characters.';
    } elseif ($password !== $confirm) {
        $message = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("
            UPDATE users SET password_hash = ? WHERE id = ?
        ");
        $stmt->execute([$hash, $id]);

        header('Location: index.php?password_reset=1');
        exit;
    }
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password</title>
<style>
body{font-family:Arial;background:#f1f5f9;padding:20px}
.container{max-width:450px;margin:auto;background:white;padding:25px;border-radius:10px}
input,button{width:100%;box-sizing:border-box;padding:12px;margin:10px 0}
button{background:#173b2d;color:white;border:0}
.error{background:#fee2e2;padding:10px}
</style>
</head>
<body>
<div class="container">
<h2>Reset Password</h2>
<p>User: <?= e($user['full_name']) ?> (<?= e($user['username']) ?>)</p>

<?php if ($message): ?>
<p class="error"><?= e($message) ?></p>
<?php endif; ?>

<form method="POST">
<label>New Password</label>
<input type="password" name="password" minlength="10" autocomplete="new-password" required>

<label>Confirm Password</label>
<input type="password" name="confirm_password" minlength="10" autocomplete="new-password" required>

<button type="submit">Reset Password</button>
</form>

<a href="index.php">Back to Users</a>
</div>
</body>
</html>
