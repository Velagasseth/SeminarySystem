<?php
session_start();

require_once __DIR__ . '/../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$adminRole = $_SESSION['role'] ?? '';

if (!in_array($adminRole, ['super_admin', 'rector', 'admin'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

$userId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$userId) {
    exit('Invalid user ID.');
}

$stmt = $pdo->prepare(
    "SELECT id, full_name, username, role
     FROM users
     WHERE id = ?"
);
$stmt->execute([$userId]);

$user = $stmt->fetch();

if (!$user) {
    exit('User not found.');
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $departmentIds = $_POST['departments'] ?? [];

    if (!is_array($departmentIds)) {
        $departmentIds = [];
    }

    $departmentIds = array_values(array_unique(array_filter(
        array_map('intval', $departmentIds),
        fn($id) => $id > 0
    )));

    try {
        $pdo->beginTransaction();

        // Confirm all submitted department IDs exist.
        if ($departmentIds) {
            $placeholders = implode(
                ',',
                array_fill(0, count($departmentIds), '?')
            );

            $check = $pdo->prepare(
                "SELECT id FROM departments
                 WHERE id IN ($placeholders)"
            );

            $check->execute($departmentIds);

            $validIds = array_map(
                'intval',
                $check->fetchAll(PDO::FETCH_COLUMN)
            );

            sort($validIds);
            $submittedIds = $departmentIds;
            sort($submittedIds);

            if ($validIds !== $submittedIds) {
                throw new RuntimeException('Invalid department selected.');
            }
        }

        // Replace existing assignments.
        $delete = $pdo->prepare(
            "DELETE FROM user_departments WHERE user_id = ?"
        );
        $delete->execute([$userId]);

        // Insert the new assignments.
        $insert = $pdo->prepare(
            "INSERT INTO user_departments
             (user_id, department_id, access_level)
             VALUES (?, ?, 'view')"
        );

        foreach ($departmentIds as $departmentId) {
            $insert->execute([$userId, $departmentId]);
        }

        $pdo->commit();

        $message = 'Department assignments saved successfully.';

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log('Department assignment error: ' . $e->getMessage());

        $message = $e instanceof RuntimeException
            ? $e->getMessage()
            : 'Unable to save assignments. Check the PHP server terminal.';
    }
}

// Load departments.
$departments = $pdo->query(
    "SELECT id, department_name
     FROM departments
     WHERE status = 'active'
     ORDER BY department_name"
)->fetchAll();

// Load current assignments.
$stmt = $pdo->prepare(
    "SELECT department_id
     FROM user_departments
     WHERE user_id = ?"
);
$stmt->execute([$userId]);

$assignedDepartments = array_map(
    'intval',
    $stmt->fetchAll(PDO::FETCH_COLUMN)
);

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Department Assignments</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f9;
    color: #1e293b;
}

header {
    background: #173b2d;
    color: white;
    padding: 20px;
}

main {
    max-width: 750px;
    margin: auto;
    padding: 20px;
}

.card {
    background: white;
    padding: 22px;
    border-radius: 10px;
    margin-bottom: 18px;
}

.department {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 13px;
    border-bottom: 1px solid #e2e8f0;
}

.department input {
    width: 19px;
    height: 19px;
}

button, .btn {
    display: inline-block;
    padding: 12px 17px;
    background: #173b2d;
    color: white;
    border: none;
    border-radius: 6px;
    text-decoration: none;
    cursor: pointer;
}

.message {
    padding: 12px;
    background: #dcfce7;
    border-radius: 6px;
}
</style>
</head>

<body>

<header>
    <h2>Seminary Management System</h2>
    <p>Department Assignment</p>
</header>

<main>

    <div class="card">
        <h3><?= e($user['full_name']) ?></h3>
        <p>Username: <?= e($user['username']) ?></p>
        <p>Role: <?= e(ucwords(str_replace('_', ' ', $user['role']))) ?></p>
    </div>

    <div class="card">

        <h3>Assign Departments</h3>

        <?php if ($message): ?>
            <p class="message"><?= e($message) ?></p>
        <?php endif; ?>

        <form method="POST">

            <?php foreach ($departments as $department): ?>

                <label class="department">

                    <input
                        type="checkbox"
                        name="departments[]"
                        value="<?= (int)$department['id'] ?>"
                        <?= in_array(
                            (int)$department['id'],
                            $assignedDepartments,
                            true
                        ) ? 'checked' : '' ?>
                    >

                    <span>
                        <?= e($department['department_name']) ?>
                    </span>

                </label>

            <?php endforeach; ?>

            <br>

            <button type="submit">Save Assignments</button>

        </form>

        <br><br>

        <a class="btn" href="index.php">Back to Users</a>

    </div>

</main>

</body>
</html>
