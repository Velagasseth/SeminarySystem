<?php
session_start();

require_once __DIR__ . '/../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$role = $_SESSION['role'] ?? '';

if (!in_array($role, ['super_admin', 'rector', 'admin'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

$stmt = $pdo->query("
    SELECT id, full_name, username, email, role, status, created_at
    FROM users
    ORDER BY id DESC
");

$users = $stmt->fetchAll();

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>User Management | Seminary System</title>

<style>
*{box-sizing:border-box}
body{margin:0;font-family:Arial,sans-serif;background:#f1f5f9;color:#1e293b}
header{background:#173b2d;color:white;padding:20px}
header h2{margin:0}
main{padding:20px;max-width:1200px;margin:auto}
.actions{display:flex;gap:10px;flex-wrap:wrap;margin:20px 0}
.btn{display:inline-block;padding:11px 16px;background:#173b2d;color:white;text-decoration:none;border-radius:6px;border:0;cursor:pointer}
.btn.secondary{background:#475569}
input{padding:12px;width:100%;border:1px solid #cbd5e1;border-radius:6px;margin-bottom:15px}
.table-wrap{overflow-x:auto;background:white;border-radius:8px}
table{width:100%;border-collapse:collapse;min-width:750px}
th,td{padding:13px;text-align:left;border-bottom:1px solid #e2e8f0}
th{background:#e2e8f0}
.badge{padding:5px 9px;border-radius:20px;background:#dcfce7;color:#166534}
.inactive{background:#fee2e2;color:#991b1b}
.count{background:white;padding:16px;border-radius:8px}
</style>
</head>

<body>
<header>
    <h2>Seminary Management System</h2>
    <p>User Management</p>
</header>

<main>

    <div class="count">
        <strong>Total registered users:</strong>
        <?= count($users) ?>
    </div>

    <div class="actions">
        <a class="btn" href="create.php">+ Add User</a>
        <a class="btn secondary" href="../dashboard.php">Dashboard</a>
    </div>

    <input
        type="search"
        id="search"
        placeholder="Search by name, username, role or email..."
        oninput="filterUsers()"
    >

    <div class="table-wrap">
    <table id="usersTable">
        <thead>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Registered</th>
            <th>Action</th>
        </tr>
        </thead>

        <tbody>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= e($user['id']) ?></td>
            <td><?= e($user['full_name']) ?></td>
            <td><?= e($user['username']) ?></td>
            <td><?= e($user['email'] ?? '') ?></td>
            <td><?= e($user['role']) ?></td>
            <td>
                <span class="badge <?= $user['status'] !== 'active' ? 'inactive' : '' ?>">
                    <?= e($user['status']) ?>
                </span>
            </td>
            <td><?= e($user['created_at']) ?></td>
            <td>
                <a href="edit.php?id=<?= (int)$user['id'] ?>">Edit</a>

|
<a href="reset_password.php?id=<?= (int)$user['id'] ?>">Reset Password</a>
|
<a href="departments.php?id=<?= (int)$user['id'] ?>">
    Departments
</a>
<form method="POST" action="status.php" style="display:inline">
    <input type="hidden" name="id" value="<?= (int)$user['id'] ?>">

    <input type="hidden" name="action"
           value="<?= $user['status'] === 'active' ? 'deactivate' : 'activate' ?>">

    <button type="submit"
            onclick="return confirm('Change this user account status?')">
        <?= $user['status'] === 'active' ? 'Deactivate' : 'Activate' ?>
    </button>
</form>
                </td>
        </tr>
        <?php endforeach; ?>

        <?php if (!$users): ?>
        <tr>
            <td colspan="8">No users registered yet.</td>
        </tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>

</main>

<script>
function filterUsers() {
    const query = document.getElementById('search').value.toLowerCase();

    document.querySelectorAll('#usersTable tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(query)
            ? ''
            : 'none';
    });
}
</script>

</body>
</html>
