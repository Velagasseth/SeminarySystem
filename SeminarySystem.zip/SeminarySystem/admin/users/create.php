<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

$adminRole = $_SESSION['role'] ?? '';

if (!in_array($adminRole, ['super_admin', 'rector', 'admin'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

$roles = [
    'seminarian',
    'lecturer',
    'librarian',
    'chapel_coordinator',
    'work_supervisor',
    'sports_coordinator',
    'bursar',
    'formator',
    'academic_director'
];

if ($adminRole === 'super_admin') {
    array_unshift($roles, 'rector', 'admin');
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $newRole = $_POST['role'] ?? '';

    if ($name === '' || $username === '' || strlen($password) < 10) {
        $message = 'Complete all required fields. Password must have at least 10 characters.';
    } elseif (!in_array($newRole, $roles, true)) {
        $message = 'Invalid role selected.';
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Invalid email address.';
    } else {
        try {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                INSERT INTO users
                    (full_name, username, email, password_hash, role, status)
                VALUES
                    (?, ?, ?, ?, ?, 'active')
            ");

            $stmt->execute([
                $name,
                $username,
                $email !== '' ? $email : null,
                $hash,
                $newRole
            ]);

            header('Location: index.php?created=1');
            exit;

        } catch (PDOException $e) {
            error_log('Create user error: ' . $e->getMessage());

            $message = $e->getCode() === '23000'
                ? 'Username or email already exists.'
                : 'Unable to create user. Check the PHP server terminal.';
        }
    }
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create User | Seminary System</title>
<style>
body{font-family:Arial;background:#f1f5f9;padding:20px}
.container{max-width:500px;margin:auto;background:white;padding:25px;border-radius:10px}
input,select,button{width:100%;box-sizing:border-box;padding:12px;margin:8px 0 16px}
button{background:#173b2d;color:white;border:0;border-radius:5px}
.message{padding:12px;background:#e2e8f0}
</style>
</head>
<body>
<div class="container">
<h2>Create User Account</h2>

<?php if ($message): ?>
<p class="message"><?= e($message) ?></p>
<?php endif; ?>

<form method="POST">
<label>Full Name</label>
<input name="full_name" maxlength="150" required>

<label>Username</label>
<input name="username" maxlength="80" required>

<label>Email (optional)</label>
<input type="email" name="email" maxlength="150">

<label>Password</label>
<input type="password" name="password" minlength="10" autocomplete="new-password" required>

<label>Role</label>
<select name="role" required>
<?php foreach ($roles as $r): ?>
<option value="<?= e($r) ?>"><?= e(ucwords(str_replace('_', ' ', $r))) ?></option>
<?php endforeach; ?>
</select>

<button type="submit">Create Account</button>
</form>

<a href="index.php">Back to User Management</a>
</div>
</body>
</html>