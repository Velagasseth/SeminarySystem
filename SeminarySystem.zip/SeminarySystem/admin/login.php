<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// If already logged in as an administrator, open the dashboard.
if (
    isset($_SESSION['user_id']) &&
    ($_SESSION['role'] ?? '') === 'super_admin'
) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'SELECT id, full_name, username, password_hash, role, status
                 FROM users
                 WHERE username = ?
                 LIMIT 1'
            );

            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if (
                $user &&
                password_verify($password, $user['password_hash']) &&
                $user['status'] === 'active' &&
                $user['role'] === 'super_admin'
            ) {
                session_regenerate_id(true);

                $_SESSION['user_id'] = (int) $user['id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                header('Location: dashboard.php');
                exit;
            }

            $error = 'Invalid login details or administrator access denied.';

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = 'A system error occurred. Please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Login | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
        }

        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.08);
        }

        h1 {
            margin-bottom: 8px;
            text-align: center;
            color: #123b2a;
            font-size: 25px;
        }

        .subtitle {
            margin-bottom: 25px;
            text-align: center;
            color: #64748b;
            font-size: 14px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 6px;
            background: #14532d;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #166534;
        }

        .error {
            margin-bottom: 18px;
            padding: 12px;
            border-radius: 6px;
            background: #fee2e2;
            color: #991b1b;
            font-size: 14px;
        }

        .back-link {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #14532d;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <main class="login-box">

        <h1>Administrator Login</h1>

        <p class="subtitle">
            Seminary Management System
        </p>

        <?php if ($error !== ''): ?>
            <div class="error">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="username">Username</label>

            <input
                type="text"
                id="username"
                name="username"
                autocomplete="username"
                required
            >

            <label for="password">Password</label>

            <input
                type="password"
                id="password"
                name="password"
                autocomplete="current-password"
                required
            >

            <button type="submit">Sign In</button>
        </form>

        <a class="back-link" href="../index.php">
            Back to Homepage
        </a>

    </main>
</body>
</html>
