<?php

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check whether a user is logged in.
 */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/**
 * Require a logged-in user.
 */
function requireLogin(): void
{
    if (!isLoggedIn()) {
        header('Location: /SeminarySystem/index.php');
        exit;
    }
}

/**
 * Check whether the logged-in user has a specified role.
 */
function requireRole(array $allowedRoles): void
{
    requireLogin();

    $userRole = $_SESSION['role'] ?? '';

    if (!in_array($userRole, $allowedRoles, true)) {
        http_response_code(403);
        exit('Access denied. You do not have permission to view this page.');
    }
}

/**
 * Log the user out.
 */
function logoutUser(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}
