<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

function isSystemAdministrator(): bool
{
    return isset($_SESSION['role'])
        && in_array(
            $_SESSION['role'],
            ['super_admin', 'rector', 'admin'],
            true
        );
}

function requireDepartmentAccess(string $departmentName): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: /index.php');
        exit;
    }

    // Administrators have access to all departments.
    if (isSystemAdministrator()) {
        return;
    }

    global $pdo;

    // Convert the supplied department name to its department code.
    $departmentCodes = [
        'Administration' => 'administration',
        'Academics' => 'academics',
        'Chapel' => 'chapel',
        'Communications' => 'communications',
        'Finance' => 'finance',
        'Formation' => 'formation',
        'Library' => 'library',
        'Manual Work' => 'manual-work',
        "Rector's Talk" => 'rectors-talk',
        'Seminarian Portal' => 'seminarian-portal',
        'Sports' => 'sports'
    ];

    if (!isset($departmentCodes[$departmentName])) {
        http_response_code(400);
        exit('Invalid department configuration.');
    }

    $departmentCode = $departmentCodes[$departmentName];

    $sql = "
        SELECT 1
        FROM user_departments ud
        INNER JOIN departments d
            ON d.id = ud.department_id
        WHERE ud.user_id = :user_id
          AND d.department_code = :department_code
          AND d.status = 'active'
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        'user_id' => (int) $_SESSION['user_id'],
        'department_code' => $departmentCode
    ]);

    if (!$stmt->fetchColumn()) {
        http_response_code(403);
        exit(
            '<h2>Access Denied</h2>
            <p>You have not been assigned access to this department.</p>
            <p><a href="../portal/dashboard.php">Return to Dashboard</a></p>'
        );
    }
}