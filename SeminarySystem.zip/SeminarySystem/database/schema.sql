-- ==========================================
-- SEMINARY MANAGEMENT SYSTEM
-- DATABASE SCHEMA
-- ==========================================

USE seminary_management;

-- ==========================================
-- 1. USERS TABLE
-- ==========================================

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    full_name VARCHAR(150) NOT NULL,

    username VARCHAR(80) NOT NULL UNIQUE,

    email VARCHAR(150) UNIQUE,

    password VARCHAR(255) NOT NULL,

    role ENUM(
        'super_admin',
        'rector',
        'administrator',
        'department_head',
        'staff',
        'seminarian'
    ) NOT NULL DEFAULT 'seminarian',

    status ENUM(
        'active',
        'inactive',
        'suspended'
    ) NOT NULL DEFAULT 'active',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;


-- ==========================================
-- 2. DEPARTMENTS TABLE
-- ==========================================

CREATE TABLE IF NOT EXISTS departments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    department_name VARCHAR(100) NOT NULL UNIQUE,

    description TEXT,

    status ENUM(
        'active',
        'inactive'
    ) NOT NULL DEFAULT 'active',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


-- ==========================================
-- 3. USER DEPARTMENT PERMISSIONS
-- ==========================================

CREATE TABLE IF NOT EXISTS user_departments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    user_id INT UNSIGNED NOT NULL,

    department_id INT UNSIGNED NOT NULL,

    access_level ENUM(
        'view',
        'manage'
    ) NOT NULL DEFAULT 'view',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY unique_user_department (
        user_id,
        department_id
    ),

    CONSTRAINT fk_user_departments_user
        FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_user_departments_department
        FOREIGN KEY (department_id)
        REFERENCES departments(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;


-- ==========================================
-- 4. INITIAL DEPARTMENTS
-- ==========================================

INSERT IGNORE INTO departments
    (department_name, description)
VALUES
    (
        'Administration',
        'Rector, administration and system management'
    ),
    (
        'Academics',
        'Classes, lectures, units, assignments and study groups'
    ),
    (
        'Manual Work',
        'Cleaning, gardening, poultry, animals and compound maintenance'
    ),
    (
        'Sports',
        'Games, competitions, fixtures and sports news'
    ),
    (
        'Library',
        'Books, learning materials, borrowing and returns'
    ),
    (
        'Chapel',
        'Liturgical duties, choir, lectors and altar service'
    ),
    (
        'Rector''s Talk',
        'Rector''s announcements, talks and instructions'
    ),
    (
        'Singing Practice',
        'Choir rehearsals, songs and singing schedules'
    ),
    (
        'Community Service',
        'Pastoral activities and community service assignments'
    ),
    (
        'Liturgical Celebrations',
        'Team Masses, Sunday Masses and recollections'
    );


-- ==========================================
-- END OF SCHEMA
-- ==========================================
