<?php
require_once __DIR__ . '/../includes/department_auth.php';
requireDepartmentAccess('Library');


// Check whether the user is logged in.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Verify Library Department access.
if (($_SESSION['role'] ?? '') !== 'super_admin') {

    $stmt = $pdo->prepare(
        "SELECT 1
         FROM user_departments ud
         INNER JOIN departments d
            ON d.id = ud.department_id
         WHERE ud.user_id = ?
           AND d.department_code = 'library'
           AND d.status = 'active'
         LIMIT 1"
    );

    $stmt->execute([(int) $_SESSION['user_id']]);

    if (!$stmt->fetch()) {
        http_response_code(403);
        exit('Access denied. You are not assigned to the Library Department.');
    }
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$fullName = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Library Dashboard | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            margin: 0;
            font-size: 21px;
        }

        header p {
            margin: 7px 0 0;
            font-size: 13px;
            color: #d1fae5;
        }

        .logout {
            color: white;
            background: #dc2626;
            padding: 10px 14px;
            text-decoration: none;
            border-radius: 6px;
        }

        main {
            max-width: 1100px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h2 {
            color: #123b2a;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .card {
            padding: 22px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, .05);
        }

        .card h3 {
            margin-top: 0;
            color: #14532d;
        }

        .card p {
            color: #64748b;
            line-height: 1.5;
        }

        .card a {
            display: inline-block;
            margin-top: 8px;
            color: #166534;
            font-weight: bold;
            text-decoration: none;
        }

        .notice {
            background: #dcfce7;
            border-left: 4px solid #166534;
            padding: 16px;
            margin-top: 25px;
            border-radius: 5px;
        }

        footer {
            padding: 25px;
            text-align: center;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>Library Department</h1>
        <p>Seminary Management System</p>
    </div>

    <a class="logout" href="../admin/logout.php">Log Out</a>
</header>

<main>

    <section class="welcome">
        <h2>Welcome, <?= e($fullName) ?>!</h2>

        <p>
            Role: <?= e(ucwords(str_replace('_', ' ', $role))) ?>
        </p>

        <p>
            Manage library books, borrowing, returns, and learning resources.
        </p>
    </section>

    <section class="cards">

        <article class="card">
            <h3>📚 Book Catalogue</h3>
            <p>Register books, search titles, and check availability.</p>
            <a href="books/index.php">Open Book Catalogue →</a>
        </article>
        
   <article class="card">
    <h3>📖 Borrowing and Returns</h3>

    <p>
        View your borrowing history or manage borrowing
        according to your assigned permissions.
    </p>

    <?php if ($role === 'seminarian'): ?>

        <a href="borrowings/my_books.php">
            View My Borrowed Books →
        </a>

    <?php elseif (in_array($role, [
        'librarian',
        'super_admin',
        'rector',
        'admin'
    ], true)): ?>

        <a href="borrowings/index.php">
            Manage Book Borrowing →
        </a>

    <?php else: ?>

        <p>
            Contact the librarian if you need borrowing assistance.
        </p>

    <?php endif; ?>
</article>


        <article class="card">
            <h3>⏰ Overdue Books</h3>
            <p>Identify books that have passed their return dates.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>💻 Digital Library</h3>
            <p>Organize electronic notes and learning materials.</p>
            <a href="#">Coming soon</a>
        </article>

    </section>

    <div class="notice">
        <strong>Development notice:</strong>
        The Library dashboard is ready. The individual library functions
        will be connected to the database in later steps.
    </div>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
