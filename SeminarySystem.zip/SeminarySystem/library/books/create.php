<?php


require_once __DIR__ . '/../library_permissions.php';
requireLibraryManager();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Display the form below.
}

$errors = [];

$title = '';
$author = '';
$isbn = '';
$publisher = '';
$publication_year = '';
$category = '';
$shelf_location = '';
$total_copies = '1';
$description = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $publisher = trim($_POST['publisher'] ?? '');
    $publication_year = trim($_POST['publication_year'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $shelf_location = trim($_POST['shelf_location'] ?? '');
    $total_copies = trim($_POST['total_copies'] ?? '1');
    $description = trim($_POST['description'] ?? '');

    if ($title === '') {
        $errors[] = 'Book title is required.';
    }

    if ($author === '') {
        $errors[] = 'Author is required.';
    }

    if (!ctype_digit($total_copies) || (int)$total_copies < 1) {
        $errors[] = 'Total copies must be at least 1.';
    }

    if (
        $publication_year !== ''
        && (
            !ctype_digit($publication_year)
            || (int)$publication_year < 1
            || (int)$publication_year > (int)date('Y') + 1
        )
    ) {
        $errors[] = 'Enter a valid publication year.';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                "INSERT INTO books (
                    isbn,
                    title,
                    author,
                    publisher,
                    publication_year,
                    category,
                    shelf_location,
                    total_copies,
                    available_copies,
                    description
                ) VALUES (
                    :isbn,
                    :title,
                    :author,
                    :publisher,
                    :publication_year,
                    :category,
                    :shelf_location,
                    :total_copies,
                    :available_copies,
                    :description
                )"
            );

            $stmt->execute([
                'isbn' => $isbn !== '' ? $isbn : null,
                'title' => $title,
                'author' => $author,
                'publisher' => $publisher !== '' ? $publisher : null,
                'publication_year' => $publication_year !== ''
                    ? (int)$publication_year : null,
                'category' => $category !== '' ? $category : null,
                'shelf_location' => $shelf_location !== ''
                    ? $shelf_location : null,
                'total_copies' => (int)$total_copies,
                'available_copies' => (int)$total_copies,
                'description' => $description !== '' ? $description : null
            ]);

            header('Location: index.php?success=created');
            exit;

        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $errors[] = 'This ISBN already exists. Check the ISBN or leave it blank.';
            } else {
                error_log($e->getMessage());
                $errors[] = 'Unable to save the book. Please try again.';
            }
        }
    }
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book | Seminary Library</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f3;
            color: #24332b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 20px;
        }

        header h1 {
            margin: 0 0 6px;
            font-size: 23px;
        }

        header p {
            margin: 0;
            color: #d1e4d7;
            font-size: 13px;
        }

        main {
            max-width: 850px;
            margin: 30px auto;
            padding: 0 16px;
        }

        .form-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, .05);
        }

        .form-card h2 {
            margin-top: 0;
            color: #123b2a;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .field {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .full {
            grid-column: 1 / -1;
        }

        label {
            font-size: 13px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccd7cf;
            border-radius: 7px;
            font: inherit;
            font-size: 14px;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        input:focus, textarea:focus {
            outline: 2px solid #a8d5b6;
            border-color: #246b43;
        }

        .actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            flex-wrap: wrap;
        }

        .button {
            display: inline-block;
            padding: 12px 18px;
            border: none;
            border-radius: 7px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .primary {
            background: #14532d;
            color: white;
        }

        .secondary {
            background: #e8eee9;
            color: #24332b;
        }

        .errors {
            background: #fee2e2;
            color: #991b1b;
            padding: 14px 18px;
            border-radius: 7px;
            margin-bottom: 20px;
        }

        @media (max-width: 600px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }

            .form-card {
                padding: 18px;
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Library Department</h1>
    <p>Register a new book in the seminary catalogue</p>
</header>

<main>
    <div class="form-card">
        <h2>📚 Add New Book</h2>

        <?php if ($errors): ?>
            <div class="errors">
                <strong>Please correct the following:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= h($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-grid">

                <div class="field full">
                    <label for="title">Book Title *</label>
                    <input id="title" name="title" required
                           value="<?= h($title) ?>">
                </div>

                <div class="field">
                    <label for="author">Author *</label>
                    <input id="author" name="author" required
                           value="<?= h($author) ?>">
                </div>

                <div class="field">
                    <label for="isbn">ISBN</label>
                    <input id="isbn" name="isbn"
                           value="<?= h($isbn) ?>">
                </div>

                <div class="field">
                    <label for="publisher">Publisher</label>
                    <input id="publisher" name="publisher"
                           value="<?= h($publisher) ?>">
                </div>

                <div class="field">
                    <label for="publication_year">Publication Year</label>
                    <input type="number" id="publication_year"
                           name="publication_year" min="1"
                           max="<?= (int)date('Y') + 1 ?>"
                           value="<?= h($publication_year) ?>">
                </div>

                <div class="field">
                    <label for="category">Category</label>
                    <input id="category" name="category"
                           placeholder="e.g. Philosophy, Theology"
                           value="<?= h($category) ?>">
                </div>

                <div class="field">
                    <label for="shelf_location">Shelf Location</label>
                    <input id="shelf_location" name="shelf_location"
                           placeholder="e.g. Shelf A3"
                           value="<?= h($shelf_location) ?>">
                </div>

                <div class="field">
                    <label for="total_copies">Total Copies *</label>
                    <input type="number" id="total_copies"
                           name="total_copies" min="1" required
                           value="<?= h($total_copies) ?>">
                </div>

                <div class="field full">
                    <label for="description">Description / Notes</label>
                    <textarea id="description"
                              name="description"><?= h($description) ?></textarea>
                </div>

            </div>

            <div class="actions">
                <button class="button primary" type="submit">
                    Save Book
                </button>

                <a class="button secondary" href="index.php">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</main>

</body>
</html>
