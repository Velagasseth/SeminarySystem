<?php

require_once __DIR__ . '/../library_permissions.php';
requireLibraryManager();
if (!function_exists('h')) {
    function h($value): string
    {
        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

$bookId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$bookId || $bookId < 1) {
    header('Location: index.php?error=invalid_id');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM books WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $bookId]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$book) {
    header('Location: index.php?error=not_found');
    exit;
}

$errors = [];

$form = [
    'isbn' => $book['isbn'] ?? '',
    'title' => $book['title'] ?? '',
    'author' => $book['author'] ?? '',
    'publisher' => $book['publisher'] ?? '',
    'publication_year' => $book['publication_year'] ?? '',
    'category' => $book['category'] ?? '',
    'shelf_location' => $book['shelf_location'] ?? '',
    'total_copies' => $book['total_copies'] ?? 1,
    'description' => $book['description'] ?? ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $key => $value) {
        if (isset($_POST[$key])) {
            $form[$key] = trim((string)$_POST[$key]);
        }
    }

    $form['isbn'] = $form['isbn'] !== '' ? $form['isbn'] : null;
    $form['publisher'] = $form['publisher'] !== '' ? $form['publisher'] : null;
    $form['publication_year'] = $form['publication_year'] !== ''
        ? $form['publication_year'] : null;
    $form['category'] = $form['category'] !== '' ? $form['category'] : null;
    $form['shelf_location'] = $form['shelf_location'] !== ''
        ? $form['shelf_location'] : null;
    $form['description'] = $form['description'] !== ''
        ? $form['description'] : null;

    if ($form['title'] === '') {
        $errors[] = 'Book title is required.';
    }

    if (empty($form['author'])) {
        $errors[] = 'Author name is required.';
    }

    if (
        $form['publication_year'] !== null &&
        (!ctype_digit((string)$form['publication_year']) ||
        (int)$form['publication_year'] < 1 ||
        (int)$form['publication_year'] > (int)date('Y') + 1)
    ) {
        $errors[] = 'Enter a valid publication year.';
    }

    if (
        !ctype_digit((string)$form['total_copies']) ||
        (int)$form['total_copies'] < 1
    ) {
        $errors[] = 'Total copies must be at least 1.';
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();

            // Lock this book row while updating its copy count.
            $lock = $pdo->prepare(
                "SELECT total_copies, available_copies
                 FROM books
                 WHERE id = :id
                 FOR UPDATE"
            );
            $lock->execute(['id' => $bookId]);
            $current = $lock->fetch(PDO::FETCH_ASSOC);

            if (!$current) {
                throw new RuntimeException('This book no longer exists.');
            }

            // Number of copies currently borrowed.
            $borrowedCopies =
                (int)$current['total_copies'] -
                (int)$current['available_copies'];

            $newTotal = (int)$form['total_copies'];

            if ($newTotal < $borrowedCopies) {
                $errors[] =
                    "Total copies cannot be less than {$borrowedCopies}, " .
                    "because that many copies are currently borrowed.";
                $pdo->rollBack();
            } else {
                // Preserve the number of borrowed copies.
                $newAvailable = $newTotal - $borrowedCopies;

                $update = $pdo->prepare(
                    "UPDATE books SET
                        isbn = :isbn,
                        title = :title,
                        author = :author,
                        publisher = :publisher,
                        publication_year = :publication_year,
                        category = :category,
                        shelf_location = :shelf_location,
                        total_copies = :total_copies,
                        available_copies = :available_copies,
                        description = :description
                     WHERE id = :id"
                );

                $update->execute([
                    'isbn' => $form['isbn'],
                    'title' => $form['title'],
                    'author' => $form['author'],
                    'publisher' => $form['publisher'],
                    'publication_year' => $form['publication_year'],
                    'category' => $form['category'],
                    'shelf_location' => $form['shelf_location'],
                    'total_copies' => $newTotal,
                    'available_copies' => $newAvailable,
                    'description' => $form['description'],
                    'id' => $bookId
                ]);

                $pdo->commit();

                header('Location: index.php?success=updated');
                exit;
            }
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($e->getCode() === '23000') {
                $errors[] = 'That ISBN is already registered to another book.';
            } else {
                error_log($e->getMessage());
                $errors[] = 'Unable to update the book. Please try again.';
            }
        } catch (RuntimeException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $errors[] = $e->getMessage();
        }
    }
}

$currentBorrowed =
    (int)$book['total_copies'] - (int)$book['available_copies'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book | Seminary Library</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 20px;
            background: #f3f6f4;
            color: #26352c;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 850px;
            margin: 25px auto;
        }

        .header {
            background: #145c37;
            color: white;
            padding: 22px;
            border-radius: 10px 10px 0 0;
        }

        .header h1 {
            margin: 0 0 8px;
        }

        .header p {
            margin: 0;
            color: #e0eee5;
        }

        .form-box {
            background: white;
            padding: 24px;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 3px 12px #00000010;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .field {
            margin-bottom: 16px;
        }

        .full {
            grid-column: 1 / -1;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccd5ce;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        .info {
            padding: 12px;
            margin-bottom: 20px;
            background: #eaf4ed;
            border-left: 4px solid #25834d;
            border-radius: 4px;
        }

        .errors {
            background: #ffe9e9;
            color: #8b1e1e;
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

        .errors li {
            margin-bottom: 6px;
        }

        .actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 10px;
        }

        .btn {
            display: inline-block;
            padding: 12px 18px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-size: 15px;
        }

        .save {
            background: #17683e;
            color: white;
        }

        .cancel {
            background: #e5e9e6;
            color: #26352c;
        }

        @media (max-width: 600px) {
            .grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }

            body {
                padding: 12px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <div class="header">
        <h1>Edit Book</h1>
        <p>Update the catalogue details for this book.</p>
    </div>

    <div class="form-box">

        <div class="info">
            <strong>Copies currently borrowed:</strong>
            <?= $currentBorrowed ?>
            <br>
            <strong>Copies currently available:</strong>
            <?= (int)$book['available_copies'] ?>
        </div>

        <?php if ($errors): ?>
            <div class="errors">
                <strong>Please correct the following:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= h($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="grid">

                <div class="field">
                    <label for="title">Book Title *</label>
                    <input
                        type="text"
                        id="title"
                        name="title"
                        maxlength="200"
                        value="<?= h($form['title']) ?>"
                        required
                    >
                </div>

                <div class="field">
                    <label for="author">Author *</label>
                    <input
                        type="text"
                        id="author"
                        name="author"
                        maxlength="150"
                        value="<?= h($form['author']) ?>"
                        required
                    >
                </div>

                <div class="field">
                    <label for="isbn">ISBN</label>
                    <input
                        type="text"
                        id="isbn"
                        name="isbn"
                        maxlength="30"
                        value="<?= h($form['isbn']) ?>"
                    >
                </div>

                <div class="field">
                    <label for="publisher">Publisher</label>
                    <input
                        type="text"
                        id="publisher"
                        name="publisher"
                        maxlength="150"
                        value="<?= h($form['publisher']) ?>"
                    >
                </div>

                <div class="field">
                    <label for="publication_year">Publication Year</label>
                    <input
                        type="number"
                        id="publication_year"
                        name="publication_year"
                        min="1"
                        max="<?= (int)date('Y') + 1 ?>"
                        value="<?= h($form['publication_year']) ?>"
                    >
                </div>

                <div class="field">
                    <label for="category">Category</label>
                    <input
                        type="text"
                        id="category"
                        name="category"
                        maxlength="100"
                        value="<?= h($form['category']) ?>"
                        placeholder="Philosophy, Theology, Bible..."
                    >
                </div>

                <div class="field">
                    <label for="shelf_location">Shelf Location</label>
                    <input
                        type="text"
                        id="shelf_location"
                        name="shelf_location"
                        maxlength="100"
                        value="<?= h($form['shelf_location']) ?>"
                        placeholder="e.g. Shelf A2"
                    >
                </div>

                <div class="field">
                    <label for="total_copies">Total Copies *</label>
                    <input
                        type="number"
                        id="total_copies"
                        name="total_copies"
                        min="<?= max(1, $currentBorrowed) ?>"
                        value="<?= h($form['total_copies']) ?>"
                        required
                    >
                </div>

                <div class="field full">
                    <label for="description">Description / Notes</label>
                    <textarea
                        id="description"
                        name="description"
                    ><?= h($form['description']) ?></textarea>
                </div>

            </div>

            <div class="actions">
                <button type="submit" class="btn save">
                    Save Changes
                </button>

                <a href="index.php" class="btn cancel">
                    Cancel
                </a>
            </div>
        </form>

    </div>
</div>
</body>
</html>
