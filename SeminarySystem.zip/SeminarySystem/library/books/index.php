<?php

declare(strict_types=1);

require_once __DIR__ . '/../library_permissions.php';

/*
|--------------------------------------------------------------------------
| Access control
|--------------------------------------------------------------------------
| All users assigned to the Library department can view the catalogue.
| Only librarians and authorized administrators can add or edit books.
*/

requireDepartmentAccess('Library');

$isLibraryManager = isLibraryManager();

/*
|--------------------------------------------------------------------------
| Database connection
|--------------------------------------------------------------------------
| database.php is loaded through department_auth.php.
| The PDO connection is expected to be available as $pdo.
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable. Please contact the system administrator.');
}

/*
|--------------------------------------------------------------------------
| Helper function
|--------------------------------------------------------------------------
*/

function escapeHtml(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| Pagination settings
|--------------------------------------------------------------------------
*/

$perPage = 10;

$page = filter_input(
    INPUT_GET,
    'page',
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1]]
);

$page = $page ?: 1;

/*
|--------------------------------------------------------------------------
| Search and category filters
|--------------------------------------------------------------------------
*/

$search = trim((string) ($_GET['search'] ?? ''));
$category = trim((string) ($_GET['category'] ?? ''));

$conditions = ["status = 'active'"];
$params = [];

if ($search !== '') {
    $conditions[] = '(
        title LIKE :title
        OR author LIKE :author
        OR isbn LIKE :isbn
        OR publisher LIKE :publisher
    )';

    $searchTerm = '%' . $search . '%';

    $params[':title'] = $searchTerm;
    $params[':author'] = $searchTerm;
    $params[':isbn'] = $searchTerm;
    $params[':publisher'] = $searchTerm;
}

if ($category !== '') {
    $conditions[] = 'category = :category';
    $params[':category'] = $category;
}

$whereSql = implode(' AND ', $conditions);

/*
|--------------------------------------------------------------------------
| Get total number of matching books
|--------------------------------------------------------------------------
*/

$countSql = "
    SELECT COUNT(*)
    FROM books
    WHERE {$whereSql}
";

$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);

$totalBooks = (int) $countStmt->fetchColumn();

$totalPages = max(1, (int) ceil($totalBooks / $perPage));

$page = min($page, $totalPages);

$offset = ($page - 1) * $perPage;

/*
|--------------------------------------------------------------------------
| Get matching books
|--------------------------------------------------------------------------
*/

$booksSql = "
    SELECT
        id,
        isbn,
        title,
        author,
        publisher,
        publication_year,
        category,
        shelf_location,
        total_copies,
        available_copies,
        description
    FROM books
    WHERE {$whereSql}
    ORDER BY title ASC
    LIMIT :limit OFFSET :offset
";

$booksStmt = $pdo->prepare($booksSql);

foreach ($params as $key => $value) {
    $booksStmt->bindValue($key, $value, PDO::PARAM_STR);
}

$booksStmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$booksStmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$booksStmt->execute();

$books = $booksStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Get categories for the filter
|--------------------------------------------------------------------------
*/

$categoryStmt = $pdo->query("
    SELECT DISTINCT category
    FROM books
    WHERE status = 'active'
      AND category IS NOT NULL
      AND category <> ''
    ORDER BY category ASC
");

$categories = $categoryStmt->fetchAll(PDO::FETCH_COLUMN);

/*
|--------------------------------------------------------------------------
| Catalogue statistics
|--------------------------------------------------------------------------
*/

$statsStmt = $pdo->query("
    SELECT
        COUNT(*) AS total_titles,
        COALESCE(SUM(total_copies), 0) AS total_copies,
        COALESCE(SUM(available_copies), 0) AS available_copies
    FROM books
    WHERE status = 'active'
");

$stats = $statsStmt->fetch(PDO::FETCH_ASSOC) ?: [
    'total_titles' => 0,
    'total_copies' => 0,
    'available_copies' => 0,
];

$totalTitles = (int) $stats['total_titles'];
$totalCopies = (int) $stats['total_copies'];
$availableCopies = (int) $stats['available_copies'];
$borrowedCopies = max(0, $totalCopies - $availableCopies);

/*
|--------------------------------------------------------------------------
| Navigation
|--------------------------------------------------------------------------
*/

$dashboardUrl = $isLibraryManager
    ? '../librarian_dashboard.php'
    : '../dashboard.php';

$dashboardLabel = $isLibraryManager
    ? 'Librarian Dashboard'
    : 'Library Dashboard';

$displayName = $_SESSION['full_name']
    ?? $_SESSION['username']
    ?? 'Library User';

/*
|--------------------------------------------------------------------------
| Flash messages
|--------------------------------------------------------------------------
*/

$successMessage = '';

if (isset($_GET['success'])) {
    $successMessages = [
        'created' => 'Book added successfully.',
        'updated' => 'Book details updated successfully.',
    ];

    $successMessage = $successMessages[(string) $_GET['success']] ?? '';
}

$errorMessage = '';

if (isset($_GET['error'])) {
    $errorMessages = [
        'not_found' => 'The requested book could not be found.',
        'invalid' => 'The requested action could not be completed.',
    ];

    $errorMessage = $errorMessages[(string) $_GET['error']] ?? '';
}

/*
|--------------------------------------------------------------------------
| Build pagination URLs while preserving filters
|--------------------------------------------------------------------------
*/

function cataloguePageUrl(int $pageNumber, string $search, string $category): string
{
    $query = [
        'page' => $pageNumber,
    ];

    if ($search !== '') {
        $query['search'] = $search;
    }

    if ($category !== '') {
        $query['category'] = $category;
    }

    return '?' . http_build_query($query);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Book Catalogue | Seminary Library</title>

    <style>
        :root {
            --primary: #173b2c;
            --primary-light: #24563f;
            --accent: #d4ad55;
            --background: #f4f6f5;
            --white: #ffffff;
            --text: #26352d;
            --muted: #718078;
            --border: #e1e8e3;
            --success: #18794e;
            --danger: #b42318;
            --shadow: 0 5px 20px rgba(23, 59, 44, 0.07);
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: var(--background);
            color: var(--text);
            line-height: 1.5;
        }

        a {
            text-decoration: none;
        }

        .topbar {
            background: var(--primary);
            color: white;
            padding: 16px 22px;
        }

        .topbar-inner {
            max-width: 1400px;
            margin: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        .brand {
            font-size: 20px;
            font-weight: bold;
        }

        .brand small {
            display: block;
            font-size: 12px;
            font-weight: normal;
            color: #dce9e0;
            margin-top: 3px;
        }

        .user-info {
            font-size: 13px;
            color: #e5eee8;
        }

        .container {
            max-width: 1400px;
            margin: 25px auto;
            padding: 0 18px;
        }

        .breadcrumbs {
            font-size: 13px;
            color: var(--muted);
            margin-bottom: 18px;
        }

        .breadcrumbs a {
            color: var(--primary-light);
        }

        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
            margin-bottom: 22px;
        }

        .page-heading h1 {
            margin: 0 0 5px;
            font-size: 28px;
            color: var(--primary);
        }

        .page-heading p {
            margin: 0;
            color: var(--muted);
            font-size: 14px;
        }

        .actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 10px 15px;
            border-radius: 7px;
            font-size: 13px;
            font-weight: bold;
            border: none;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-light);
        }

        .btn-light {
            background: white;
            color: var(--primary);
            border: 1px solid var(--border);
        }

        .btn-light:hover {
            background: #edf3ef;
        }

        .btn-edit {
            background: #fff5dc;
            color: #795500;
            padding: 7px 11px;
        }

        .btn-edit:hover {
            background: #f8e6b4;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 15px;
            margin-bottom: 22px;
        }

        .stat-card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 18px;
            box-shadow: var(--shadow);
        }

        .stat-label {
            font-size: 12px;
            color: var(--muted);
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 27px;
            font-weight: bold;
            color: var(--primary);
        }

        .panel {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: var(--shadow);
            margin-bottom: 22px;
            overflow: hidden;
        }

        .panel-heading {
            padding: 18px 20px;
            border-bottom: 1px solid var(--border);
        }

        .panel-heading h2 {
            margin: 0;
            color: var(--primary);
            font-size: 17px;
        }

        .panel-heading p {
            margin: 5px 0 0;
            color: var(--muted);
            font-size: 13px;
        }

        .filters {
            padding: 18px 20px;
            display: grid;
            grid-template-columns: minmax(180px, 2fr) minmax(160px, 1fr) auto auto;
            gap: 12px;
            align-items: end;
        }

        .form-group label {
            display: block;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 6px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            min-height: 42px;
            padding: 10px;
            border: 1px solid #cfd9d2;
            border-radius: 6px;
            background: white;
            font-size: 14px;
            color: var(--text);
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: 2px solid #d4e4d8;
            border-color: var(--primary-light);
        }

        .alert {
            border-radius: 7px;
            padding: 12px 15px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .alert-success {
            color: var(--success);
            background: #e8f7ef;
            border: 1px solid #b7e5ca;
        }

        .alert-error {
            color: var(--danger);
            background: #fff0ef;
            border: 1px solid #f3c5c1;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th,
        td {
            text-align: left;
            padding: 13px 16px;
            border-bottom: 1px solid #edf0ee;
            font-size: 13px;
            vertical-align: middle;
        }

        th {
            background: #f8faf8;
            color: #596a60;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        tbody tr:hover {
            background: #fafcfb;
        }

        .book-title {
            color: var(--primary);
            font-weight: bold;
            font-size: 14px;
        }

        .book-subtitle {
            display: block;
            color: var(--muted);
            font-size: 12px;
            margin-top: 3px;
        }

        .badge {
            display: inline-block;
            padding: 5px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
        }

        .badge-available {
            background: #e4f6eb;
            color: #176b42;
        }

        .badge-unavailable {
            background: #fff0ef;
            color: #a52820;
        }

        .badge-category {
            background: #eef2f8;
            color: #344f7a;
        }

        .empty-state {
            text-align: center;
            padding: 45px 20px;
        }

        .empty-state h3 {
            color: var(--primary);
            margin: 0 0 8px;
        }

        .empty-state p {
            color: var(--muted);
            font-size: 13px;
            margin: 0 0 18px;
        }

        .pagination {
            padding: 18px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
        }

        .pagination-info {
            color: var(--muted);
            font-size: 12px;
        }

        .pagination-links {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }

        .page-link {
            display: inline-block;
            min-width: 35px;
            padding: 8px 10px;
            text-align: center;
            border: 1px solid var(--border);
            border-radius: 5px;
            background: white;
            color: var(--primary);
            font-size: 12px;
        }

        .page-link.active {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
        }

        .page-link.disabled {
            color: #a6b0a9;
            pointer-events: none;
            background: #f7f8f7;
        }

        .footer {
            text-align: center;
            color: var(--muted);
            font-size: 12px;
            padding: 25px 10px;
        }

        @media (max-width: 850px) {
            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .filters {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 520px) {
            .container {
                margin-top: 18px;
                padding: 0 12px;
            }

            .page-heading h1 {
                font-size: 23px;
            }

            .stats {
                gap: 10px;
            }

            .stat-card {
                padding: 13px;
            }

            .stat-value {
                font-size: 23px;
            }

            .filters {
                grid-template-columns: 1fr;
                padding: 15px;
            }

            .filters .btn {
                width: 100%;
            }

            .panel-heading {
                padding: 15px;
            }

            .pagination {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<header class="topbar">
    <div class="topbar-inner">

        <div class="brand">
            Seminary Library
            <small>Book Catalogue and Resources</small>
        </div>

        <div class="user-info">
            Signed in as:
            <strong><?= escapeHtml($displayName) ?></strong>
        </div>

    </div>
</header>

<main class="container">

    <div class="breadcrumbs">
        <a href="<?= escapeHtml($dashboardUrl) ?>">
            <?= escapeHtml($dashboardLabel) ?>
        </a>
        &nbsp; / &nbsp;
        Book Catalogue
    </div>

    <section class="page-heading">

        <div>
            <h1>Book Catalogue</h1>
            <p>
                Search, browse and check the availability of library books.
            </p>
        </div>

        <div class="actions">

            <a
                class="btn btn-light"
                href="<?= escapeHtml($dashboardUrl) ?>"
            >
                ← Back to Dashboard
            </a>

            <?php if ($isLibraryManager): ?>

                <a class="btn btn-primary" href="create.php">
                    + Add New Book
                </a>

            <?php endif; ?>

        </div>

    </section>

    <?php if ($successMessage !== ''): ?>

        <div class="alert alert-success">
            <?= escapeHtml($successMessage) ?>
        </div>

    <?php endif; ?>

    <?php if ($errorMessage !== ''): ?>

        <div class="alert alert-error">
            <?= escapeHtml($errorMessage) ?>
        </div>

    <?php endif; ?>

    <!-- Catalogue statistics -->

    <section class="stats">

        <div class="stat-card">
            <div class="stat-label">Book Titles</div>
            <div class="stat-value">
                <?= number_format($totalTitles) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Total Copies</div>
            <div class="stat-value">
                <?= number_format($totalCopies) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Available Copies</div>
            <div class="stat-value">
                <?= number_format($availableCopies) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Borrowed Copies</div>
            <div class="stat-value">
                <?= number_format($borrowedCopies) ?>
            </div>
        </div>

    </section>

    <!-- Search and filters -->

    <section class="panel">

        <div class="panel-heading">
            <h2>Find a Book</h2>
            <p>
                Search by title, author, ISBN or publisher.
            </p>
        </div>

        <form method="GET" action="index.php" class="filters">

            <div class="form-group">
                <label for="search">Search</label>

                <input
                    type="search"
                    id="search"
                    name="search"
                    value="<?= escapeHtml($search) ?>"
                    placeholder="Enter title, author or ISBN..."
                >
            </div>

            <div class="form-group">
                <label for="category">Category</label>

                <select id="category" name="category">

                    <option value="">All categories</option>

                    <?php foreach ($categories as $item): ?>

                        <option
                            value="<?= escapeHtml($item) ?>"
                            <?= $category === $item ? 'selected' : '' ?>
                        >
                            <?= escapeHtml($item) ?>
                        </option>

                    <?php endforeach; ?>

                </select>
            </div>

            <button class="btn btn-primary" type="submit">
                Search Books
            </button>

            <a class="btn btn-light" href="index.php">
                Clear Filters
            </a>

        </form>

    </section>

    <!-- Books table -->

    <section class="panel">

        <div class="panel-heading">
            <h2>Library Collection</h2>

            <p>
                <?= number_format($totalBooks) ?>
                matching book<?= $totalBooks === 1 ? '' : 's' ?> found.
            </p>
        </div>

        <?php if (empty($books)): ?>

            <div class="empty-state">

                <h3>No Books Found</h3>

                <p>
                    No active books match your search or selected category.
                </p>

                <?php if ($search !== '' || $category !== ''): ?>

                    <a class="btn btn-light" href="index.php">
                        Clear Search
                    </a>

                <?php elseif ($isLibraryManager): ?>

                    <a class="btn btn-primary" href="create.php">
                        + Add Your First Book
                    </a>

                <?php endif; ?>

            </div>

        <?php else: ?>

            <div class="table-wrapper">

                <table>

                    <thead>
                        <tr>
                            <th>Book Details</th>
                            <th>Author</th>
                            <th>Category</th>
                            <th>Shelf</th>
                            <th>Copies</th>
                            <th>Availability</th>

                            <?php if ($isLibraryManager): ?>
                                <th>Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($books as $book): ?>

                            <?php
                            $available = (int) $book['available_copies'];
                            $total = (int) $book['total_copies'];
                            ?>

                            <tr>

                                <td>
                                    <span class="book-title">
                                        <?= escapeHtml($book['title']) ?>
                                    </span>

                                    <span class="book-subtitle">
                                        ISBN:
                                        <?= escapeHtml($book['isbn'] ?: 'Not provided') ?>
                                    </span>

                                    <?php if (!empty($book['publisher'])): ?>
                                        <span class="book-subtitle">
                                            Publisher:
                                            <?= escapeHtml($book['publisher']) ?>
                                        </span>
                                    <?php endif; ?>

                                    <?php if (!empty($book['publication_year'])): ?>
                                        <span class="book-subtitle">
                                            Year:
                                            <?= escapeHtml($book['publication_year']) ?>
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?= escapeHtml($book['author']) ?>
                                </td>

                                <td>
                                    <?php if (!empty($book['category'])): ?>

                                        <span class="badge badge-category">
                                            <?= escapeHtml($book['category']) ?>
                                        </span>

                                    <?php else: ?>

                                        <span class="book-subtitle">
                                            Not specified
                                        </span>

                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?= escapeHtml($book['shelf_location'] ?: 'Not assigned') ?>
                                </td>

                                <td>
                                    <?= number_format($available) ?>
                                    /
                                    <?= number_format($total) ?>
                                </td>

                                <td>

                                    <?php if ($available > 0): ?>

                                        <span class="badge badge-available">
                                            Available
                                        </span>

                                    <?php else: ?>

                                        <span class="badge badge-unavailable">
                                            Not Available
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <?php if ($isLibraryManager): ?>

                                    <td>
                                        <a
                                            class="btn btn-edit"
                                            href="edit.php?id=<?= (int) $book['id'] ?>"
                                        >
                                            Edit
                                        </a>
                                    </td>

                                <?php endif; ?>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

            <!-- Pagination -->

            <div class="pagination">

                <div class="pagination-info">

                    Showing
                    <?= $totalBooks > 0 ? number_format($offset + 1) : '0' ?>
                    –
                    <?= number_format(min($offset + $perPage, $totalBooks)) ?>
                    of
                    <?= number_format($totalBooks) ?>

                </div>

                <?php if ($totalPages > 1): ?>

                    <div class="pagination-links">

                        <a
                            class="page-link <?= $page <= 1 ? 'disabled' : '' ?>"
                            href="<?= escapeHtml(cataloguePageUrl(max(1, $page - 1), $search, $category)) ?>"
                        >
                            Previous
                        </a>

                        <?php
                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);
                        ?>

                        <?php for ($i = $startPage; $i <= $endPage; $i++): ?>

                            <a
                                class="page-link <?= $i === $page ? 'active' : '' ?>"
                                href="<?= escapeHtml(cataloguePageUrl($i, $search, $category)) ?>"
                            >
                                <?= $i ?>
                            </a>

                        <?php endfor; ?>

                        <a
                            class="page-link <?= $page >= $totalPages ? 'disabled' : '' ?>"
                            href="<?= escapeHtml(cataloguePageUrl(min($totalPages, $page + 1), $search, $category)) ?>"
                        >
                            Next
                        </a>

                    </div>

                <?php endif; ?>

            </div>

        <?php endif; ?>

    </section>

    <footer class="footer">
        Seminary Management System &bull; Library Department
    </footer>

</main>

</body>
</html>