<?php

require_once __DIR__ . '/../includes/department_auth.php';

if (!function_exists('isLibraryManager')) {
    function isLibraryManager(): bool
    {
        $role = $_SESSION['role'] ?? '';

        return in_array(
            $role,
            ['librarian', 'super_admin', 'rector', 'admin'],
            true
        );
    }
}

if (!function_exists('requireLibraryManager')) {
    function requireLibraryManager(): void
    {
        requireDepartmentAccess('Library');

        if (!isLibraryManager()) {
            http_response_code(403);
            exit(
                'Access denied. Only the librarian or an authorized administrator can perform this action.'
            );
        }
    }
}
