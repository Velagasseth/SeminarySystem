<?php

require_once __DIR__ . '/library_permissions.php';
requireLibraryManager();

if (!function_exists('h')) {
    function h($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Library statistics
|--------------------------------------------------------------------------
*/

$totalTitles = 0;
$totalCopies = 0;
$availableCopies = 0;
$borrowedBooks = 0;
$overdueBooks = 0;

try {
    $stmt = $pdo->query(
        "SELECT
            COUNT(*) AS total_titles,
            COALESCE(SUM(total_copies), 0) AS total_copies,
            COALESCE(SUM(available_copies), 0) AS available_copies
         FROM books
         WHERE status = 'active'"
    );

    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($stats) {
        $totalTitles = (int)$stats['total_titles'];
        $totalCopies = (int)$stats['total_copies'];
        $availableCopies = (int)$stats['available_copies'];
    }

    $stmt = $pdo->query(
        "SELECT COUNT(*)
         FROM book_borrowings
         WHERE status IN ('borrowed', 'overdue')"
    );

    $borrowedBooks = (int)$stmt->fetchColumn();

    $stmt = $pdo->query(
    "SELECT COUNT(*)
     FROM book_borrowings
     WHERE status IN ('borrowed', 'overdue')
       AND due_date < CURDATE()
       AND returned_at IS NULL"
);

$overdueBooks = (int)$stmt->fetchColumn();

} catch (PDOException $e) {
    error_log($e->getMessage());
}

/*
|--------------------------------------------------------------------------
| Current user information
|--------------------------------------------------------------------------
*/

$librarianName = $_SESSION['full_name']
    ?? $_SESSION['username']
    ?? 'Librarian';

$role = $_SESSION['role'] ?? 'seminarian';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Librarian Dashboard | Seminary Library</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f3f6f4;
            color: #25372c;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: 245px;
            background: #104a2d;
            color: white;
            padding: 25px 16px;
            overflow-y: auto;
        }

        .brand {
            padding: 0 10px 25px;
            border-bottom: 1px solid #ffffff25;
        }

        .brand h2 {
            margin: 0 0 7px;
            font-size: 23px;
        }

        .brand p {
            margin: 0;
            color: #d5e7da;
            font-size: 13px;
        }

        .menu-title {
            margin: 25px 10px 10px;
            color: #c2d9ca;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sidebar a {
            display: block;
            padding: 12px;
            margin-bottom: 5px;
            color: #f0f7f2;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
        }

        .sidebar a:hover {
            background: #226542;
        }

        .sidebar a.active {
            background: #dceee2;
            color: #104a2d;
            font-weight: bold;
        }

        .main {
            margin-left: 245px;
            padding: 25px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .topbar h1 {
            margin: 0 0 7px;
            font-size: 27px;
        }

        .topbar p {
            margin: 0;
            color: #68776d;
        }

        .user-info {
            padding: 12px 16px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px #00000008;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 28px;
        }

        .stat {
            background: white;
            padding: 22px;
            border-radius: 10px;
            border-left: 4px solid #247449;
            box-shadow: 0 2px 10px #00000008;
        }

        .stat-label {
            color: #6b786f;
            font-size: 13px;
        }

        .stat-number {
            display: block;
            margin-top: 12px;
            font-size: 29px;
            font-weight: bold;
        }

        .section-title {
            margin: 28px 0 15px;
            font-size: 20px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 2px 10px #00000008;
        }

        .card-icon {
            font-size: 28px;
            margin-bottom: 12px;
        }

        .card h3 {
            margin: 0 0 10px;
            font-size: 17px;
        }

        .card p {
            min-height: 40px;
            margin: 0 0 18px;
            color: #6b786f;
            font-size: 13px;
            line-height: 1.6;
        }

        .button {
            display: inline-block;
            padding: 11px 14px;
            background: #17683e;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 13px;
        }

        .button:hover {
            background: #104a2d;
        }

        .warning {
            border-left-color: #c53b36;
        }

        .warning .stat-number {
            color: #b72d2d;
        }

        .footer {
            margin-top: 35px;
            padding: 20px 0;
            color: #7a867e;
            font-size: 12px;
            border-top: 1px solid #dfe6e1;
        }

        @media (max-width: 1100px) {
            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .cards {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 700px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
                bottom: auto;
            }

            .main {
                margin-left: 0;
                padding: 16px;
            }

            .stats,
            .cards {
                grid-template-columns: 1fr;
            }

            .topbar h1 {
                font-size: 23px;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">

    <div class="brand">
        <h2>📚 Seminary Library</h2>
        <p>Library Management Portal</p>
    </div>

    <div class="menu-title">Main Menu</div>

    <a href="dashboard.php" class="active">
        🏠 Dashboard
    </a>

    <a href="books/index.php">
        📚 Book Catalogue
    </a>

    <a href="books/create.php">
        ➕ Add New Book
    </a>

    <a href="borrowings/index.php">
        📖 Issue Books
    </a>

    <div class="menu-title">Library Operations</div>

<a href="borrowings/index.php">
    ⏰ Borrowing Records
</a>

<a href="borrowings/requests.php">
    📥 Manage Book Requests
</a>

<a href="borrowings/seminarian_history.php">
    👨‍🎓 Seminarian Borrowing History
</a>

<a href="borrowings/index.php?status=overdue">
    ⚠️ Overdue Books
</a>

    <div class="menu-title">System</div>

    <a href="../index.php">
        🌐 Main Website
    </a>

    <a href="../admin/logout.php">
        🚪 Log Out
    </a>

</aside>

<main class="main">

    <header class="topbar">

        <div>
            <h1>Librarian Dashboard</h1>
            <p>Manage books, borrowing records and library resources.</p>
        </div>

        <div class="user-info">
            👤 <?= h($librarianName) ?>
        </div>

    </header>

    <section class="stats">

        <div class="stat">
            <span class="stat-label">Book Titles</span>
            <span class="stat-number">
                <?= number_format($totalTitles) ?>
            </span>
        </div>

        <div class="stat">
            <span class="stat-label">Total Copies</span>
            <span class="stat-number">
                <?= number_format($totalCopies) ?>
            </span>
        </div>

        <div class="stat">
            <span class="stat-label">Available Copies</span>
            <span class="stat-number">
                <?= number_format($availableCopies) ?>
            </span>
        </div>

        <div class="stat warning">
            <span class="stat-label">Overdue Books</span>
            <span class="stat-number">
                <?= number_format($overdueBooks) ?>
            </span>
        </div>

    </section>

    <h2 class="section-title">Book Management</h2>

    <section class="cards">

        <article class="card">
            <div class="card-icon">➕</div>
            <h3>Add New Book</h3>
            <p>
                Register new books, enter author details,
                assign categories and record copies.
            </p>
            <a class="button" href="books/create.php">
                Add Book
            </a>
        </article>

        <article class="card">
            <div class="card-icon">📚</div>
            <h3>Book Catalogue</h3>
            <p>
                Search, browse and edit books already
                registered in the library.
            </p>
            <a class="button" href="books/index.php">
                Open Catalogue
            </a>
        </article>

        <article class="card">
            <div class="card-icon">📖</div>
            <h3>Issue a Book</h3>
            <p>
                Register a book borrowed by a seminarian
                and set the return deadline.
            </p>
            <a class="button" href="borrowings/index.php">
                Issue Book
            </a>
        </article>
        
        <article class="card">
    <div class="card-icon">📥</div>
    <h3>Book Requests</h3>
    <p>
        Review requests submitted by seminarians,
        approve or reject them, and issue approved books.
    </p>
    <a class="button" href="borrowings/requests.php">
        Manage Requests
    </a>
</article>
        
        <article class="card">
    <div class="card-icon">↩️</div>
    <h3>Book Returns</h3>
    <p>
        Open the return management page to process
        returned books and update their records.
    </p>
    <a class="button" href="borrowings/return.php">
        Manage Returns
    </a>
</article>

     

        <article class="card">
            <div class="card-icon">⏰</div>
            <h3>Overdue Books</h3>
            <p>
                Monitor books whose return deadlines
                have passed.
            </p>
            <a class="button" href="borrowings/index.php">
                Check Overdue
            </a>
        </article>

        <article class="card">
            <div class="card-icon">📊</div>
            <h3>Library Statistics</h3>
            <p>
                Review the catalogue size, available
                copies and outstanding loans.
            </p>
            <a class="button" href="books/index.php">
                View Catalogue
            </a>
        </article>

    </section>

    <div class="footer">
        Seminary Management System · Library Department
    </div>

</main>

</body>
</html>
