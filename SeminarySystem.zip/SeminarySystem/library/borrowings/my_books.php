<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/department_auth.php';

/*
|--------------------------------------------------------------------------
| Seminarian-only access
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'seminarian') {
    http_response_code(403);
    exit('Access denied. This page is for seminarians only.');
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

/*
|--------------------------------------------------------------------------
| Helper function
|--------------------------------------------------------------------------
*/

function myBooksEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Get the logged-in seminarian's information
|--------------------------------------------------------------------------
*/

$userId = (int) $_SESSION['user_id'];

$fullName = $_SESSION['full_name'] ?? 'Seminarian';

/*
|--------------------------------------------------------------------------
| Retrieve ONLY this seminarian's borrowing records
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        bb.id,
        bb.borrowed_at,
        bb.due_date,
        bb.returned_at,
        bb.status,
        b.title,
        b.author,
        b.isbn,
        b.shelf_location,
        CASE
            WHEN bb.returned_at IS NOT NULL
                THEN 'returned'
            WHEN bb.due_date < CURDATE()
                THEN 'overdue'
            ELSE 'borrowed'
        END AS current_status
    FROM book_borrowings bb
    INNER JOIN books b
        ON b.id = bb.book_id
    WHERE bb.user_id = :user_id
    ORDER BY
        CASE
            WHEN bb.returned_at IS NULL THEN 0
            ELSE 1
        END,
        bb.due_date ASC,
        bb.borrowed_at DESC
");

$stmt->execute([
    ':user_id' => $userId
]);

$borrowings = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Calculate statistics
|--------------------------------------------------------------------------
*/

$totalBorrowed = count($borrowings);
$currentlyBorrowed = 0;
$overdueBooks = 0;
$returnedBooks = 0;

foreach ($borrowings as $book) {
    if ($book['current_status'] === 'returned') {
        $returnedBooks++;
    } elseif ($book['current_status'] === 'overdue') {
        $overdueBooks++;
        $currentlyBorrowed++;
    } else {
        $currentlyBorrowed++;
    }
}

$success = $_GET['success'] ?? '';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Borrowed Books | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 22px;
        }

        header h1 {
            margin: 0 0 8px;
            font-size: 23px;
        }

        header p {
            margin: 0;
            color: #d1fae5;
            font-size: 14px;
        }

        nav {
            background: white;
            padding: 14px 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        nav a {
            color: #166534;
            font-weight: bold;
            text-decoration: none;
            margin-right: 18px;
        }

        main {
            max-width: 1150px;
            margin: auto;
            padding: 24px 16px;
        }

        .welcome {
            margin-bottom: 22px;
        }

        .welcome h2 {
            color: #123b2a;
        }

        .stats {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .stat {
            background: white;
            padding: 20px;
            border-radius: 9px;
            box-shadow: 0 2px 7px rgba(0, 0, 0, .05);
        }

        .stat h3 {
            margin: 0 0 10px;
            font-size: 14px;
            color: #64748b;
        }

        .stat strong {
            font-size: 28px;
            color: #14532d;
        }

        .panel {
            background: white;
            padding: 20px;
            border-radius: 9px;
            box-shadow: 0 2px 7px rgba(0, 0, 0, .05);
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 750px;
        }

        th,
        td {
            text-align: left;
            padding: 13px 10px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 14px;
        }

        th {
            background: #f8fafc;
            color: #334155;
        }

        .badge {
            display: inline-block;
            padding: 6px 9px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .borrowed {
            background: #dbeafe;
            color: #1d4ed8;
        }

        .overdue {
            background: #fee2e2;
            color: #b91c1c;
        }

        .returned {
            background: #dcfce7;
            color: #166534;
        }

        .notice {
            background: #fffbeb;
            border-left: 4px solid #d97706;
            padding: 14px;
            margin-bottom: 20px;
            border-radius: 5px;
            line-height: 1.6;
        }

        .empty {
            text-align: center;
            padding: 35px 15px;
            color: #64748b;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
            font-size: 13px;
        }

        @media (max-width: 600px) {
            header h1 {
                font-size: 20px;
            }

            .panel {
                padding: 12px;
            }
        }
    </style>
</head>

<body>

<header>
    <h1>📚 My Borrowed Books</h1>

    <p>
        Seminary Management System — Personal Library Account
    </p>
</header>

<nav>
    <a href="../dashboard.php">Library Dashboard</a>
    <a href="../../index.php">Main Website</a>
    <a href="../../admin/logout.php">Log Out</a>
</nav>

<main>

    <section class="welcome">
        <h2>
            Welcome, <?= myBooksEscape($fullName) ?>!
        </h2>

        <p>
            Here you can view the books you have borrowed,
            their due dates, and your return history.
        </p>
    </section>

    <?php if ($success === 'returned'): ?>

        <div class="success">
            Your book return has been recorded.
        </div>

    <?php endif; ?>

    <div class="notice">
        <strong>Important:</strong>
        Return borrowed books to the librarian on or before
        their due dates. If a book is overdue, contact the
        librarian to arrange its return.
    </div>

    <section class="stats">

        <article class="stat">
            <h3>Total Borrowing Records</h3>
            <strong><?= $totalBorrowed ?></strong>
        </article>

        <article class="stat">
            <h3>Currently Borrowed</h3>
            <strong><?= $currentlyBorrowed ?></strong>
        </article>

        <article class="stat">
            <h3>Overdue Books</h3>
            <strong><?= $overdueBooks ?></strong>
        </article>

        <article class="stat">
            <h3>Returned Books</h3>
            <strong><?= $returnedBooks ?></strong>
        </article>

    </section>

    <section class="panel">

        <h2>My Borrowing History</h2>

        <?php if (empty($borrowings)): ?>

            <div class="empty">
                <h3>No borrowing records found</h3>

                <p>
                    You have no recorded book borrowings yet.
                    Contact the librarian if you believe
                    this information is incorrect.
                </p>
            </div>

        <?php else: ?>

            <div class="table-wrapper">

                <table>

                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Borrowed On</th>
                            <th>Due Date</th>
                            <th>Returned On</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($borrowings as $index => $book): ?>

                        <tr>
                            <td><?= $index + 1 ?></td>

                            <td>
                                <strong>
                                    <?= myBooksEscape($book['title']) ?>
                                </strong>

                                <?php if (!empty($book['shelf_location'])): ?>
                                    <br>

                                    <small>
                                        Shelf:
                                        <?= myBooksEscape(
                                            $book['shelf_location']
                                        ) ?>
                                    </small>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?= myBooksEscape($book['author']) ?>
                            </td>

                            <td>
                                <?= myBooksEscape(
                                    date(
                                        'd M Y',
                                        strtotime($book['borrowed_at'])
                                    )
                                ) ?>
                            </td>

                            <td>
                                <?= myBooksEscape(
                                    date(
                                        'd M Y',
                                        strtotime($book['due_date'])
                                    )
                                ) ?>
                            </td>

                            <td>
                                <?php if (!empty($book['returned_at'])): ?>

                                    <?= myBooksEscape(
                                        date(
                                            'd M Y',
                                            strtotime($book['returned_at'])
                                        )
                                    ) ?>

                                <?php else: ?>

                                    <span>Not yet returned</span>

                                <?php endif; ?>
                            </td>

                            <td>
                                <span class="badge <?= myBooksEscape(
                                    $book['current_status']
                                ) ?>">
                                    <?= myBooksEscape(
                                        ucfirst($book['current_status'])
                                    ) ?>
                                </span>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </section>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
