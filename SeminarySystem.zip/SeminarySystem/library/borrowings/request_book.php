<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/department_auth.php';

/*
|--------------------------------------------------------------------------
| Authentication and authorization
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'seminarian') {
    http_response_code(403);
    exit('Access denied. This page is for seminarians only.');
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$userId = (int) $_SESSION['user_id'];
$fullName = $_SESSION['full_name'] ?? 'Seminarian';

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function requestBookEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| CSRF protection
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

/*
|--------------------------------------------------------------------------
| Handle book request submission
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        http_response_code(403);
        exit('Invalid security token. Reload the page and try again.');
    }

    $bookId = filter_input(
        INPUT_POST,
        'book_id',
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1]]
    );

    $notes = trim((string) ($_POST['request_notes'] ?? ''));

    if (strlen($notes) > 4000) {
        header('Location: request_book.php?error=notes');
        exit;
    }

    if (!$bookId) {
        header('Location: request_book.php?error=invalid');
        exit;
    }

    try {
        $pdo->beginTransaction();

        /*
         * Lock the book row while checking eligibility.
         */

        $bookStmt = $pdo->prepare("
            SELECT id, title, available_copies
            FROM books
            WHERE id = :book_id
              AND status = 'active'
            FOR UPDATE
        ");

        $bookStmt->execute([
            ':book_id' => $bookId,
        ]);

        $book = $bookStmt->fetch(PDO::FETCH_ASSOC);

        if (!$book) {
            $pdo->rollBack();
            header('Location: request_book.php?error=unavailable');
            exit;
        }

        /*
         * Prevent duplicate pending requests.
         */

        $duplicateStmt = $pdo->prepare("
            SELECT id
            FROM book_requests
            WHERE book_id = :book_id
              AND user_id = :user_id
              AND status = 'pending'
            LIMIT 1
        ");

        $duplicateStmt->execute([
            ':book_id' => $bookId,
            ':user_id' => $userId,
        ]);

        if ($duplicateStmt->fetchColumn()) {
            $pdo->rollBack();
            header('Location: request_book.php?error=duplicate');
            exit;
        }

        /*
         * Check whether this seminarian already has an
         * outstanding request for this book.
         *
         * Approved requests also count as outstanding.
         */

        $approvedStmt = $pdo->prepare("
            SELECT id
            FROM book_requests
            WHERE book_id = :book_id
              AND user_id = :user_id
              AND status = 'approved'
            LIMIT 1
        ");

        $approvedStmt->execute([
            ':book_id' => $bookId,
            ':user_id' => $userId,
        ]);

        if ($approvedStmt->fetchColumn()) {
            $pdo->rollBack();
            header('Location: request_book.php?error=approved');
            exit;
        }

        /*
         * Create the request.
         * Available copies are NOT changed here.
         */

        $insertStmt = $pdo->prepare("
            INSERT INTO book_requests (
                book_id,
                user_id,
                status,
                request_notes
            ) VALUES (
                :book_id,
                :user_id,
                'pending',
                :request_notes
            )
        ");

        $insertStmt->execute([
            ':book_id' => $bookId,
            ':user_id' => $userId,
            ':request_notes' => $notes !== '' ? $notes : null,
        ]);

        $pdo->commit();

        header('Location: my_requests.php?success=submitted');
        exit;

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log('Book request error: ' . $e->getMessage());

        http_response_code(500);
        exit('The request could not be submitted. Please try again.');
    }
}

/*
|--------------------------------------------------------------------------
| Search catalogue
|--------------------------------------------------------------------------
*/

$search = trim((string) ($_GET['search'] ?? ''));

$sql = "
    SELECT
        b.id,
        b.title,
        b.author,
        b.category,
        b.shelf_location,
        b.available_copies,
        b.total_copies
    FROM books b
    WHERE b.status = 'active'
";

$params = [];

if ($search !== '') {
    $sql .= "
        AND (
            b.title LIKE :title
            OR b.author LIKE :author
            OR b.category LIKE :category
        )
    ";

    $term = '%' . $search . '%';

    $params = [
        ':title' => $term,
        ':author' => $term,
        ':category' => $term,
    ];
}

$sql .= " ORDER BY b.title ASC LIMIT 100";

$catalogueStmt = $pdo->prepare($sql);
$catalogueStmt->execute($params);

$books = $catalogueStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Page messages
|--------------------------------------------------------------------------
*/

$errorMessages = [
    'invalid' => 'Please select a valid book.',
    'unavailable' => 'This book is unavailable or inactive.',
    'duplicate' => 'You already have a pending request for this book.',
    'approved' => 'Your request for this book has already been approved.',
    'notes' => 'Your request message is too long.',
];

$error = $errorMessages[$_GET['error'] ?? ''] ?? '';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Request a Book | Seminary Library</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 22px;
        }

        header h1 {
            margin: 0 0 8px;
            font-size: 23px;
        }

        header p {
            margin: 0;
            color: #d1fae5;
        }

        nav {
            background: white;
            padding: 15px 20px;
            border-bottom: 1px solid #e2e8f0;
        }

        nav a {
            margin-right: 16px;
            color: #166534;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            max-width: 1100px;
            margin: auto;
            padding: 24px 16px;
        }

        .panel {
            background: white;
            padding: 20px;
            border-radius: 9px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .05);
        }

        .search-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        input[type="search"],
        textarea {
            width: 100%;
            padding: 11px;
            border: 1px solid #cbd5e1;
            border-radius: 5px;
            font: inherit;
        }

        input[type="search"] {
            flex: 1;
            min-width: 180px;
        }

        button {
            border: 0;
            border-radius: 5px;
            padding: 11px 16px;
            cursor: pointer;
            font-weight: bold;
        }

        .search-button,
        .request-button {
            background: #166534;
            color: white;
        }

        .book-grid {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(260px, 1fr));
            gap: 18px;
        }

        .book {
            background: white;
            border-radius: 9px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .05);
        }

        .book h3 {
            margin-top: 0;
            color: #14532d;
        }

        .book p {
            line-height: 1.5;
            overflow-wrap: anywhere;
        }

        .available {
            color: #166534;
            font-weight: bold;
        }

        .unavailable {
            color: #b91c1c;
            font-weight: bold;
        }

        .request-form {
            margin-top: 15px;
        }

        .request-form label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .request-form textarea {
            margin-bottom: 10px;
            resize: vertical;
            min-height: 75px;
        }

        .request-button:disabled {
            background: #94a3b8;
            cursor: not-allowed;
        }

        .alert {
            background: #fee2e2;
            color: #991b1b;
            padding: 13px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

        .empty {
            background: white;
            padding: 30px;
            text-align: center;
            border-radius: 9px;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <h1>📚 Request a Library Book</h1>
    <p>Welcome, <?= requestBookEscape($fullName) ?></p>
</header>

<nav>
    <a href="../dashboard.php">Library Dashboard</a>
    <a href="my_books.php">My Borrowed Books</a>
    <a href="my_requests.php">My Requests</a>
    <a href="../../index.php">Main Website</a>
</nav>

<main>

    <?php if ($error !== ''): ?>
        <div class="alert">
            <?= requestBookEscape($error) ?>
        </div>
    <?php endif; ?>

    <section class="panel">

        <h2>Search the Catalogue</h2>

        <p>
            Find a book and submit a request to the librarian.
            Submitting a request does not reserve a copy or
            automatically issue the book.
        </p>

        <form method="get" class="search-form">

            <input
                type="search"
                name="search"
                placeholder="Search title, author, or category..."
                value="<?= requestBookEscape($search) ?>"
            >

            <button class="search-button" type="submit">
                Search
            </button>

        </form>

    </section>

    <?php if (empty($books)): ?>

        <div class="empty">
            <h3>No books found</h3>
            <p>Try a different search term.</p>
        </div>

    <?php else: ?>

        <section class="book-grid">

            <?php foreach ($books as $book): ?>

                <article class="book">

                    <h3>
                        <?= requestBookEscape($book['title']) ?>
                    </h3>

                    <p>
                        <strong>Author:</strong>
                        <?= requestBookEscape($book['author']) ?>
                    </p>

                    <p>
                        <strong>Category:</strong>
                        <?= requestBookEscape(
                            $book['category'] ?: 'Uncategorized'
                        ) ?>
                    </p>

                    <p>
                        <strong>Shelf:</strong>
                        <?= requestBookEscape(
                            $book['shelf_location'] ?: 'Not specified'
                        ) ?>
                    </p>

                    <p class="<?= (int) $book['available_copies'] > 0
                        ? 'available'
                        : 'unavailable' ?>">

                        <?php if ((int) $book['available_copies'] > 0): ?>

                            <?= (int) $book['available_copies'] ?>
                            of <?= (int) $book['total_copies'] ?>
                            copies available

                        <?php else: ?>

                            No copies currently available

                        <?php endif; ?>

                    </p>

                    <form method="post" class="request-form">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= requestBookEscape($csrfToken) ?>"
                        >

                        <input
                            type="hidden"
                            name="book_id"
                            value="<?= (int) $book['id'] ?>"
                        >

                        <label for="notes-<?= (int) $book['id'] ?>">
                            Message to librarian (optional)
                        </label>

                        <textarea
                            id="notes-<?= (int) $book['id'] ?>"
                            name="request_notes"
                            maxlength="4000"
                            placeholder="Why do you need this book?"
                        ></textarea>

                        <button
                            class="request-button"
                            type="submit"
                        >
                            Request This Book
                        </button>

                    </form>

                </article>

            <?php endforeach; ?>

        </section>

    <?php endif; ?>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
