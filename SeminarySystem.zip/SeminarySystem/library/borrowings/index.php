<?php

declare(strict_types=1);

require_once __DIR__ . '/../library_permissions.php';

requireLibraryManager();

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

/*
|--------------------------------------------------------------------------
| Security token
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function borrowingEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Issue a book
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        http_response_code(403);
        exit('Invalid security token. Reload the page and try again.');
    }

    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'borrow') {

        $bookId = filter_input(
            INPUT_POST,
            'book_id',
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        $userId = filter_input(
            INPUT_POST,
            'user_id',
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );

        $dueDate = trim((string) ($_POST['due_date'] ?? ''));

        $validDate = DateTimeImmutable::createFromFormat(
            '!Y-m-d',
            $dueDate
        );

        $dateErrors = DateTimeImmutable::getLastErrors();

        $dateIsValid = $validDate !== false
            && (
                $dateErrors === false
                || (
                    $dateErrors['warning_count'] === 0
                    && $dateErrors['error_count'] === 0
                )
            )
            && $validDate->format('Y-m-d') === $dueDate;

        if (
            !$bookId ||
            !$userId ||
            !$dateIsValid ||
            $dueDate < date('Y-m-d')
        ) {
            header('Location: index.php?error=invalid');
            exit;
        }

        try {

            $pdo->beginTransaction();

            /*
             * Lock the selected book.
             */

            $bookStmt = $pdo->prepare("
                SELECT id, title, available_copies
                FROM books
                WHERE id = :id
                  AND status = 'active'
                FOR UPDATE
            ");

            $bookStmt->execute([
                ':id' => $bookId,
            ]);

            $book = $bookStmt->fetch(PDO::FETCH_ASSOC);

            if (!$book || (int) $book['available_copies'] < 1) {
                $pdo->rollBack();

                header('Location: index.php?error=unavailable');
                exit;
            }

            /*
             * Confirm that the borrower is an active seminarian.
             */

            $userStmt = $pdo->prepare("
                SELECT id
                FROM users
                WHERE id = :id
                  AND role = 'seminarian'
                  AND status = 'active'
                LIMIT 1
            ");

            $userStmt->execute([
                ':id' => $userId,
            ]);

            if (!$userStmt->fetchColumn()) {
                $pdo->rollBack();

                header('Location: index.php?error=invalid_borrower');
                exit;
            }

            /*
             * Create the borrowing record.
             */

            $insertStmt = $pdo->prepare("
                INSERT INTO book_borrowings (
                    book_id,
                    user_id,
                    borrowed_at,
                    due_date,
                    status
                ) VALUES (
                    :book_id,
                    :user_id,
                    NOW(),
                    :due_date,
                    'borrowed'
                )
            ");

            $insertStmt->execute([
                ':book_id' => $bookId,
                ':user_id' => $userId,
                ':due_date' => $dueDate,
            ]);

            /*
             * Decrease the number of available copies.
             */

            $updateStmt = $pdo->prepare("
                UPDATE books
                SET available_copies = available_copies - 1
                WHERE id = :id
                  AND available_copies > 0
            ");

            $updateStmt->execute([
                ':id' => $bookId,
            ]);

            if ($updateStmt->rowCount() !== 1) {
                throw new RuntimeException(
                    'Could not update the available book copies.'
                );
            }

            $pdo->commit();

            header('Location: index.php?success=issued');
            exit;

        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Book issuing error: ' . $e->getMessage());

            http_response_code(500);

            exit(
                'The book could not be issued because of a system error. ' .
                'Please try again.'
            );
        }

    } else {

        header('Location: index.php?error=invalid');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Update overdue status
|--------------------------------------------------------------------------
*/

$pdo->exec("
    UPDATE book_borrowings
    SET status = CASE
        WHEN due_date < CURDATE() THEN 'overdue'
        ELSE 'borrowed'
    END
    WHERE status IN ('borrowed', 'overdue')
      AND returned_at IS NULL
");
/*
|--------------------------------------------------------------------------
| Search and filter
|--------------------------------------------------------------------------
*/

$search = trim((string) ($_GET['search'] ?? ''));

$statusFilter = trim((string) ($_GET['status'] ?? ''));

$allowedStatuses = [
    'borrowed',
    'overdue',
    'returned',
];

if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

$where = [];
$params = [];

if ($search !== '') {
    $where[] = "(
        b.title LIKE :title
        OR u.full_name LIKE :borrower
        OR u.username LIKE :username
    )";

    $term = '%' . $search . '%';

    $params[':title'] = $term;
    $params[':borrower'] = $term;
    $params[':username'] = $term;
}

if ($statusFilter !== '') {
    $where[] = 'bb.status = :status';
    $params[':status'] = $statusFilter;
}

$whereSql = $where
    ? 'WHERE ' . implode(' AND ', $where)
    : '';

/*
|--------------------------------------------------------------------------
| Pagination
|--------------------------------------------------------------------------
*/

$perPage = 10;

$page = filter_input(
    INPUT_GET,
    'page',
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1]]
);

$page = $page ?: 1;

$countStmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM book_borrowings bb
    INNER JOIN books b ON b.id = bb.book_id
    INNER JOIN users u ON u.id = bb.user_id
    {$whereSql}
");

$countStmt->execute($params);

$totalRecords = (int) $countStmt->fetchColumn();

$totalPages = max(
    1,
    (int) ceil($totalRecords / $perPage)
);

$page = min($page, $totalPages);

$offset = ($page - 1) * $perPage;

/*
|--------------------------------------------------------------------------
| Fetch borrowing records
|--------------------------------------------------------------------------
*/

$listStmt = $pdo->prepare("
    SELECT
        bb.id,
        bb.book_id,
        bb.user_id,
        bb.borrowed_at,
        bb.due_date,
        bb.returned_at,
        bb.status,
        b.title,
        b.author,
        u.full_name,
        u.username
    FROM book_borrowings bb
    INNER JOIN books b ON b.id = bb.book_id
    INNER JOIN users u ON u.id = bb.user_id
    {$whereSql}
    ORDER BY
        CASE
            WHEN bb.status = 'overdue' THEN 0
            WHEN bb.status = 'borrowed' THEN 1
            ELSE 2
        END,
        bb.due_date ASC,
        bb.id DESC
    LIMIT :limit OFFSET :offset
");

foreach ($params as $key => $value) {
    $listStmt->bindValue($key, $value, PDO::PARAM_STR);
}

$listStmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$listStmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$listStmt->execute();

$borrowings = $listStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$statsStmt = $pdo->query("
    SELECT
        COUNT(*) AS total_records,
        COALESCE(SUM(
            CASE
                WHEN status = 'borrowed' THEN 1
                ELSE 0
            END
        ), 0) AS borrowed_count,
        COALESCE(SUM(
            CASE
                WHEN status = 'overdue' THEN 1
                ELSE 0
            END
        ), 0) AS overdue_count,
        COALESCE(SUM(
            CASE
                WHEN status = 'returned' THEN 1
                ELSE 0
            END
        ), 0) AS returned_count
    FROM book_borrowings
");

$stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

$totalBorrowings = (int) $stats['total_records'];
$borrowedCount = (int) $stats['borrowed_count'];
$overdueCount = (int) $stats['overdue_count'];
$returnedCount = (int) $stats['returned_count'];

/*
|--------------------------------------------------------------------------
| Form dropdown data
|--------------------------------------------------------------------------
*/

$booksStmt = $pdo->query("
    SELECT id, title, author, available_copies
    FROM books
    WHERE status = 'active'
      AND available_copies > 0
    ORDER BY title ASC
");

$availableBooks = $booksStmt->fetchAll(PDO::FETCH_ASSOC);

$usersStmt = $pdo->query("
    SELECT id, full_name, username
    FROM users
    WHERE role = 'seminarian'
      AND status = 'active'
    ORDER BY full_name ASC
");

$seminarians = $usersStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$successMessages = [
    'issued' => 'Book issued successfully.',
    'returned' => 'Book returned successfully.',
];

$errorMessages = [
    'invalid' => 'Please enter valid borrowing details and a valid due date.',
    'unavailable' => 'This book is no longer available.',
    'invalid_borrower' => 'The selected seminarian is not active or does not exist.',
    'not_found' => 'The borrowing record or book could not be found.',
    'already_returned' => 'This book has already been returned.',
    'book_not_found' => 'The associated book could not be found.',
];

$successMessage = $successMessages[
    (string) ($_GET['success'] ?? '')
] ?? '';

$errorMessage = $errorMessages[
    (string) ($_GET['error'] ?? '')
] ?? '';

/*
|--------------------------------------------------------------------------
| Navigation
|--------------------------------------------------------------------------
*/

$dashboardUrl = '../librarian_dashboard.php';

$displayName = $_SESSION['full_name']
    ?? $_SESSION['username']
    ?? 'Librarian';

function borrowingPageUrl(
    int $pageNumber,
    string $search,
    string $status
): string {
    $query = ['page' => $pageNumber];

    if ($search !== '') {
        $query['search'] = $search;
    }

    if ($status !== '') {
        $query['status'] = $status;
    }

    return '?' . http_build_query($query);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Book Borrowings | Seminary Library</title>

    <style>
        :root {
            --primary: #173b2c;
            --primary-light: #24563f;
            --background: #f4f6f5;
            --white: #ffffff;
            --text: #26352d;
            --muted: #718078;
            --border: #e1e8e3;
            --success: #18794e;
            --danger: #b42318;
            --warning: #8a5a00;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--background);
            color: var(--text);
            font-family: Arial, Helvetica, sans-serif;
        }

        a {
            text-decoration: none;
        }

        .topbar {
            background: var(--primary);
            color: white;
            padding: 17px 20px;
        }

        .topbar-inner {
            max-width: 1350px;
            margin: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .brand {
            font-weight: bold;
            font-size: 20px;
        }

        .brand small {
            display: block;
            font-size: 12px;
            font-weight: normal;
            color: #dce9e0;
            margin-top: 3px;
        }

        .user {
            font-size: 13px;
            color: #e5eee8;
        }

        .container {
            max-width: 1350px;
            margin: 25px auto;
            padding: 0 18px;
        }

        .breadcrumbs {
            font-size: 13px;
            color: var(--muted);
            margin-bottom: 18px;
        }

        .breadcrumbs a {
            color: var(--primary-light);
        }

        .heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 22px;
        }

        h1 {
            margin: 0 0 5px;
            color: var(--primary);
            font-size: 27px;
        }

        .subtitle {
            color: var(--muted);
            font-size: 13px;
            margin: 0;
        }

        .btn {
            display: inline-block;
            padding: 10px 14px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
            text-align: center;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-light {
            background: white;
            color: var(--primary);
            border: 1px solid var(--border);
        }

        .btn-return {
            background: #e4f6eb;
            color: #176b42;
        }

        .btn:hover {
            opacity: 0.86;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 14px;
            margin-bottom: 22px;
        }

        .stat-card {
            background: white;
            padding: 18px;
            border: 1px solid var(--border);
            border-radius: 9px;
        }

        .stat-label {
            color: var(--muted);
            font-size: 12px;
            margin-bottom: 7px;
        }

        .stat-value {
            color: var(--primary);
            font-weight: bold;
            font-size: 27px;
        }

        .panel {
            background: white;
            border: 1px solid var(--border);
            border-radius: 9px;
            margin-bottom: 22px;
            overflow: hidden;
        }

        .panel-heading {
            padding: 17px 20px;
            border-bottom: 1px solid var(--border);
        }

        .panel-heading h2 {
            margin: 0;
            font-size: 17px;
            color: var(--primary);
        }

        .panel-heading p {
            color: var(--muted);
            font-size: 12px;
            margin: 5px 0 0;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 15px;
            padding: 20px;
        }

        .field label {
            display: block;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 6px;
        }

        .field input,
        .field select {
            width: 100%;
            min-height: 42px;
            padding: 10px;
            border: 1px solid #cfd9d2;
            border-radius: 6px;
            background: white;
            color: var(--text);
            font-size: 13px;
        }

        .form-actions {
            grid-column: 1 / -1;
        }

        .filters {
            display: grid;
            grid-template-columns: 2fr 1fr auto auto;
            gap: 12px;
            padding: 18px 20px;
            align-items: end;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 18px;
            font-size: 13px;
        }

        .success {
            color: var(--success);
            background: #e8f7ef;
            border: 1px solid #b7e5ca;
        }

        .error {
            color: var(--danger);
            background: #fff0ef;
            border: 1px solid #f3c5c1;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        th,
        td {
            padding: 13px 15px;
            border-bottom: 1px solid #edf0ee;
            text-align: left;
            font-size: 12px;
            vertical-align: middle;
        }

        th {
            background: #f8faf8;
            color: #596a60;
            font-size: 11px;
            text-transform: uppercase;
        }

        .book-title {
            font-weight: bold;
            color: var(--primary);
            font-size: 13px;
        }

        .muted {
            display: block;
            color: var(--muted);
            font-size: 11px;
            margin-top: 4px;
        }

        .badge {
            display: inline-block;
            border-radius: 20px;
            padding: 5px 8px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
        }

        .badge-borrowed {
            background: #e9efff;
            color: #2c4f9b;
        }

        .badge-overdue {
            background: #fff0ef;
            color: #a52820;
        }

        .badge-returned {
            background: #e4f6eb;
            color: #176b42;
        }

        .empty {
            text-align: center;
            padding: 35px 15px;
            color: var(--muted);
            font-size: 13px;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            padding: 17px 20px;
        }

        .page-links {
            display: flex;
            gap: 6px;
        }

        .page-link {
            display: inline-block;
            padding: 8px 10px;
            border: 1px solid var(--border);
            border-radius: 5px;
            color: var(--primary);
            font-size: 12px;
            background: white;
        }

        .page-link.active {
            color: white;
            background: var(--primary);
        }

        .page-link.disabled {
            pointer-events: none;
            opacity: 0.45;
        }

        .footer {
            text-align: center;
            color: var(--muted);
            font-size: 12px;
            padding: 25px 10px;
        }

        @media (max-width: 800px) {
            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .form-grid {
                grid-template-columns: 1fr 1fr;
            }

            .filters {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 520px) {
            .container {
                padding: 0 12px;
                margin-top: 18px;
            }

            h1 {
                font-size: 23px;
            }

            .form-grid,
            .filters {
                grid-template-columns: 1fr;
                padding: 15px;
            }

            .form-actions .btn,
            .filters .btn {
                width: 100%;
            }

            .stat-card {
                padding: 13px;
            }

            .stat-value {
                font-size: 23px;
            }
        }
    </style>
</head>

<body>

<header class="topbar">
    <div class="topbar-inner">

        <div class="brand">
            Seminary Library
            <small>Book Borrowing and Returns</small>
        </div>

        <div class="user">
            Signed in as:
            <strong><?= borrowingEscape($displayName) ?></strong>
        </div>

    </div>
</header>

<main class="container">

    <div class="breadcrumbs">
        <a href="<?= borrowingEscape($dashboardUrl) ?>">
            Librarian Dashboard
        </a>
        &nbsp; / &nbsp; Borrowings
    </div>

    <section class="heading">

        <div>
            <h1>Book Borrowings</h1>
            <p class="subtitle">
                Issue books, track due dates and process returns.
            </p>
        </div>

        <div>
            <a class="btn btn-light" href="<?= borrowingEscape($dashboardUrl) ?>">
                ← Back to Dashboard
            </a>

            <a class="btn btn-light" href="../books/index.php">
                Book Catalogue
            </a>
        </div>

    </section>

    <?php if ($successMessage !== ''): ?>
        <div class="alert success">
            <?= borrowingEscape($successMessage) ?>
        </div>
    <?php endif; ?>

    <?php if ($errorMessage !== ''): ?>
        <div class="alert error">
            <?= borrowingEscape($errorMessage) ?>
        </div>
    <?php endif; ?>

    <!-- Statistics -->

    <section class="stats">

        <div class="stat-card">
            <div class="stat-label">All Borrowing Records</div>
            <div class="stat-value">
                <?= number_format($totalBorrowings) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Currently Borrowed</div>
            <div class="stat-value">
                <?= number_format($borrowedCount) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Overdue</div>
            <div class="stat-value">
                <?= number_format($overdueCount) ?>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-label">Returned</div>
            <div class="stat-value">
                <?= number_format($returnedCount) ?>
            </div>
        </div>

    </section>

    <!-- Issue a book -->

    <section class="panel">

        <div class="panel-heading">
            <h2>Issue a Book</h2>
            <p>
                Select an available book and an active seminarian.
            </p>
        </div>

        <?php if (empty($availableBooks)): ?>

            <div class="empty">
                No books are currently available for issuing.
            </div>

        <?php elseif (empty($seminarians)): ?>

            <div class="empty">
                No active seminarian accounts were found.
            </div>

        <?php else: ?>

            <form method="POST" action="index.php" class="form-grid">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= borrowingEscape($csrfToken) ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="borrow"
                >

                <div class="field">
                    <label for="book_id">Select Book</label>

                    <select id="book_id" name="book_id" required>
                        <option value="">Choose a book</option>

                        <?php foreach ($availableBooks as $book): ?>
                            <option value="<?= (int) $book['id'] ?>">
                                <?= borrowingEscape($book['title']) ?>
                                —
                                <?= borrowingEscape($book['author']) ?>
                                (<?= (int) $book['available_copies'] ?> available)
                            </option>
                        <?php endforeach; ?>

                    </select>
                </div>

                <div class="field">
                    <label for="user_id">Select Seminarian</label>

                    <select id="user_id" name="user_id" required>
                        <option value="">Choose a seminarian</option>

                        <?php foreach ($seminarians as $seminarian): ?>
                            <option value="<?= (int) $seminarian['id'] ?>">
                                <?= borrowingEscape($seminarian['full_name']) ?>
                                (<?= borrowingEscape($seminarian['username']) ?>)
                            </option>
                        <?php endforeach; ?>

                    </select>
                </div>

                <div class="field">
                    <label for="due_date">Return Due Date</label>

                    <input
                        type="date"
                        id="due_date"
                        name="due_date"
                        min="<?= date('Y-m-d') ?>"
                        value="<?= date('Y-m-d', strtotime('+14 days')) ?>"
                        required
                    >
                </div>

                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">
                        Issue Book
                    </button>
                </div>

            </form>

        <?php endif; ?>

    </section>

    <!-- Search borrowing records -->


    <footer class="footer">
        Seminary Management System &bull; Library Department
    </footer>

</main>

</body>
</html>