<?php

declare(strict_types=1);



require_once __DIR__ . '/../library_permissions.php';

$isSeminarian = ($_SESSION['role'] ?? '') === 'seminarian';

if (!$isSeminarian) {
    requireLibraryManager();
}

if ($isSeminarian && empty($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

if (!function_exists('seminarianHistoryEscape')) {
    function seminarianHistoryEscape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Search and select a seminarian
|--------------------------------------------------------------------------
*/

$search = trim((string) ($_GET['search'] ?? ''));

$seminarianId = filter_input(
    INPUT_GET,
    'user_id',
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1]]
);

$seminarianId = $seminarianId ?: 0;

$seminarian = null;
$borrowings = [];

$totalBorrowed = 0;
$totalOverdue = 0;
$totalReturned = 0;
$totalOutstanding = 0;

if ($seminarianId > 0) {
    $userStmt = $pdo->prepare("
        SELECT id, full_name, username, email
        FROM users
        WHERE id = :id
          AND role = 'seminarian'
          AND status = 'active'
        LIMIT 1
    ");

    $userStmt->execute([
        ':id' => $seminarianId,
    ]);

    $seminarian = $userStmt->fetch(PDO::FETCH_ASSOC);

    if ($seminarian) {
        /*
        |--------------------------------------------------------------------------
        | Refresh overdue statuses
        |--------------------------------------------------------------------------
        */

        $pdo->exec("
            UPDATE book_borrowings
            SET status = CASE
                WHEN due_date < CURDATE() THEN 'overdue'
                ELSE 'borrowed'
            END
            WHERE status IN ('borrowed', 'overdue')
              AND returned_at IS NULL
        ");

        /*
        |--------------------------------------------------------------------------
        | Borrowing statistics for this seminarian
        |--------------------------------------------------------------------------
        */

        $statsStmt = $pdo->prepare("
            SELECT
                COUNT(*) AS total_borrowings,

                COALESCE(SUM(
                    CASE
                        WHEN status = 'borrowed' THEN 1
                        ELSE 0
                    END
                ), 0) AS borrowed_count,

                COALESCE(SUM(
                    CASE
                        WHEN status = 'overdue' THEN 1
                        ELSE 0
                    END
                ), 0) AS overdue_count,

                COALESCE(SUM(
                    CASE
                        WHEN status = 'returned' THEN 1
                        ELSE 0
                    END
                ), 0) AS returned_count

            FROM book_borrowings
            WHERE user_id = :user_id
        ");

        $statsStmt->execute([
            ':user_id' => $seminarianId,
        ]);

        $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

        $totalBorrowed = (int) $stats['borrowed_count'];
        $totalOverdue = (int) $stats['overdue_count'];
        $totalReturned = (int) $stats['returned_count'];

        $totalOutstanding = $totalBorrowed + $totalOverdue;

        /*
        |--------------------------------------------------------------------------
        | Complete borrowing history
        |--------------------------------------------------------------------------
        */

        $historyStmt = $pdo->prepare("
            SELECT
                bb.id,
                bb.borrowed_at,
                bb.due_date,
                bb.returned_at,
                bb.status,
                b.title,
                b.author,
                b.isbn

            FROM book_borrowings bb

            INNER JOIN books b
                ON b.id = bb.book_id

            WHERE bb.user_id = :user_id

            ORDER BY
                CASE
                    WHEN bb.status = 'overdue' THEN 0
                    WHEN bb.status = 'borrowed' THEN 1
                    ELSE 2
                END,
                bb.borrowed_at DESC,
                bb.id DESC
        ");

        $historyStmt->execute([
            ':user_id' => $seminarianId,
        ]);

        $borrowings = $historyStmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

/*
|--------------------------------------------------------------------------
| List active seminarians
|--------------------------------------------------------------------------
*/

if ($search !== '') {
    $usersStmt = $pdo->prepare("
        SELECT id, full_name, username
        FROM users
        WHERE role = 'seminarian'
          AND status = 'active'
          AND (
              full_name LIKE :name
              OR username LIKE :username
          )
        ORDER BY full_name ASC
        LIMIT 100
    ");

    $term = '%' . $search . '%';

    $usersStmt->execute([
        ':name' => $term,
        ':username' => $term,
    ]);
} else {
    $usersStmt = $pdo->query("
        SELECT id, full_name, username
        FROM users
        WHERE role = 'seminarian'
          AND status = 'active'
        ORDER BY full_name ASC
        LIMIT 100
    ");
}

$seminarians = $usersStmt->fetchAll(PDO::FETCH_ASSOC);

$dashboardUrl = '../librarian_dashboard.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Seminarian Borrowing History | Seminary Library</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f3f6f4;
            color: #26352d;
            font-family: Arial, Helvetica, sans-serif;
        }

        .topbar {
            padding: 20px;
            background: #104a2d;
            color: white;
        }

        .topbar-inner {
            max-width: 1250px;
            margin: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .brand {
            font-size: 20px;
            font-weight: bold;
        }

        .brand small {
            display: block;
            margin-top: 5px;
            font-size: 12px;
            font-weight: normal;
            color: #d5e7da;
        }

        .user {
            font-size: 13px;
        }

        .container {
            max-width: 1250px;
            margin: 25px auto;
            padding: 0 18px;
        }

        .breadcrumbs {
            margin-bottom: 18px;
            color: #6b786f;
            font-size: 13px;
        }

        a {
            color: #17683e;
            text-decoration: none;
        }

        .heading {
            margin-bottom: 22px;
        }

        h1 {
            margin: 0 0 8px;
            color: #104a2d;
            font-size: 27px;
        }

        .subtitle {
            margin: 0;
            color: #6b786f;
            font-size: 13px;
            line-height: 1.6;
        }

        .panel {
            margin-bottom: 22px;
            overflow: hidden;
            background: white;
            border: 1px solid #e1e8e3;
            border-radius: 10px;
        }

        .panel-heading {
            padding: 18px 20px;
            border-bottom: 1px solid #e1e8e3;
        }

        .panel-heading h2 {
            margin: 0 0 6px;
            font-size: 17px;
            color: #104a2d;
        }

        .form {
            display: grid;
            grid-template-columns: 2fr 1fr auto;
            gap: 12px;
            align-items: end;
            padding: 20px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-size: 12px;
            font-weight: bold;
        }

        input,
        select {
            width: 100%;
            min-height: 42px;
            padding: 10px;
            border: 1px solid #cbd8cf;
            border-radius: 6px;
            background: white;
            font-size: 13px;
        }

        .btn {
            display: inline-block;
            padding: 11px 15px;
            border: none;
            border-radius: 6px;
            background: #17683e;
            color: white;
            font-size: 13px;
            font-weight: bold;
            text-align: center;
            cursor: pointer;
        }

        .btn:hover {
            opacity: .85;
        }

        .btn-light {
            background: white;
            color: #17683e;
            border: 1px solid #d5e0d8;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 15px;
            margin-bottom: 22px;
        }

        .stat {
            padding: 19px;
            background: white;
            border: 1px solid #e1e8e3;
            border-radius: 9px;
        }

        .stat-label {
            margin-bottom: 10px;
            color: #6b786f;
            font-size: 12px;
        }

        .stat-number {
            color: #104a2d;
            font-size: 28px;
            font-weight: bold;
        }

        .stat.overdue .stat-number {
            color: #b42318;
        }

        .seminarian-details {
            padding: 20px;
            background: #e7f3eb;
            border-radius: 9px;
            margin-bottom: 22px;
        }

        .seminarian-details h2 {
            margin: 0 0 8px;
            color: #104a2d;
            font-size: 20px;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 800px;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 13px 15px;
            border-bottom: 1px solid #edf0ee;
            text-align: left;
            font-size: 12px;
        }

        th {
            background: #f8faf8;
            color: #596a60;
            font-size: 11px;
            text-transform: uppercase;
        }

        .badge {
            display: inline-block;
            padding: 6px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
        }

        .badge-borrowed {
            background: #e9efff;
            color: #2c4f9b;
        }

        .badge-overdue {
            background: #fff0ef;
            color: #a52820;
        }

        .badge-returned {
            background: #e4f6eb;
            color: #176b42;
        }

        .empty {
            padding: 30px 18px;
            color: #6b786f;
            text-align: center;
            font-size: 13px;
        }

        .footer {
            padding: 25px 10px;
            color: #6b786f;
            font-size: 12px;
            text-align: center;
        }

        @media (max-width: 750px) {
            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .form {
                grid-template-columns: 1fr;
            }

            .form .btn {
                width: 100%;
            }
        }

        @media (max-width: 420px) {
            .stats {
                grid-template-columns: 1fr;
            }

            h1 {
                font-size: 23px;
            }

            .container {
                padding: 0 12px;
            }
        }
    </style>
</head>

<body>

<header class="topbar">
    <div class="topbar-inner">
        <div class="brand">
            Seminary Library
            <small>Seminarian Borrowing History</small>
        </div>

        <div class="user">
            Signed in as:
            <strong>
                <?= seminarianHistoryEscape(
                    $_SESSION['full_name']
                    ?? $_SESSION['username']
                    ?? 'Librarian'
                ) ?>
            </strong>
        </div>
    </div>
</header>

<main class="container">

    <div class="breadcrumbs">
        <a href="<?= seminarianHistoryEscape($dashboardUrl) ?>">
            Librarian Dashboard
        </a>
        &nbsp; / &nbsp;
        <a href="index.php">Borrowings</a>
        &nbsp; / &nbsp;
        Seminarian History
    </div>

    <section class="heading">
        <h1>Seminarian Borrowing History</h1>

        <p class="subtitle">
            Select a seminarian to review their borrowing records
            and outstanding books.
        </p>
    </section>

    <section class="panel">
        <div class="panel-heading">
            <h2>Find a Seminarian</h2>

            <p class="subtitle">
                Search by name or username, then select an account.
            </p>
        </div>

        <form method="GET" action="seminarian_history.php" class="form">

            <div>
                <label for="search">Search Seminarian</label>

                <input
                    type="search"
                    id="search"
                    name="search"
                    value="<?= seminarianHistoryEscape($search) ?>"
                    placeholder="Enter name or username"
                >
            </div>

            <div>
                <label for="user_id">Select Seminarian</label>

                <select id="user_id" name="user_id">
                    <option value="">Choose a seminarian</option>

                    <?php foreach ($seminarians as $person): ?>
                        <option
                            value="<?= (int) $person['id'] ?>"
                            <?= $seminarianId === (int) $person['id']
                                ? 'selected'
                                : '' ?>
                        >
                            <?= seminarianHistoryEscape(
                                $person['full_name']
                            ) ?>
                            (<?= seminarianHistoryEscape(
                                $person['username']
                            ) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button class="btn" type="submit">
                View History
            </button>

        </form>
    </section>

    <?php if ($seminarianId > 0 && !$seminarian): ?>

        <section class="panel">
            <div class="empty">
                The selected seminarian was not found or is not active.
                Please choose another account.
            </div>
        </section>

    <?php elseif ($seminarian): ?>

        <section class="seminarian-details">
            <h2>
                <?= seminarianHistoryEscape(
                    $seminarian['full_name']
                ) ?>
            </h2>

            <p class="subtitle">
                Username:
                <?= seminarianHistoryEscape(
                    $seminarian['username']
                ) ?>
            </p>

            <?php if (!empty($seminarian['email'])): ?>
                <p class="subtitle">
                    Email:
                    <?= seminarianHistoryEscape(
                        $seminarian['email']
                    ) ?>
                </p>
            <?php endif; ?>
        </section>

        <section class="stats">

            <div class="stat">
                <div class="stat-label">Currently Borrowed</div>
                <div class="stat-number">
                    <?= number_format($totalBorrowed) ?>
                </div>
            </div>

            <div class="stat overdue">
                <div class="stat-label">Overdue Books</div>
                <div class="stat-number">
                    <?= number_format($totalOverdue) ?>
                </div>
            </div>

            <div class="stat">
                <div class="stat-label">Returned Books</div>
                <div class="stat-number">
                    <?= number_format($totalReturned) ?>
                </div>
            </div>

            <div class="stat">
                <div class="stat-label">Outstanding Books</div>
                <div class="stat-number">
                    <?= number_format($totalOutstanding) ?>
                </div>
            </div>

        </section>

        <section class="panel">

            <div class="panel-heading">
                <h2>Complete Borrowing History</h2>

                <p class="subtitle">
                    Books are listed with outstanding loans first.
                </p>
            </div>

            <?php if (empty($borrowings)): ?>

                <div class="empty">
                    This seminarian has no borrowing records yet.
                </div>

            <?php else: ?>

                <div class="table-wrap">

                    <table>
                        <thead>
                            <tr>
                                <th>Book</th>
                                <th>Borrowed Date</th>
                                <th>Due Date</th>
                                <th>Status</th>
                                <th>Return Date</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($borrowings as $record): ?>

                                <?php
                                $status = (string) $record['status'];

                                $badgeClass = match ($status) {
                                    'overdue' => 'badge-overdue',
                                    'returned' => 'badge-returned',
                                    default => 'badge-borrowed',
                                };
                                ?>

                                <tr>
                                    <td>
                                        <strong>
                                            <?= seminarianHistoryEscape(
                                                $record['title']
                                            ) ?>
                                        </strong>

                                        <br>

                                        <span class="subtitle">
                                            <?= seminarianHistoryEscape(
                                                $record['author']
                                            ) ?>
                                        </span>

                                        <?php if (!empty($record['isbn'])): ?>
                                            <br>

                                            <span class="subtitle">
                                                ISBN:
                                                <?= seminarianHistoryEscape(
                                                    $record['isbn']
                                                ) ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?= seminarianHistoryEscape(
                                            date(
                                                'd M Y',
                                                strtotime($record['borrowed_at'])
                                            )
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= seminarianHistoryEscape(
                                            date(
                                                'd M Y',
                                                strtotime($record['due_date'])
                                            )
                                        ) ?>
                                    </td>

                                    <td>
                                        <span class="badge <?= $badgeClass ?>">
                                            <?= seminarianHistoryEscape(
                                                ucfirst($status)
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?php if ($record['returned_at']): ?>

                                            <?= seminarianHistoryEscape(
                                                date(
                                                    'd M Y',
                                                    strtotime(
                                                        $record['returned_at']
                                                    )
                                                )
                                            ) ?>

                                        <?php else: ?>

                                            <span class="subtitle">
                                                Not returned
                                            </span>

                                        <?php endif; ?>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>

            <?php endif; ?>

        </section>

    <?php else: ?>

        <section class="panel">
            <div class="empty">
                Select a seminarian above to display their borrowing
                history and borrowing statistics.
            </div>
        </section>

    <?php endif; ?>

    <p>
        <a class="btn btn-light" href="index.php">
            ← Back to Borrowing Records
        </a>

        <a class="btn btn-light" href="../books/index.php">
            Book Catalogue
        </a>
    </p>

    <footer class="footer">
        Seminary Management System &bull; Library Department
    </footer>

</main>

</body>
</html>
