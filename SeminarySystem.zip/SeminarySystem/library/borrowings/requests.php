<?php
declare(strict_types=1);

require_once __DIR__ . '/../library_permissions.php';

requireLibraryManager();

if (!isset($pdo) || !$pdo instanceof PDO) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Helper Functions
|--------------------------------------------------------------------------
*/

function libraryRequestsEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function libraryRequestsRedirect(string $message): never
{
    header(
        'Location: requests.php?message=' . urlencode($message)
    );
    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['library_requests_csrf'])) {
    $_SESSION['library_requests_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['library_requests_csrf'];

$staffId = (int) ($_SESSION['user_id'] ?? 0);

if ($staffId < 1) {
    http_response_code(401);
    exit('Please log in again.');
}

/*
|--------------------------------------------------------------------------
| Process Librarian Actions
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        http_response_code(403);
        exit('Invalid security token. Refresh the page and try again.');
    }

    $requestId = filter_var(
        $_POST['request_id'] ?? null,
        FILTER_VALIDATE_INT
    );

    $action = $_POST['action'] ?? '';

    $librarianNotes = trim(
        (string) ($_POST['librarian_notes'] ?? '')
    );

    if (!$requestId || $requestId < 1) {
        libraryRequestsRedirect('invalid_request');
    }

    if (!in_array($action, ['approve', 'reject', 'issue'], true)) {
        libraryRequestsRedirect('invalid_action');
    }

    if (strlen($librarianNotes) > 4000) {
        libraryRequestsRedirect('notes_too_long');
    }

    try {

        /*
        |--------------------------------------------------------------------------
        | APPROVE OR REJECT A REQUEST
        |--------------------------------------------------------------------------
        */

        if ($action === 'approve' || $action === 'reject') {

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                SELECT id, status
                FROM book_requests
                WHERE id = :request_id
                FOR UPDATE
            ");

            $stmt->execute([
                'request_id' => $requestId
            ]);

            $request = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$request) {
                $pdo->rollBack();
                libraryRequestsRedirect('not_found');
            }

            if ($request['status'] !== 'pending') {
                $pdo->rollBack();
                libraryRequestsRedirect('already_reviewed');
            }

            $newStatus = ($action === 'approve')
                ? 'approved'
                : 'rejected';

            $stmt = $pdo->prepare("
                UPDATE book_requests
                SET
                    status = :status,
                    librarian_notes = :notes,
                    reviewed_by = :reviewed_by,
                    reviewed_at = NOW()
                WHERE id = :request_id
                  AND status = 'pending'
            ");

            $stmt->execute([
                'status' => $newStatus,
                'notes' => $librarianNotes !== ''
                    ? $librarianNotes
                    : null,
                'reviewed_by' => $staffId,
                'request_id' => $requestId
            ]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException(
                    'The request could not be updated.'
                );
            }

            $pdo->commit();

            libraryRequestsRedirect(
                $action === 'approve'
                    ? 'approved'
                    : 'rejected'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | ISSUE AN APPROVED BOOK
        |--------------------------------------------------------------------------
        */

        if ($action === 'issue') {

            $dueDate = $_POST['due_date'] ?? '';

            $dateObject = DateTimeImmutable::createFromFormat(
                '!Y-m-d',
                is_string($dueDate) ? $dueDate : ''
            );

            $dateErrors = DateTimeImmutable::getLastErrors();

            $validDate = $dateObject !== false
                && (
                    $dateErrors === false
                    || (
                        $dateErrors['warning_count'] === 0
                        && $dateErrors['error_count'] === 0
                    )
                )
                && $dateObject->format('Y-m-d') === $dueDate;

            if (!$validDate || $dueDate < date('Y-m-d')) {
                libraryRequestsRedirect('invalid_due_date');
            }

            $pdo->beginTransaction();

            /*
             * Lock the request to prevent it from being issued twice.
             */
            $stmt = $pdo->prepare("
                SELECT
                    id,
                    book_id,
                    user_id,
                    status
                FROM book_requests
                WHERE id = :request_id
                FOR UPDATE
            ");

            $stmt->execute([
                'request_id' => $requestId
            ]);

            $request = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$request) {
                $pdo->rollBack();
                libraryRequestsRedirect('not_found');
            }

            if ($request['status'] !== 'approved') {
                $pdo->rollBack();
                libraryRequestsRedirect('not_approved');
            }

            /*
             * Lock the book row before checking and changing stock.
             */
            $stmt = $pdo->prepare("
                SELECT
                    id,
                    title,
                    available_copies,
                    status
                FROM books
                WHERE id = :book_id
                FOR UPDATE
            ");

            $stmt->execute([
                'book_id' => $request['book_id']
            ]);

            $book = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$book || $book['status'] !== 'active') {
                $pdo->rollBack();
                libraryRequestsRedirect('book_unavailable');
            }

            if ((int) $book['available_copies'] < 1) {
                $pdo->rollBack();
                libraryRequestsRedirect('out_of_stock');
            }

            /*
             * Verify that the requesting seminarian still has an
             * active account.
             */
            $stmt = $pdo->prepare("
                SELECT id
                FROM users
                WHERE id = :user_id
                  AND role = 'seminarian'
                  AND status = 'active'
                FOR UPDATE
            ");

            $stmt->execute([
                'user_id' => $request['user_id']
            ]);

            $seminarian = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$seminarian) {
                $pdo->rollBack();
                libraryRequestsRedirect('seminarian_inactive');
            }

            /*
             * Prevent issuing a second copy of the same book to
             * the seminarian while an earlier copy is still borrowed.
             */
            $stmt = $pdo->prepare("
                SELECT id
                FROM book_borrowings
                WHERE book_id = :book_id
                  AND user_id = :user_id
                  AND returned_at IS NULL
                LIMIT 1
                FOR UPDATE
            ");

            $stmt->execute([
                'book_id' => $request['book_id'],
                'user_id' => $request['user_id']
            ]);

            if ($stmt->fetch(PDO::FETCH_ASSOC)) {
                $pdo->rollBack();
                libraryRequestsRedirect('already_borrowed');
            }

            /*
             * Create the actual borrowing record.
             */
            $stmt = $pdo->prepare("
                INSERT INTO book_borrowings (
                    book_id,
                    user_id,
                    borrowed_at,
                    due_date,
                    status,
                    notes
                ) VALUES (
                    :book_id,
                    :user_id,
                    NOW(),
                    :due_date,
                    'borrowed',
                    :notes
                )
            ");

            $stmt->execute([
                'book_id' => $request['book_id'],
                'user_id' => $request['user_id'],
                'due_date' => $dueDate,
                'notes' => 'Issued from book request #' . $requestId
            ]);

            $borrowingId = (int) $pdo->lastInsertId();

            /*
             * Decrease the available stock.
             */
            $stmt = $pdo->prepare("
                UPDATE books
                SET available_copies = available_copies - 1
                WHERE id = :book_id
                  AND available_copies > 0
            ");

            $stmt->execute([
                'book_id' => $request['book_id']
            ]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException(
                    'Book stock could not be updated.'
                );
            }

            /*
             * Mark the request fulfilled and connect it to
             * the borrowing record.
             */
            $stmt = $pdo->prepare("
                UPDATE book_requests
                SET
                    status = 'fulfilled',
                    borrowing_id = :borrowing_id,
                    librarian_notes = :notes,
                    reviewed_by = :reviewed_by,
                    reviewed_at = NOW()
                WHERE id = :request_id
                  AND status = 'approved'
            ");

            $stmt->execute([
                'borrowing_id' => $borrowingId,
                'notes' => $librarianNotes !== ''
                    ? $librarianNotes
                    : null,
                'reviewed_by' => $staffId,
                'request_id' => $requestId
            ]);

            if ($stmt->rowCount() !== 1) {
                throw new RuntimeException(
                    'The request status could not be updated.'
                );
            }

            /*
             * All three changes succeed together or are rolled back:
             * borrowing record, stock update, request status.
             */
            $pdo->commit();

            libraryRequestsRedirect('issued');
        }

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log(
            'Library request management error: ' . $e->getMessage()
        );

        http_response_code(500);
        exit(
            'An error occurred while processing the request. '
            . 'Check the PHP error log for details.'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Notifications
|--------------------------------------------------------------------------
*/

$messages = [
    'approved' => [
        'success',
        'Request approved successfully. The book has not been issued yet.'
    ],
    'rejected' => [
        'success',
        'Request rejected successfully.'
    ],
    'issued' => [
        'success',
        'Book issued successfully. Stock and borrowing records were updated.'
    ],
    'already_reviewed' => [
        'error',
        'This request has already been reviewed.'
    ],
    'not_found' => [
        'error',
        'Book request not found.'
    ],
    'invalid_request' => [
        'error',
        'Invalid request ID.'
    ],
    'invalid_action' => [
        'error',
        'Invalid action.'
    ],
    'notes_too_long' => [
        'error',
        'Notes cannot exceed 4,000 characters.'
    ],
    'invalid_due_date' => [
        'error',
        'Enter a valid due date that is today or later.'
    ],
    'not_approved' => [
        'error',
        'Only approved requests can be issued.'
    ],
    'book_unavailable' => [
        'error',
        'This book is inactive or unavailable.'
    ],
    'out_of_stock' => [
        'error',
        'There are no copies currently available. The request remains approved.'
    ],
    'seminarian_inactive' => [
        'error',
        'The seminarian account is inactive or unavailable.'
    ],
    'already_borrowed' => [
        'error',
        'This seminarian already has an unreturned copy of this book.'
    ]
];

$messageKey = $_GET['message'] ?? '';
$notification = $messages[$messageKey] ?? null;

/*
|--------------------------------------------------------------------------
| Search and Filtering
|--------------------------------------------------------------------------
*/

$search = trim((string) ($_GET['search'] ?? ''));
$statusFilter = (string) ($_GET['status'] ?? '');

$allowedStatuses = [
    'pending',
    'approved',
    'rejected',
    'cancelled',
    'fulfilled'
];

if (!in_array($statusFilter, $allowedStatuses, true)) {
    $statusFilter = '';
}

$sql = "
    SELECT
        br.id,
        br.status,
        br.request_notes,
        br.librarian_notes,
        br.requested_at,
        br.reviewed_at,
        br.borrowing_id,
        b.title,
        b.author,
        b.available_copies,
        b.status AS book_status,
        u.full_name AS seminarian_name,
        u.id AS seminarian_id,
        reviewer.full_name AS reviewer_name
    FROM book_requests br
    INNER JOIN books b
        ON b.id = br.book_id
    INNER JOIN users u
        ON u.id = br.user_id
    LEFT JOIN users reviewer
        ON reviewer.id = br.reviewed_by
    WHERE 1 = 1
";

$params = [];

if ($search !== '') {
    $sql .= "
        AND (
            b.title LIKE :title_search
            OR b.author LIKE :author_search
            OR u.full_name LIKE :name_search
        )
    ";

    $searchTerm = '%' . $search . '%';

    $params['title_search'] = $searchTerm;
    $params['author_search'] = $searchTerm;
    $params['name_search'] = $searchTerm;
}

if ($statusFilter !== '') {
    $sql .= " AND br.status = :status_filter";
    $params['status_filter'] = $statusFilter;
}

$sql .= "
    ORDER BY
        CASE br.status
            WHEN 'pending' THEN 1
            WHEN 'approved' THEN 2
            WHEN 'rejected' THEN 3
            WHEN 'cancelled' THEN 4
            WHEN 'fulfilled' THEN 5
            ELSE 6
        END,
        br.requested_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Summary Statistics
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(status = 'pending'), 0) AS pending,
        COALESCE(SUM(status = 'approved'), 0) AS approved,
        COALESCE(SUM(status = 'rejected'), 0) AS rejected,
        COALESCE(SUM(status = 'fulfilled'), 0) AS fulfilled
    FROM book_requests
");

$stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

$statusLabels = [
    'pending' => 'Pending',
    'approved' => 'Approved',
    'rejected' => 'Rejected',
    'cancelled' => 'Cancelled',
    'fulfilled' => 'Issued / Fulfilled'
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Book Requests Management | Seminary Library</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f3f5f7;
            color: #25332e;
        }

        header {
            background: #173f35;
            color: white;
            padding: 22px 16px;
        }

        .header-content,
        main {
            max-width: 1250px;
            margin: auto;
        }

        header h1 {
            margin: 0 0 8px;
            font-size: 25px;
        }

        header p {
            margin: 0;
            color: #dceae4;
        }

        nav {
            background: white;
            padding: 13px 16px;
            border-bottom: 1px solid #ddd;
        }

        .nav-content {
            max-width: 1250px;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            gap: 9px;
        }

        nav a,
        .button {
            display: inline-block;
            text-decoration: none;
            border: none;
            cursor: pointer;
            border-radius: 6px;
            padding: 10px 13px;
            font-size: 13px;
        }

        nav a {
            background: #eaf1ed;
            color: #173f35;
        }

        main {
            padding: 24px 16px 40px;
        }

        .heading {
            margin-bottom: 22px;
        }

        .heading h2 {
            margin: 0 0 8px;
        }

        .heading p {
            color: #64736c;
            line-height: 1.6;
            margin: 0;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));
            gap: 13px;
            margin-bottom: 23px;
        }

        .stat-card {
            background: white;
            padding: 18px;
            border-radius: 8px;
            border-left: 4px solid #477c67;
            box-shadow: 0 2px 7px rgba(0, 0, 0, .04);
        }

        .stat-card span {
            display: block;
            color: #65746d;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .stat-card strong {
            font-size: 26px;
        }

        .notification {
            padding: 14px;
            border-radius: 7px;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .notification.success {
            background: #e2f5e7;
            color: #176331;
        }

        .notification.error {
            background: #fde9e7;
            color: #8c2620;
        }

        .filters {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            background: white;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .filters input,
        .filters select {
            min-width: 150px;
            flex: 1;
            padding: 11px;
            border: 1px solid #ccd5d0;
            border-radius: 6px;
            background: white;
            font-size: 14px;
        }

        .search-button {
            background: #173f35;
            color: white;
        }

        .reset-button {
            background: #e8ecea;
            color: #25332e;
        }

        .request-card {
            background: white;
            border-radius: 9px;
            padding: 20px;
            margin-bottom: 17px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .05);
        }

        .request-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 14px;
        }

        .request-header h3 {
            margin: 0 0 7px;
            font-size: 19px;
        }

        .request-id {
            color: #718078;
            font-size: 12px;
        }

        .badge {
            display: inline-block;
            padding: 7px 11px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge.pending {
            background: #fff0c2;
            color: #795500;
        }

        .badge.approved {
            background: #dcecff;
            color: #174b85;
        }

        .badge.rejected {
            background: #fde2e0;
            color: #8c2620;
        }

        .badge.cancelled {
            background: #eee;
            color: #555;
        }

        .badge.fulfilled {
            background: #d9f4df;
            color: #176331;
        }

        .details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
            margin: 16px 0;
        }

        .detail {
            padding: 12px;
            background: #f6f8f7;
            border-radius: 6px;
            overflow-wrap: anywhere;
        }

        .detail strong {
            display: block;
            font-size: 11px;
            color: #65746d;
            margin-bottom: 6px;
        }

        .detail span {
            font-size: 14px;
            line-height: 1.5;
        }

        .notes {
            background: #f3f5f8;
            padding: 12px;
            border-radius: 6px;
            margin-top: 12px;
            line-height: 1.6;
            overflow-wrap: anywhere;
        }

        .notes strong {
            display: block;
            margin-bottom: 5px;
        }

        .action-form {
            margin-top: 16px;
            padding: 15px;
            background: #f6f8f7;
            border-radius: 7px;
        }

        .action-form label {
            display: block;
            font-size: 13px;
            font-weight: bold;
            margin: 0 0 7px;
        }

        .action-form textarea,
        .action-form input[type="date"] {
            display: block;
            width: 100%;
            padding: 11px;
            border: 1px solid #ccd5d0;
            border-radius: 6px;
            margin-bottom: 13px;
            background: white;
            font-family: inherit;
            font-size: 14px;
        }

        .action-form textarea {
            resize: vertical;
            min-height: 75px;
        }

        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 9px;
        }

        .approve-button {
            background: #237747;
            color: white;
        }

        .reject-button {
            background: #b83232;
            color: white;
        }

        .issue-button {
            background: #174b85;
            color: white;
        }

        .button:hover {
            opacity: .88;
        }

        .empty-state {
            background: white;
            padding: 35px 20px;
            text-align: center;
            border-radius: 9px;
        }

        .empty-state p {
            color: #65746d;
        }

        footer {
            padding: 20px;
            text-align: center;
            color: #718078;
            font-size: 13px;
        }

        @media (max-width: 500px) {
            header h1 {
                font-size: 21px;
            }

            .request-card {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<header>
    <div class="header-content">
        <h1>📚 Seminary Library</h1>
        <p>Book Requests Management</p>
    </div>
</header>

<nav>
    <div class="nav-content">
        <a href="../dashboard.php">Library Dashboard</a>
        <a href="../books/index.php">Book Catalogue</a>
        <a href="../books/create.php">Add Book</a>
        <a href="index.php">Borrowings</a>
        <a href="seminarian_history.php">Seminarian History</a>
        <a href="requests.php">Book Requests</a>
        <a href="../../index.php">Main System</a>
    </div>
</nav>

<main>

    <section class="heading">
        <h2>Book Requests</h2>

        <p>
            Review requests, communicate with seminarians, and issue
            approved books. Stock is updated only when a book is issued.
        </p>
    </section>

    <?php if ($notification): ?>
        <div class="notification <?= libraryRequestsEscape($notification[0]) ?>">
            <?= libraryRequestsEscape($notification[1]) ?>
        </div>
    <?php endif; ?>

    <section class="stats">

        <div class="stat-card">
            <span>Total Requests</span>
            <strong><?= (int) ($stats['total'] ?? 0) ?></strong>
        </div>

        <div class="stat-card">
            <span>Pending Review</span>
            <strong><?= (int) ($stats['pending'] ?? 0) ?></strong>
        </div>

        <div class="stat-card">
            <span>Approved</span>
            <strong><?= (int) ($stats['approved'] ?? 0) ?></strong>
        </div>

        <div class="stat-card">
            <span>Rejected</span>
            <strong><?= (int) ($stats['rejected'] ?? 0) ?></strong>
        </div>

        <div class="stat-card">
            <span>Issued / Fulfilled</span>
            <strong><?= (int) ($stats['fulfilled'] ?? 0) ?></strong>
        </div>

    </section>

    <form method="GET" action="requests.php" class="filters">

        <input
            type="search"
            name="search"
            placeholder="Search book or seminarian..."
            value="<?= libraryRequestsEscape($search) ?>"
        >

        <select name="status">
            <option value="">All statuses</option>

            <?php foreach ($statusLabels as $value => $label): ?>
                <option
                    value="<?= libraryRequestsEscape($value) ?>"
                    <?= $statusFilter === $value ? 'selected' : '' ?>
                >
                    <?= libraryRequestsEscape($label) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="button search-button" type="submit">
            Search
        </button>

        <a class="button reset-button" href="requests.php">
            Reset
        </a>

    </form>

    <?php if (empty($requests)): ?>

        <section class="empty-state">
            <h3>No book requests found</h3>

            <p>
                Try another search term or status filter.
                New requests will appear here when seminarians submit them.
            </p>
        </section>

    <?php else: ?>

        <?php foreach ($requests as $request): ?>

            <?php
                $status = $request['status'];

                $statusLabel = $statusLabels[$status] ?? ucfirst($status);
            ?>

            <article class="request-card">

                <div class="request-header">

                    <div>
                        <h3>
                            <?= libraryRequestsEscape($request['title']) ?>
                        </h3>

                        <div class="request-id">
                            Request #<?= (int) $request['id'] ?>
                        </div>
                    </div>

                    <span class="badge <?= libraryRequestsEscape($status) ?>">
                        <?= libraryRequestsEscape($statusLabel) ?>
                    </span>

                </div>

                <div class="details">

                    <div class="detail">
                        <strong>SEMINARIAN</strong>
                        <span>
                            <?= libraryRequestsEscape($request['seminarian_name']) ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>SEMINARIAN ID</strong>
                        <span>
                            <?= (int) $request['seminarian_id'] ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>AUTHOR</strong>
                        <span>
                            <?= libraryRequestsEscape($request['author']) ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>AVAILABLE COPIES</strong>
                        <span>
                            <?= (int) $request['available_copies'] ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>REQUESTED ON</strong>
                        <span>
                            <?= libraryRequestsEscape($request['requested_at']) ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>LAST REVIEWED</strong>
                        <span>
                            <?= libraryRequestsEscape($request['reviewed_at'] ?: 'Not reviewed') ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>REVIEWED BY</strong>
                        <span>
                            <?= libraryRequestsEscape($request['reviewer_name'] ?: 'Not reviewed') ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>BOOK STATUS</strong>
                        <span>
                            <?= libraryRequestsEscape(ucfirst($request['book_status'])) ?>
                        </span>
                    </div>

                </div>

                <?php if (!empty($request['request_notes'])): ?>

                    <div class="notes">
                        <strong>Seminarian's Notes</strong>

                        <?= nl2br(libraryRequestsEscape($request['request_notes'])) ?>
                    </div>

                <?php endif; ?>

                <?php if (!empty($request['librarian_notes'])): ?>

                    <div class="notes">
                        <strong>Previous Librarian's Notes</strong>

                        <?= nl2br(libraryRequestsEscape($request['librarian_notes'])) ?>
                    </div>

                <?php endif; ?>

                <?php if ($status === 'pending'): ?>

                    <form
                        method="POST"
                        action="requests.php"
                        class="action-form"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= libraryRequestsEscape($csrfToken) ?>"
                        >

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?= (int) $request['id'] ?>"
                        >

                        <label for="notes-<?= (int) $request['id'] ?>">
                            Librarian's Notes (optional)
                        </label>

                        <textarea
                            id="notes-<?= (int) $request['id'] ?>"
                            name="librarian_notes"
                            maxlength="4000"
                            placeholder="Explain your decision or provide instructions..."
                        ></textarea>

                        <div class="action-buttons">

                            <button
                                class="button approve-button"
                                type="submit"
                                name="action"
                                value="approve"
                                onclick="return confirm('Approve this book request?');"
                            >
                                Approve Request
                            </button>

                            <button
                                class="button reject-button"
                                type="submit"
                                name="action"
                                value="reject"
                                onclick="return confirm('Reject this book request?');"
                            >
                                Reject Request
                            </button>

                        </div>

                    </form>

                <?php elseif ($status === 'approved'): ?>

                    <?php if (
                        $request['book_status'] === 'active'
                        && (int) $request['available_copies'] > 0
                    ): ?>

                        <form
                            method="POST"
                            action="requests.php"
                            class="action-form"
                            onsubmit="return confirm('Issue this book and update the library stock?');"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= libraryRequestsEscape($csrfToken) ?>"
                            >

                            <input
                                type="hidden"
                                name="request_id"
                                value="<?= (int) $request['id'] ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="issue"
                            >

                            <label for="due-<?= (int) $request['id'] ?>">
                                Book Return Due Date
                            </label>

                            <input
                                type="date"
                                id="due-<?= (int) $request['id'] ?>"
                                name="due_date"
                                min="<?= date('Y-m-d') ?>"
                                value="<?= date('Y-m-d', strtotime('+14 days')) ?>"
                                required
                            >

                            <label for="issue-notes-<?= (int) $request['id'] ?>">
                                Issuing Notes (optional)
                            </label>

                            <textarea
                                id="issue-notes-<?= (int) $request['id'] ?>"
                                name="librarian_notes"
                                maxlength="4000"
                                placeholder="Optional note about issuing this book..."
                            ></textarea>

                            <button
                                class="button issue-button"
                                type="submit"
                            >
                                Issue Book to Seminarian
                            </button>

                        </form>

                    <?php else: ?>

                        <div class="notes">
                            <strong>Cannot Issue Yet</strong>

                            The book is inactive or no copies are currently
                            available. The request remains approved.
                            Check the book catalogue and stock before trying again.
                        </div>

                    <?php endif; ?>

                <?php elseif ($status === 'fulfilled'): ?>

                    <div class="notes">
                        <strong>Book Issued Successfully</strong>

                        Borrowing reference:
                        #<?= (int) ($request['borrowing_id'] ?? 0) ?>
                    </div>

                <?php endif; ?>

            </article>

        <?php endforeach; ?>

    <?php endif; ?>

</main>

<footer>
    Seminary Management System &mdash; Library Department
</footer>

</body>
</html>
