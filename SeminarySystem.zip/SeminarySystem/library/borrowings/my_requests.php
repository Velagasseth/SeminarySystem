<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/department_auth.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'seminarian') {
    http_response_code(403);
    exit('Access denied. This page is for seminarians only.');
}

if (!isset($pdo) || !$pdo instanceof PDO) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$userId = (int) $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| Helper Functions
|--------------------------------------------------------------------------
*/

function myRequestEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function myRequestRedirect(string $message): never
{
    header('Location: my_requests.php?message=' . urlencode($message));
    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['my_requests_csrf'])) {
    $_SESSION['my_requests_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['my_requests_csrf'];

$message = $_GET['message'] ?? '';

/*
|--------------------------------------------------------------------------
| Cancel Pending Request
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($submittedToken) ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        http_response_code(403);
        exit('Invalid security token. Please refresh the page and try again.');
    }

    $requestId = filter_var(
        $_POST['request_id'] ?? null,
        FILTER_VALIDATE_INT
    );

    if (!$requestId || $requestId < 1) {
        myRequestRedirect('invalid_request');
    }

    try {
        $pdo->beginTransaction();

        /*
         * Lock only a request belonging to the currently logged-in
         * seminarian. A different user's request cannot be cancelled.
         */
        $stmt = $pdo->prepare("
            SELECT id, status
            FROM book_requests
            WHERE id = :request_id
              AND user_id = :user_id
            FOR UPDATE
        ");

        $stmt->execute([
            'request_id' => $requestId,
            'user_id' => $userId
        ]);

        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            $pdo->rollBack();
            myRequestRedirect('not_found');
        }

        if ($request['status'] !== 'pending') {
            $pdo->rollBack();
            myRequestRedirect('cannot_cancel');
        }

        $stmt = $pdo->prepare("
            UPDATE book_requests
            SET status = 'cancelled'
            WHERE id = :request_id
              AND user_id = :user_id
              AND status = 'pending'
        ");

        $stmt->execute([
            'request_id' => $requestId,
            'user_id' => $userId
        ]);

        $pdo->commit();

        myRequestRedirect('cancelled');

    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log('Book request cancellation error: ' . $e->getMessage());

        http_response_code(500);
        exit('Something went wrong while cancelling the request. Please try again.');
    }
}

/*
|--------------------------------------------------------------------------
| Notification Messages
|--------------------------------------------------------------------------
*/

$notifications = [
    'submitted' => [
        'type' => 'success',
        'text' => 'Your book request was submitted successfully.'
    ],
    'cancelled' => [
        'type' => 'success',
        'text' => 'Your pending book request has been cancelled.'
    ],
    'invalid_request' => [
        'type' => 'error',
        'text' => 'Invalid request. Please try again.'
    ],
    'not_found' => [
        'type' => 'error',
        'text' => 'The requested record was not found in your account.'
    ],
    'cannot_cancel' => [
        'type' => 'error',
        'text' => 'Only pending requests can be cancelled.'
    ]
];

$notification = $notifications[$message] ?? null;

/*
|--------------------------------------------------------------------------
| Request Statistics
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total_requests,
        SUM(status = 'pending') AS pending_requests,
        SUM(status = 'approved') AS approved_requests,
        SUM(status = 'rejected') AS rejected_requests,
        SUM(status = 'cancelled') AS cancelled_requests,
        SUM(status = 'fulfilled') AS fulfilled_requests
    FROM book_requests
    WHERE user_id = :user_id
");

$stmt->execute(['user_id' => $userId]);

$stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

/*
|--------------------------------------------------------------------------
| Fetch This Seminarian's Requests
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        br.id,
        br.status,
        br.request_notes,
        br.librarian_notes,
        br.requested_at,
        br.reviewed_at,
        br.borrowing_id,
        b.title,
        b.author,
        b.category,
        b.shelf_location,
        reviewer.full_name AS reviewer_name
    FROM book_requests br
    INNER JOIN books b
        ON b.id = br.book_id
    LEFT JOIN users reviewer
        ON reviewer.id = br.reviewed_by
    WHERE br.user_id = :user_id
    ORDER BY br.requested_at DESC, br.id DESC
");

$stmt->execute(['user_id' => $userId]);

$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Page Presentation
|--------------------------------------------------------------------------
*/

$statusLabels = [
    'pending' => 'Pending',
    'approved' => 'Approved',
    'rejected' => 'Rejected',
    'cancelled' => 'Cancelled',
    'fulfilled' => 'Issued / Fulfilled'
];

$statusClasses = [
    'pending' => 'pending',
    'approved' => 'approved',
    'rejected' => 'rejected',
    'cancelled' => 'cancelled',
    'fulfilled' => 'fulfilled'
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Book Requests | Seminary Library</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #263238;
        }

        header {
            background: #173f35;
            color: white;
            padding: 22px 16px;
        }

        .header-content,
        main {
            max-width: 1150px;
            margin: auto;
        }

        header h1 {
            margin: 0 0 8px;
            font-size: 25px;
        }

        header p {
            margin: 0;
            color: #e2eee9;
        }

        nav {
            background: white;
            padding: 13px 16px;
            border-bottom: 1px solid #ddd;
        }

        .nav-content {
            max-width: 1150px;
            margin: auto;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        nav a,
        .button {
            display: inline-block;
            text-decoration: none;
            background: #e9f1ed;
            color: #173f35;
            padding: 10px 13px;
            border-radius: 6px;
            font-size: 14px;
            border: none;
            cursor: pointer;
        }

        nav a:hover,
        .button:hover {
            background: #d6e7de;
        }

        main {
            padding: 22px 16px 40px;
        }

        .page-heading {
            margin-bottom: 20px;
        }

        .page-heading h2 {
            margin: 0 0 8px;
            font-size: 23px;
        }

        .page-heading p {
            margin: 0;
            color: #60716b;
            line-height: 1.6;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));
            gap: 14px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: white;
            padding: 18px;
            border-radius: 9px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            border-left: 4px solid #477c67;
        }

        .stat-card span {
            display: block;
            color: #64736d;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .stat-card strong {
            font-size: 27px;
        }

        .notification {
            padding: 14px;
            margin-bottom: 20px;
            border-radius: 7px;
            line-height: 1.5;
        }

        .notification.success {
            background: #e4f6e9;
            color: #176331;
            border: 1px solid #b8e3c4;
        }

        .notification.error {
            background: #fde9e7;
            color: #8c2620;
            border: 1px solid #f1c0bc;
        }

        .request-card {
            background: white;
            border-radius: 9px;
            padding: 20px;
            margin-bottom: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .request-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 14px;
        }

        .request-top h3 {
            margin: 0 0 7px;
            font-size: 19px;
        }

        .request-id {
            font-size: 12px;
            color: #718078;
        }

        .badge {
            display: inline-block;
            padding: 7px 11px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge.pending {
            background: #fff0c2;
            color: #795500;
        }

        .badge.approved {
            background: #dcecff;
            color: #174b85;
        }

        .badge.rejected {
            background: #fde2e0;
            color: #8c2620;
        }

        .badge.cancelled {
            background: #eeeeee;
            color: #555;
        }

        .badge.fulfilled {
            background: #d9f4df;
            color: #176331;
        }

        .details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 13px;
            margin: 15px 0;
        }

        .detail {
            padding: 11px;
            background: #f7f9f8;
            border-radius: 6px;
        }

        .detail strong {
            display: block;
            font-size: 12px;
            color: #65746d;
            margin-bottom: 6px;
        }

        .detail span {
            overflow-wrap: anywhere;
            line-height: 1.5;
        }

        .notes {
            padding: 13px;
            border-radius: 6px;
            margin-top: 12px;
            line-height: 1.6;
            overflow-wrap: anywhere;
        }

        .request-notes {
            background: #f3f5f8;
        }

        .librarian-notes {
            background: #edf6f0;
            border-left: 3px solid #477c67;
        }

        .notes strong {
            display: block;
            margin-bottom: 5px;
        }

        .cancel-button {
            background: #b83232;
            color: white;
            margin-top: 14px;
        }

        .cancel-button:hover {
            background: #962525;
        }

        .empty-state {
            text-align: center;
            background: white;
            padding: 35px 20px;
            border-radius: 9px;
        }

        .empty-state h3 {
            margin-top: 0;
        }

        .empty-state p {
            color: #60716b;
            line-height: 1.6;
        }

        .primary-button {
            background: #173f35;
            color: white;
        }

        footer {
            text-align: center;
            color: #718078;
            padding: 20px;
            font-size: 13px;
        }

        @media (max-width: 500px) {
            header h1 {
                font-size: 21px;
            }

            .request-card {
                padding: 15px;
            }

            .stat-card strong {
                font-size: 23px;
            }
        }
    </style>
</head>

<body>

<header>
    <div class="header-content">
        <h1>📚 Seminary Library</h1>
        <p>My Book Requests</p>
    </div>
</header>

<nav>
    <div class="nav-content">
        <a href="../dashboard.php">Library Dashboard</a>
        <a href="../books/index.php">Book Catalogue</a>
        <a href="request_book.php">Request a Book</a>
        <a href="my_books.php">My Borrowed Books</a>
        <a href="../../index.php">Main System</a>
    </div>
</nav>

<main>

    <section class="page-heading">
        <h2>My Book Requests</h2>

        <p>
            Track the books you have requested from the library.
            A pending request is waiting for the librarian to review it.
            An approved request does not mean the book has already been issued.
        </p>
    </section>

    <?php if ($notification): ?>
        <div class="notification <?= myRequestEscape($notification['type']) ?>">
            <?= myRequestEscape($notification['text']) ?>
        </div>
    <?php endif; ?>

    <section class="stats">

        <div class="stat-card">
            <span>Total Requests</span>
            <strong>
                <?= (int) ($stats['total_requests'] ?? 0) ?>
            </strong>
        </div>

        <div class="stat-card">
            <span>Pending</span>
            <strong>
                <?= (int) ($stats['pending_requests'] ?? 0) ?>
            </strong>
        </div>

        <div class="stat-card">
            <span>Approved</span>
            <strong>
                <?= (int) ($stats['approved_requests'] ?? 0) ?>
            </strong>
        </div>

        <div class="stat-card">
            <span>Rejected</span>
            <strong>
                <?= (int) ($stats['rejected_requests'] ?? 0) ?>
            </strong>
        </div>

        <div class="stat-card">
            <span>Fulfilled</span>
            <strong>
                <?= (int) ($stats['fulfilled_requests'] ?? 0) ?>
            </strong>
        </div>

    </section>

    <?php if (empty($requests)): ?>

        <section class="empty-state">
            <h3>You have not requested any books yet.</h3>

            <p>
                Visit the book catalogue to find books and submit
                a request to the librarian.
            </p>

            <a class="button primary-button" href="request_book.php">
                Browse Books
            </a>
        </section>

    <?php else: ?>

        <?php foreach ($requests as $request): ?>

            <?php
                $status = $request['status'];

                $statusLabel = $statusLabels[$status] ?? ucfirst($status);

                $statusClass = $statusClasses[$status] ?? 'cancelled';
            ?>

            <article class="request-card">

                <div class="request-top">

                    <div>
                        <h3>
                            <?= myRequestEscape($request['title']) ?>
                        </h3>

                        <div class="request-id">
                            Request #<?= (int) $request['id'] ?>
                        </div>
                    </div>

                    <span class="badge <?= myRequestEscape($statusClass) ?>">
                        <?= myRequestEscape($statusLabel) ?>
                    </span>

                </div>

                <div class="details">

                    <div class="detail">
                        <strong>AUTHOR</strong>
                        <span>
                            <?= myRequestEscape($request['author']) ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>CATEGORY</strong>
                        <span>
                            <?= myRequestEscape($request['category'] ?: 'Not specified') ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>SHELF LOCATION</strong>
                        <span>
                            <?= myRequestEscape($request['shelf_location'] ?: 'Not specified') ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>REQUESTED ON</strong>
                        <span>
                            <?= myRequestEscape($request['requested_at']) ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>REVIEWED ON</strong>
                        <span>
                            <?= myRequestEscape($request['reviewed_at'] ?: 'Not reviewed yet') ?>
                        </span>
                    </div>

                    <div class="detail">
                        <strong>REVIEWED BY</strong>
                        <span>
                            <?= myRequestEscape($request['reviewer_name'] ?: 'Not reviewed yet') ?>
                        </span>
                    </div>

                </div>

                <?php if (!empty($request['request_notes'])): ?>

                    <div class="notes request-notes">
                        <strong>Your Notes</strong>

                        <?= nl2br(myRequestEscape($request['request_notes'])) ?>
                    </div>

                <?php endif; ?>

                <?php if (!empty($request['librarian_notes'])): ?>

                    <div class="notes librarian-notes">
                        <strong>Librarian's Notes</strong>

                        <?= nl2br(myRequestEscape($request['librarian_notes'])) ?>
                    </div>

                <?php endif; ?>

                <?php if ($status === 'approved'): ?>

                    <div class="notes librarian-notes">
                        <strong>Next Step</strong>

                        Your request has been approved. Please wait for the
                        librarian to issue the book. It is not yet recorded
                        as borrowed.
                    </div>

                <?php elseif ($status === 'fulfilled'): ?>

                    <div class="notes librarian-notes">
                        <strong>Book Issued</strong>

                        This request has been fulfilled and linked to a
                        library borrowing record.

                        <?php if (!empty($request['borrowing_id'])): ?>
                            <br>
                            Borrowing reference:
                            #<?= (int) $request['borrowing_id'] ?>
                        <?php endif; ?>

                        <br><br>

                        <a href="my_books.php">
                            View My Borrowed Books →
                        </a>
                    </div>

                <?php endif; ?>

                <?php if ($status === 'pending'): ?>

                    <form
                        method="POST"
                        action="my_requests.php"
                        onsubmit="return confirm('Are you sure you want to cancel this book request?');"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= myRequestEscape($csrfToken) ?>"
                        >

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?= (int) $request['id'] ?>"
                        >

                        <button
                            type="submit"
                            class="button cancel-button"
                        >
                            Cancel Request
                        </button>

                    </form>

                <?php endif; ?>

            </article>

        <?php endforeach; ?>

    <?php endif; ?>

</main>

<footer>
    Seminary Management System &mdash; Library Department
</footer>

</body>
</html>
