<?php

declare(strict_types=1);

require_once __DIR__ . '/../library_permissions.php';

/*
|--------------------------------------------------------------------------
| Access control
|--------------------------------------------------------------------------
*/

requireLibraryManager();

/*
|--------------------------------------------------------------------------
| Accept POST requests only
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Verify CSRF token
|--------------------------------------------------------------------------
*/

$submittedToken = $_POST['csrf_token'] ?? '';
$sessionToken = $_SESSION['csrf_token'] ?? '';

if (
    !is_string($submittedToken) ||
    !is_string($sessionToken) ||
    $sessionToken === '' ||
    !hash_equals($sessionToken, $submittedToken)
) {
    http_response_code(403);
    exit('Invalid security token. Please return to the borrowing page and try again.');
}

/*
|--------------------------------------------------------------------------
| Validate borrowing ID
|--------------------------------------------------------------------------
*/

$borrowingId = filter_input(
    INPUT_POST,
    'borrowing_id',
    FILTER_VALIDATE_INT,
    ['options' => ['min_range' => 1]]
);

if (!$borrowingId) {
    header('Location: index.php?error=invalid');
    exit;
}

/*
|--------------------------------------------------------------------------
| Database connection
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

try {
    /*
    |--------------------------------------------------------------------------
    | Begin transaction
    |--------------------------------------------------------------------------
    */

    $pdo->beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Lock the borrowing record
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            book_id,
            status
        FROM book_borrowings
        WHERE id = :id
        FOR UPDATE
    ");

    $stmt->execute([
        ':id' => $borrowingId,
    ]);

    $borrowing = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$borrowing) {
        $pdo->rollBack();

        header('Location: index.php?error=not_found');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Prevent returning a book twice
    |--------------------------------------------------------------------------
    */

    if (!in_array($borrowing['status'], ['borrowed', 'overdue'], true)) {
        $pdo->rollBack();

        header('Location: index.php?error=already_returned');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Lock the book record
    |--------------------------------------------------------------------------
    */

    $bookStmt = $pdo->prepare("
        SELECT
            id,
            total_copies,
            available_copies
        FROM books
        WHERE id = :id
        FOR UPDATE
    ");

    $bookStmt->execute([
        ':id' => (int) $borrowing['book_id'],
    ]);

    $book = $bookStmt->fetch(PDO::FETCH_ASSOC);

    if (!$book) {
        $pdo->rollBack();

        header('Location: index.php?error=book_not_found');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Mark the borrowing as returned
    |--------------------------------------------------------------------------
    */

    $returnStmt = $pdo->prepare("
        UPDATE book_borrowings
        SET
            status = 'returned',
            returned_at = NOW()
        WHERE id = :id
          AND status IN ('borrowed', 'overdue')
    ");

    $returnStmt->execute([
        ':id' => $borrowingId,
    ]);

    if ($returnStmt->rowCount() !== 1) {
        $pdo->rollBack();

        header('Location: index.php?error=already_returned');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Restore one available copy
    |--------------------------------------------------------------------------
    | Do not allow available copies to exceed total copies.
    */

    $updateBookStmt = $pdo->prepare("
        UPDATE books
        SET available_copies = LEAST(
            total_copies,
            available_copies + 1
        )
        WHERE id = :id
    ");

    $updateBookStmt->execute([
        ':id' => (int) $book['id'],
    ]);

    /*
    |--------------------------------------------------------------------------
    | Commit changes
    |--------------------------------------------------------------------------
    */

    $pdo->commit();

    header('Location: index.php?success=returned');
    exit;

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log('Book return error: ' . $e->getMessage());

    http_response_code(500);

    exit(
        'The book could not be returned because of a system error. ' .
        'Please try again or contact the system administrator.'
    );
}
