<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Require a logged-in user.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Verify that the user is authorized for Academics.
if (($_SESSION['role'] ?? '') !== 'super_admin') {

    $stmt = $pdo->prepare(
        "SELECT 1
         FROM user_departments ud
         INNER JOIN departments d
            ON d.id = ud.department_id
         WHERE ud.user_id = ?
           AND d.department_code = 'academics'
           AND d.status = 'active'
         LIMIT 1"
    );

    $stmt->execute([(int) $_SESSION['user_id']]);

    if (!$stmt->fetch()) {
        http_response_code(403);
        exit('Access denied. You are not assigned to the Academics Department.');
    }
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$fullName = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Academics Dashboard</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            margin: 0;
            font-size: 21px;
        }

        header p {
            margin: 7px 0 0;
            font-size: 13px;
            color: #d1fae5;
        }

        .logout {
            color: white;
            background: #dc2626;
            padding: 10px 14px;
            text-decoration: none;
            border-radius: 6px;
        }

        main {
            max-width: 1100px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h2 {
            color: #123b2a;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .card {
            padding: 22px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, .05);
        }

        .card h3 {
            margin-top: 0;
            color: #14532d;
        }

        .card p {
            color: #64748b;
            line-height: 1.5;
        }

        .card a {
            display: inline-block;
            margin-top: 8px;
            color: #166534;
            font-weight: bold;
            text-decoration: none;
        }

        .notice {
            background: #dcfce7;
            border-left: 4px solid #166534;
            padding: 16px;
            margin-top: 25px;
            border-radius: 5px;
        }

        footer {
            padding: 25px;
            text-align: center;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>Academics Department</h1>
        <p>Seminary Management System</p>
    </div>

    <a class="logout" href="../admin/logout.php">Log Out</a>
</header>

<main>

    <section class="welcome">
        <h2>Welcome, <?= e($fullName) ?>!</h2>

        <p>
            Role: <?= e(ucwords(str_replace('_', ' ', $role))) ?>
        </p>

        <p>
            Manage academic activities and learning resources
            from this dashboard.
        </p>
    </section>

    <section class="cards">

        <article class="card">
            <h3>📚 Academic Units</h3>
            <p>Organize subjects, units, and course information.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📝 Assignments</h3>
            <p>Prepare assignments, set deadlines, and manage submissions.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>👥 Academic Groups</h3>
            <p>Organize seminarians into academic groups.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📅 Lectures</h3>
            <p>Organize lecture schedules and academic activities.</p>
            <a href="#">Coming soon</a>
        </article>

    </section>

    <div class="notice">
        <strong>Development notice:</strong>
        The dashboard is ready. We will connect each section
        to the database as we build the academic features.
    </div>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
