<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

$error = '';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        $error = 'Invalid request. Please refresh the page.';
    } else {

        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === '' || $password === '') {

            $error = 'Please enter your username and password.';

        } else {

            try {
                $stmt = $pdo->prepare(
                    "SELECT
                        u.id,
                        u.full_name,
                        u.username,
                        u.password_hash,
                        u.role,
                        u.status
                     FROM users u
                     WHERE u.username = ?
                     LIMIT 1"
                );

                $stmt->execute([$username]);
                $user = $stmt->fetch();

                if (
                    $user &&
                    password_verify($password, $user['password_hash']) &&
                    $user['status'] === 'active'
                ) {
                    // Super administrators can access every department.
                    $hasAccess = $user['role'] === 'super_admin';

                    if (!$hasAccess) {
                        $accessCheck = $pdo->prepare(
                            "SELECT ud.department_id
                             FROM user_departments ud
                             INNER JOIN departments d
                                ON d.id = ud.department_id
                             WHERE ud.user_id = ?
                               AND d.department_code = 'academics'
                               AND d.status = 'active'
                             LIMIT 1"
                        );

                        $accessCheck->execute([(int) $user['id']]);

                        $hasAccess = (bool) $accessCheck->fetch();
                    }

                    if ($hasAccess) {

                        session_regenerate_id(true);

                        $_SESSION['user_id'] = (int) $user['id'];
                        $_SESSION['full_name'] = $user['full_name'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['department_code'] = 'academics';

                        header('Location: dashboard.php');
                        exit;

                    } else {
                        $error = 'You are not authorized to access the Academics Department.';
                    }

                } else {
                    $error = 'Invalid username or password.';
                }

            } catch (PDOException $e) {
                error_log('Academics login failed: ' . $e->getMessage());
                $error = 'A system error occurred. Please try again later.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Academics Login | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
        }

        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.08);
        }

        h1 {
            color: #123b2a;
            text-align: center;
            font-size: 25px;
        }

        .subtitle {
            color: #64748b;
            text-align: center;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 13px;
            background: #14532d;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
        }

        .error {
            padding: 12px;
            margin-bottom: 18px;
            border-radius: 6px;
            background: #fee2e2;
            color: #991b1b;
        }

        .back-link {
            display: block;
            margin-top: 20px;
            text-align: center;
            color: #14532d;
            text-decoration: none;
        }
    </style>
</head>

<body>

    <main class="login-box">

        <h1>Academics Department</h1>

        <p class="subtitle">
            Seminary Management System
        </p>

        <?php if ($error !== ''): ?>
            <div class="error">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars(
                    $_SESSION['csrf_token'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
            >

            <label for="username">Username</label>

            <input
                type="text"
                id="username"
                name="username"
                autocomplete="username"
                required
            >

            <label for="password">Password</label>

            <input
                type="password"
                id="password"
                name="password"
                autocomplete="current-password"
                required
            >

            <button type="submit">Sign In</button>

        </form>

        <a class="back-link" href="../index.php">
            Back to Homepage
        </a>

    </main>

</body>
</html>
