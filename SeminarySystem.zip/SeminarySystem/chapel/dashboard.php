<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Ensure the user is logged in.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Check Chapel Department permissions.
if (($_SESSION['role'] ?? '') !== 'super_admin') {

    $stmt = $pdo->prepare(
        "SELECT 1
         FROM user_departments ud
         INNER JOIN departments d
            ON d.id = ud.department_id
         WHERE ud.user_id = ?
           AND d.department_code = 'chapel'
           AND d.status = 'active'
         LIMIT 1"
    );

    $stmt->execute([(int) $_SESSION['user_id']]);

    if (!$stmt->fetch()) {
        http_response_code(403);
        exit('Access denied. You are not assigned to the Chapel Department.');
    }
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$fullName = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Chapel Dashboard | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            margin: 0;
            font-size: 22px;
        }

        header p {
            margin: 7px 0 0;
            color: #d1fae5;
            font-size: 13px;
        }

        .logout {
            background: #dc2626;
            color: white;
            padding: 10px 14px;
            border-radius: 6px;
            text-decoration: none;
        }

        main {
            max-width: 1100px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h2 {
            color: #123b2a;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .card h3 {
            color: #14532d;
            margin-top: 0;
        }

        .card p {
            color: #64748b;
            line-height: 1.5;
        }

        .card a {
            display: inline-block;
            margin-top: 8px;
            color: #166534;
            font-weight: bold;
            text-decoration: none;
        }

        .notice {
            margin-top: 25px;
            padding: 16px;
            background: #dcfce7;
            border-left: 4px solid #166534;
            border-radius: 5px;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>⛪ Chapel Department</h1>
        <p>Seminary Management System</p>
    </div>

    <a class="logout" href="../admin/logout.php">Log Out</a>
</header>

<main>

    <section class="welcome">
        <h2>Welcome, <?= e($fullName) ?>!</h2>

        <p>
            Role: <?= e(ucwords(str_replace('_', ' ', $role))) ?>
        </p>

        <p>
            Manage liturgical schedules, chapel duties, music, and celebrations.
        </p>
    </section>

    <section class="cards">

        <article class="card">
            <h3>🗓️ Mass Schedules</h3>
            <p>Organize daily Masses, Sunday Masses, and team Masses.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📋 Liturgical Duties</h3>
            <p>Assign lectors, altar servers, deacons, and other ministers.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🎵 Choir and Organists</h3>
            <p>Manage choir members, organists, rehearsals, and music duties.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🎼 Singing Practice</h3>
            <p>Schedule choir practice and upload songs for learning.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📖 Liturgical Music</h3>
            <p>Organize hymns, liturgical songs, and approved music resources.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🙏 Recollection and Prayer</h3>
            <p>Publish recollection schedules and community prayer activities.</p>
            <a href="#">Coming soon</a>
        </article>

    </section>

    <div class="notice">
        <strong>Development notice:</strong>
        The Chapel Dashboard is ready. Its management functions will be
        implemented step by step.
    </div>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
