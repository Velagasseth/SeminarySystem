<?php
$page_title = "St. Mbaagas Major Seminary -Gabba";

$departments = [
    [
        "name" => "Administration",
        "description" => "Manage users, departments, and system settings.",
        "icon" => "⚙️",
        "link" => "admin/login.php"
    ],
    [
        "name" => "Academics",
        "description" => "Lectures, units, assignments, and academic activities.",
        "icon" => "🎓",
        "link" => "academics/login.php"
    ],
    [
        "name" => "Library",
        "description" => "Books, borrowing, returns, and digital learning resources.",
        "icon" => "📚",
        "link" => "library/login.php"
    ],
    [
        "name" => "Chapel",
        "description" => "Liturgical duties, choir, readers, and chapel schedules.",
        "icon" => "⛪",
        "link" => "chapel/login.php"
    ],
    [
        "name" => "Manual Work",
        "description" => "Cleaning, gardening, livestock, and community duties.",
        "icon" => "🌱",
        "link" => "manual-work/login.php"
    ],
    [
        "name" => "Sports",
        "description" => "Sports activities, fixtures, teams, and results.",
        "icon" => "⚽",
        "link" => "sports/login.php"
    ],
    [
        "name" => "Finance",
        "description" => "Financial administration and accounting activities.",
        "icon" => "💰",
        "link" => "finance/login.php"
    ],
    [
        "name" => "Formation",
        "description" => "Seminarian formation, growth, and community life.",
        "icon" => "🙏",
        "link" => "formation/login.php"
    ],
    [
        "name" => "Communications",
        "description" => "Announcements, news, and community information.",
        "icon" => "📢",
        "link" => "communications/login.php"
    ],
    [
        "name" => "Seminarian Portal",
        "description" => "Access personal information and seminary activities.",
        "icon" => "👤",
        "link" => "portal/login.php"
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <meta name="theme-color" content="#123b2a">

    <title><?= htmlspecialchars($page_title) ?></title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #123b2a;
            --primary-light: #1d5b40;
            --accent: #c9a646;
            --background: #f4f7f5;
            --text: #24332b;
            --muted: #66756c;
            --white: #ffffff;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: var(--background);
            color: var(--text);
            line-height: 1.6;
        }

        a {
            text-decoration: none;
        }

        /* TOP BAR */

        .topbar {
            background: #0b291d;
            color: #e5eee8;
            padding: 9px 5%;
            font-size: 12px;
            text-align: center;
            letter-spacing: 0.5px;
        }

        /* HEADER */

        .header {
            background: var(--white);
            border-bottom: 3px solid var(--accent);
        }

        .header-inner {
            max-width: 1200px;
            margin: auto;
            padding: 22px 25px;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        /* LOGO PLACEHOLDER */

        .logo-placeholder {
            width: 90px;
            height: 90px;
            flex-shrink: 0;
            border: 2px dashed #9aab9e;
            border-radius: 50%;
            background: #f5f8f5;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #65786b;
            font-size: 12px;
            padding: 8px;
            overflow: hidden;
        }

        .logo-placeholder img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .school-info h1 {
            color: var(--primary);
            font-size: clamp(21px, 4vw, 32px);
            line-height: 1.3;
            margin-bottom: 5px;
        }

        .school-info p {
            color: var(--muted);
            font-size: 14px;
        }

        .school-label {
            display: inline-block;
            margin-top: 8px;
            color: var(--primary-light);
            background: #e8f2eb;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            letter-spacing: 0.5px;
        }

        /* HERO SECTION */

        .hero {
            background:
                linear-gradient(
                    120deg,
                    rgba(9, 39, 26, 0.97),
                    rgba(29, 91, 64, 0.92)
                );
            color: var(--white);
            padding: 55px 20px;
            text-align: center;
        }

        .hero-content {
            max-width: 800px;
            margin: auto;
        }

        .hero .eyebrow {
            color: #e5cb7b;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 15px;
        }

        .hero h2 {
            font-size: clamp(27px, 5vw, 43px);
            line-height: 1.2;
            margin-bottom: 16px;
        }

        .hero p {
            max-width: 650px;
            margin: auto;
            color: #e0ebe4;
            font-size: 15px;
        }

        .hero-line {
            width: 65px;
            height: 4px;
            background: var(--accent);
            margin: 22px auto 0;
            border-radius: 5px;
        }

        /* MAIN CONTENT */

        main {
            max-width: 1200px;
            margin: auto;
            padding: 45px 25px 55px;
        }

        .section-heading {
            text-align: center;
            margin-bottom: 30px;
        }

        .section-heading h2 {
            font-size: 27px;
            color: var(--primary);
            margin-bottom: 8px;
        }

        .section-heading p {
            color: var(--muted);
            font-size: 14px;
        }

        /* DEPARTMENT CARDS */

        .department-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .department-card {
            background: var(--white);
            padding: 24px;
            border-radius: 12px;
            border: 1px solid #e2e9e3;
            box-shadow: 0 4px 12px rgba(20, 50, 32, 0.04);
            display: flex;
            flex-direction: column;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .department-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 24px rgba(20, 50, 32, 0.10);
            border-color: #c6d9ca;
        }

        .card-top {
            display: flex;
            align-items: center;
            gap: 13px;
            margin-bottom: 16px;
        }

        .department-icon {
            width: 48px;
            height: 48px;
            flex-shrink: 0;
            background: #eaf3ec;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
        }

        .department-card h3 {
            color: var(--primary);
            font-size: 17px;
        }

        .department-card p {
            color: var(--muted);
            font-size: 13px;
            margin-bottom: 22px;
            flex-grow: 1;
        }

        .department-link {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #edf5ef;
            color: var(--primary);
            padding: 11px 13px;
            border-radius: 7px;
            font-size: 13px;
            font-weight: bold;
            transition: background 0.2s;
        }

        .department-link:hover {
            background: #d9eadc;
        }

        .arrow {
            font-size: 18px;
        }

        /* INFORMATION STRIP */

        .info-strip {
            margin-top: 35px;
            background: #fff;
            border-left: 4px solid var(--accent);
            border-radius: 8px;
            padding: 20px;
            display: flex;
            gap: 15px;
            align-items: flex-start;
        }

        .info-symbol {
            font-size: 25px;
        }

        .info-strip h3 {
            color: var(--primary);
            font-size: 16px;
            margin-bottom: 5px;
        }

        .info-strip p {
            color: var(--muted);
            font-size: 13px;
        }

        /* FOOTER */

        footer {
            background: #0b291d;
            color: #d6e3da;
            padding: 30px 20px;
            text-align: center;
        }

        .footer-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        footer p {
            font-size: 12px;
            margin-top: 5px;
            color: #b9cbbf;
        }

        .footer-accent {
            width: 45px;
            height: 3px;
            background: var(--accent);
            margin: 15px auto;
        }

        /* RESPONSIVE DESIGN */

        @media (max-width: 900px) {
            .department-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 550px) {
            .header-inner {
                padding: 18px 15px;
                gap: 13px;
            }

            .logo-placeholder {
                width: 70px;
                height: 70px;
                font-size: 10px;
            }

            .school-info p {
                font-size: 12px;
            }

            .hero {
                padding: 42px 20px;
            }

            main {
                padding: 35px 15px;
            }

            .department-grid {
                grid-template-columns: 1fr;
                gap: 14px;
            }

            .department-card {
                padding: 20px;
            }

            .section-heading h2 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

    <div class="topbar">
        ST. MBAAGAS COMMUNITY PORTAL
    </div>

    <!-- HEADER WITH LOGO PLACEHOLDER -->

    <header class="header">
        <div class="header-inner">

            <div class="logo-placeholder">
            <div class="logo-placeholder">
    <img
        src="assets/images/Mbagas2.png"
        alt="Seminary Logo"
    >
</div>
           
            </div>

            <div class="school-info">
                <h1>Seminary Management System</h1>

                <p>
                    Formation, Learning, Prayer and Community Life
                </p>

                <span class="school-label">
                    OFFICIAL COMMUNITY PORTAL
                </span>
            </div>

        </div>
    </header>

    <!-- HERO -->

    <section class="hero">
        <div class="hero-content">

            <div class="eyebrow">
                Welcome to St. Mbaagas Community
            </div>

            <h2>Growing Together in Faith and Knowledge</h2>

            <p>
                A central platform for managing seminary activities,
                academic programmes, spiritual formation, community
                responsibilities, and daily life.
            </p>

            <div class="hero-line"></div>

        </div>
    </section>

    <!-- DEPARTMENTS -->

    <main>

        <section class="section-heading">
            <h2>Explore Our Departments</h2>

            <p>
                Select a department below to access its portal.
            </p>
        </section>

        <section class="department-grid">

            <?php foreach ($departments as $department): ?>

                <article class="department-card">

                    <div class="card-top">

                        <div class="department-icon">
                            <?= $department['icon'] ?>
                        </div>

                        <h3>
                            <?= htmlspecialchars(
                                $department['name'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </h3>

                    </div>

                    <p>
                        <?= htmlspecialchars(
                            $department['description'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </p>

                    <a
                        class="department-link"
                        href="<?= htmlspecialchars(
                            $department['link'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                    >
                        <span>Open Department Portal</span>
                        <span class="arrow">&rarr;</span>
                    </a>

                </article>

            <?php endforeach; ?>

        </section>

        <section class="info-strip">

            <div class="info-symbol">ℹ️</div>

            <div>
                <h3>Accessing the System</h3>

                <p>
                    Select your department and log in using your
                    authorized account. Access to administrative
                    functions depends on your assigned role and
                    permissions.
                </p>
            </div>

        </section>

    </main>

    <!-- FOOTER -->

    <footer>

        <div class="footer-title">
            Seminary Management System
        </div>

        <div class="footer-accent"></div>

        <p>
            Supporting academic, spiritual, and community formation.
        </p>

        <p>
            &copy; <?= date("Y") ?> Seminary Management System.
            All rights reserved.
        </p>

        <p>System under development.</p>

    </footer>

</body>
</html>