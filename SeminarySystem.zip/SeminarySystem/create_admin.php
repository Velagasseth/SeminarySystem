<?php

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';

$fullName = 'System Administrator';
$username = 'admin';
$email = 'admin@seminary.local';
$password = 'ChangeThisPassword123!';

try {
    // Check whether the username already exists.
    $check = $pdo->prepare(
        'SELECT id FROM users WHERE username = ?'
    );
    $check->execute([$username]);

    if ($check->fetch()) {
        exit("An administrator with this username already exists.\n");
    }

    // Hash the password before storing it.
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    // Create the administrator account.
    $stmt = $pdo->prepare(
        'INSERT INTO users
        (full_name, username, email, password_hash, role, status)
        VALUES (?, ?, ?, ?, ?, ?)'
    );

    $stmt->execute([
        $fullName,
        $username,
        $email,
        $passwordHash,
        'super_admin',
        'active'
    ]);

    echo "Administrator account created successfully!\n";
    echo "Username: " . $username . "\n";
    echo "Change the initial password before using the system.\n";

} catch (PDOException $e) {
    error_log($e->getMessage());
    exit("Could not create the administrator account. Check the database configuration and users table.\n");
}
