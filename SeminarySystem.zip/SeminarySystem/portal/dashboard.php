<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Ensure the seminarian is logged in.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Verify Seminarian Portal access.
if (($_SESSION['role'] ?? '') !== 'super_admin') {

    $stmt = $pdo->prepare(
        "SELECT 1
         FROM user_departments ud
         INNER JOIN departments d
            ON d.id = ud.department_id
         WHERE ud.user_id = ?
           AND d.department_code = 'portal'
           AND d.status = 'active'
         LIMIT 1"
    );

    $stmt->execute([(int) $_SESSION['user_id']]);

    if (!$stmt->fetch()) {
        http_response_code(403);
        exit('Access denied. You are not authorized to access the Seminarian Portal.');
    }
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$fullName = $_SESSION['full_name'] ?? 'Seminarian';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Seminarian Portal | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #14532d;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            margin: 0;
            font-size: 22px;
        }

        header p {
            margin: 7px 0 0;
            color: #dcfce7;
            font-size: 13px;
        }

        .logout {
            background: #dc2626;
            color: white;
            padding: 10px 14px;
            border-radius: 6px;
            text-decoration: none;
        }

        main {
            max-width: 1150px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            background: white;
            padding: 24px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .welcome h2 {
            margin-top: 0;
            color: #14532d;
        }

        .section-title {
            margin: 28px 0 16px;
            color: #14532d;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .card h3 {
            margin-top: 0;
            color: #166534;
        }

        .card p {
            color: #64748b;
            line-height: 1.6;
        }

        .status {
            display: inline-block;
            margin-top: 5px;
            padding: 6px 9px;
            border-radius: 5px;
            background: #dcfce7;
            color: #166534;
            font-size: 12px;
        }

        .notice {
            margin-top: 25px;
            padding: 16px;
            background: #fef3c7;
            border-left: 4px solid #d97706;
            border-radius: 5px;
            line-height: 1.6;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>🎓 Seminarian Portal</h1>
        <p>Your personal seminary information centre</p>
    </div>

    <a class="logout" href="../admin/logout.php">
        Log Out
    </a>
</header>

<main>

    <section class="welcome">

        <h2>
            Welcome, <?= e($fullName) ?>!
        </h2>

        <p>
            This is your personal portal for academic activities,
            community responsibilities, and seminary announcements.
        </p>

        <p>
            Check this portal regularly for updates from your departments.
        </p>

    </section>

    <h2 class="section-title">📚 Academics</h2>

    <section class="cards">

        <article class="card">
            <h3>📖 My Units</h3>
            <p>View your subjects, units, and lecturers.</p>
            <span class="status">Coming soon</span>
        </article>

        <article class="card">
            <h3>📝 Assignments</h3>
            <p>View assignment instructions, deadlines, and submission details.</p>
            <span class="status">Coming soon</span>
        </article>

        <article class="card">
            <h3>🗓️ Timetable</h3>
            <p>Check lectures, examinations, and other scheduled activities.</p>
            <span class="status">Coming soon</span>
        </article>

    </section>

    <h2 class="section-title">🙏 Community Life</h2>

    <section class="cards">

        <article class="card">
            <h3>⛪ Chapel Duties</h3>
            <p>Check your assigned liturgical duties and service schedules.</p>
            <span class="status">Coming soon</span>
        </article>

        <article class="card">
            <h3>🧹 Manual Work</h3>
            <p>View assigned duties and community work schedules.</p>
            <span class="status">Coming soon</span>
        </article>

        <article class="card">
            <h3>⚽ Sports</h3>
            <p>Check sports fixtures, teams, matches, and results.</p>
            <span class="status">Coming soon</span>
        </article>

        <article class="card">
            <h3>📚 Library</h3>
            <p>Search for books and check borrowing records and due dates.</p>
            <span class="status">Coming soon</span>
        </article>

    </section>

    <h2 class="section-title">📢 Information</h2>

    <section class="cards">

        <article class="card">
            <h3>📣 Announcements</h3>
            <p>Read official notices and important community updates.</p>
            <span class="status">Coming soon</span>
        </article>

        <article class="card">
            <h3>📅 Events</h3>
            <p>View upcoming recollections, community service, and seminary events.</p>
            <span class="status">Coming soon</span>
        </article>

        <article class="card">
            <h3>👤 My Profile</h3>
            <p>View your registered account information.</p>
            <span class="status">Coming soon</span>
        </article>

    </section>

    <div class="notice">
        <strong>Development notice:</strong>
        These sections are currently placeholders. They will become functional
        as we build the database tables and features for each department.
    </div>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
