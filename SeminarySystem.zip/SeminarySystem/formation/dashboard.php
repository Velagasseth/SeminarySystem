<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Require login.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Verify Formation Department access.
if (($_SESSION['role'] ?? '') !== 'super_admin') {

    $stmt = $pdo->prepare(
        "SELECT 1
         FROM user_departments ud
         INNER JOIN departments d
            ON d.id = ud.department_id
         WHERE ud.user_id = ?
           AND d.department_code = 'formation'
           AND d.status = 'active'
         LIMIT 1"
    );

    $stmt->execute([(int) $_SESSION['user_id']]);

    if (!$stmt->fetch()) {
        http_response_code(403);
        exit('Access denied. You are not assigned to the Formation Department.');
    }
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$fullName = $_SESSION['full_name'] ?? 'User';
$role = $_SESSION['role'] ?? 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Formation Dashboard | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }

        header {
            background: #123b2a;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        header h1 {
            margin: 0;
            font-size: 22px;
        }

        header p {
            margin: 7px 0 0;
            color: #d1fae5;
            font-size: 13px;
        }

        .logout {
            background: #dc2626;
            color: white;
            padding: 10px 14px;
            border-radius: 6px;
            text-decoration: none;
        }

        main {
            max-width: 1100px;
            margin: auto;
            padding: 25px 18px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h2 {
            color: #123b2a;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .card h3 {
            color: #14532d;
            margin-top: 0;
        }

        .card p {
            color: #64748b;
            line-height: 1.5;
        }

        .card a {
            display: inline-block;
            margin-top: 8px;
            color: #166534;
            font-weight: bold;
            text-decoration: none;
        }

        .notice {
            margin-top: 25px;
            padding: 16px;
            background: #dcfce7;
            border-left: 4px solid #166534;
            border-radius: 5px;
        }

        footer {
            text-align: center;
            padding: 25px;
            color: #64748b;
            font-size: 13px;
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>🙏 Formation Department</h1>
        <p>Seminary Management System</p>
    </div>

    <a class="logout" href="../admin/logout.php">Log Out</a>
</header>

<main>

    <section class="welcome">
        <h2>Welcome, <?= e($fullName) ?>!</h2>

        <p>
            Role: <?= e(ucwords(str_replace('_', ' ', $role))) ?>
        </p>

        <p>
            Support the human, spiritual, intellectual, and pastoral
            formation of seminarians.
        </p>
    </section>

    <section class="cards">

        <article class="card">
            <h3>👤 Seminarian Profiles</h3>
            <p>Organize seminarian records and formation information.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🌱 Formation Progress</h3>
            <p>Record formation goals, reviews, and progress assessments.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🙏 Spiritual Development</h3>
            <p>Organize spiritual activities and confidential appointments.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🤝 Community Life</h3>
            <p>Coordinate community responsibilities and shared activities.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>🕊️ Retreats and Recollections</h3>
            <p>Publish retreat dates, recollections, and prayer activities.</p>
            <a href="#">Coming soon</a>
        </article>

        <article class="card">
            <h3>📋 Formation Reports</h3>
            <p>Prepare authorized formation summaries and progress reports.</p>
            <a href="#">Coming soon</a>
        </article>

    </section>

    <div class="notice">
        <strong>Development notice:</strong>
        This dashboard currently provides the interface. Database-backed
        formation records will be developed in later steps. Confidential
        spiritual-direction notes should not be exposed through general
        seminarian records or reports.
    </div>

</main>

<footer>
    &copy; <?= date('Y') ?> Seminary Management System
</footer>

</body>
</html>
