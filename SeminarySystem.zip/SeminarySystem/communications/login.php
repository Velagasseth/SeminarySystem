<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../config/database.php';

// Generate CSRF token.
if (empty($_SESSION['communications_csrf'])) {
    $_SESSION['communications_csrf'] = bin2hex(random_bytes(32));
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['communications_csrf'], $token)
    ) {
        $error = 'Invalid request. Please refresh the page and try again.';
    } else {

        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === '' || $password === '') {

            $error = 'Please enter both your username and password.';

        } else {

            // Find the account.
            $stmt = $pdo->prepare(
                "SELECT id, full_name, username, password_hash, role, status
                 FROM users
                 WHERE username = ?
                 LIMIT 1"
            );

            $stmt->execute([$username]);
            $user = $stmt->fetch();

            // Verify account status and password.
            if (
                $user &&
                $user['status'] === 'active' &&
                password_verify($password, $user['password_hash'])
            ) {

                $hasAccess = false;

                // Super administrator can access all departments.
                if ($user['role'] === 'super_admin') {

                    $hasAccess = true;

                } else {

                    // Check Communications Department permission.
                    $accessStmt = $pdo->prepare(
                        "SELECT 1
                         FROM user_departments ud
                         INNER JOIN departments d
                            ON d.id = ud.department_id
                         WHERE ud.user_id = ?
                           AND d.department_code = 'communications'
                           AND d.status = 'active'
                         LIMIT 1"
                    );

                    $accessStmt->execute([(int) $user['id']]);

                    $hasAccess = (bool) $accessStmt->fetch();
                }

                if ($hasAccess) {

                    // Regenerate session ID after successful login.
                    session_regenerate_id(true);

                    $_SESSION['user_id'] = (int) $user['id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['department_code'] = 'communications';

                    unset($_SESSION['communications_csrf']);

                    header('Location: dashboard.php');
                    exit;

                } else {

                    $error = 'You are not authorized to access this department.';
                }

            } else {

                $error = 'Incorrect username or password, or your account is inactive.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Communications Login | Seminary Management System</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background: #f1f5f9;
            font-family: Arial, sans-serif;
        }

        .login-box {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
        }

        h1 {
            text-align: center;
            color: #1e3a8a;
            font-size: 24px;
        }

        .subtitle {
            text-align: center;
            color: #64748b;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #334155;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 18px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 16px;
        }

        input:focus {
            outline: 2px solid #93c5fd;
            border-color: #2563eb;
        }

        button {
            width: 100%;
            padding: 13px;
            background: #1d4ed8;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1e40af;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
            line-height: 1.5;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #1d4ed8;
            text-decoration: none;
        }

        .back:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

<div class="login-box">

    <h1>📢 Communications</h1>

    <p class="subtitle">
        Seminary Management System
        <br>
        Department Login
    </p>

    <?php if ($error !== ''): ?>

        <div class="error">
            <?= htmlspecialchars(
                $error,
                ENT_QUOTES,
                'UTF-8'
            ) ?>
        </div>

    <?php endif; ?>

    <form method="POST" action="">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars(
                $_SESSION['communications_csrf'],
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >

        <label for="username">Username</label>

        <input
            type="text"
            id="username"
            name="username"
            placeholder="Enter your username"
            autocomplete="username"
            required
        >

        <label for="password">Password</label>

        <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            autocomplete="current-password"
            required
        >

        <button type="submit">
            Log In
        </button>

    </form>

    <a class="back" href="../index.php">
        ← Back to Home
    </a>

</div>

</body>
</html>