<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/config/database.php';

// Only allow the super administrator to view this page.
if (
    !isset($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'super_admin'
) {
    http_response_code(403);
    exit('Access denied. Please log in as the super administrator.');
}

$checks = [];

// Check essential database tables.
$requiredTables = [
    'users',
    'departments',
    'user_departments'
];

foreach ($requiredTables as $table) {
    try {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*)
             FROM information_schema.tables
             WHERE table_schema = DATABASE()
               AND table_name = ?"
        );

        $stmt->execute([$table]);

        $exists = (int) $stmt->fetchColumn() > 0;

        $checks[] = [
            'name' => "Table: {$table}",
            'success' => $exists,
            'message' => $exists
                ? 'Table exists'
                : 'Table is missing'
        ];

    } catch (PDOException $e) {
        $checks[] = [
            'name' => "Table: {$table}",
            'success' => false,
            'message' => 'Unable to check table'
        ];
    }
}

// Check required departments.
$requiredDepartments = [
    'admin',
    'academics',
    'library',
    'chapel',
    'manual-work',
    'sports',
    'finance',
    'formation',
    'communications',
    'portal'
];

try {
    $stmt = $pdo->query(
        "SELECT department_code
         FROM departments"
    );

    $existingDepartments = $stmt->fetchAll(PDO::FETCH_COLUMN);

    foreach ($requiredDepartments as $code) {
        $exists = in_array($code, $existingDepartments, true);

        $checks[] = [
            'name' => "Department: {$code}",
            'success' => $exists,
            'message' => $exists
                ? 'Department exists'
                : 'Department is missing'
        ];
    }

} catch (PDOException $e) {
    $checks[] = [
        'name' => 'Department records',
        'success' => false,
        'message' => 'Could not read department records'
    ];
}

$allPassed = true;

foreach ($checks as $check) {
    if (!$check['success']) {
        $allPassed = false;
        break;
    }
}

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>System Health Check</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 20px;
            background: #f1f5f9;
            color: #1e293b;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 850px;
            margin: 25px auto;
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
        }

        h1 {
            color: #14532d;
        }

        .summary {
            padding: 15px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .passed {
            background: #dcfce7;
            color: #166534;
        }

        .failed {
            background: #fee2e2;
            color: #991b1b;
        }

        .check {
            padding: 13px;
            margin-bottom: 10px;
            border: 1px solid #e2e8f0;
            border-radius: 7px;
        }

        .check strong {
            display: block;
            margin-bottom: 5px;
        }

        .ok {
            color: #15803d;
        }

        .bad {
            color: #b91c1c;
        }

        .back {
            display: inline-block;
            margin-top: 15px;
            color: #166534;
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>🛠️ System Health Check</h1>

    <p>
        This page checks the essential database tables and department records.
    </p>

    <div class="summary <?= $allPassed ? 'passed' : 'failed' ?>">
        <?= $allPassed
            ? 'All checks passed!'
            : 'Some checks failed. Review the results below.' ?>
    </div>

    <?php foreach ($checks as $check): ?>

        <div class="check">

            <strong>
                <?= escapeHtml($check['name']) ?>
            </strong>

            <span class="<?= $check['success'] ? 'ok' : 'bad' ?>">
                <?= $check['success'] ? '✓ ' : '✗ ' ?>
                <?= escapeHtml($check['message']) ?>
            </span>

        </div>

    <?php endforeach; ?>

    <a class="back" href="index.php">
        ← Return to Home
    </a>

</div>

</body>
</html>
